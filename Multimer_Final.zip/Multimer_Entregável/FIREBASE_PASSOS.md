# Firebase: o que fazer

Projeto: `multimer-6b325` (plano Spark, gratuito, sem cartão).
Região do Cloud Firestore: `eur3` (Europa / Europe-West).
A informação seguinte pode não estar totalmente integrada no projeto atual por conflitos de regulamentação, no entanto serve para guia futuro, aquando do término do desenvolvimento da versão final da aplicação.

## 1. Ficheiro de configuração da app
O ficheiro `google-services.json` encontra-se em `app/` para a app Android `pt.ubi.di.pdm.multimer`.
Foi efetuado o **Sync** e a compilação da app no Android Studio com sucesso.
Sem este ficheiro a app compila e funciona normalmente, só sem contas.

## 2. Publicar as regras de segurança (obrigatório)
As regras fecham a base de dados: cada pessoa só acede ao que é seu. Duas formas:

**A. Com um comando** (na pasta do projeto, onde está o `firebase.json`):
```
npm install -g firebase-tools
firebase login
firebase deploy --only firestore
```

**B. Colando na consola:** Firestore Database → separador **Regras** → substitui tudo pelo conteúdo de
`firebase/firestore.rules` → **Publicar**.

## 3. Região e Privacidade
- **Região do Cloud Firestore:** `eur3` (Europa / Europe-West).
- **Informação de privacidade:** O ecrã de conta (`sheet_account.xml`) explicita que os dados do utilizador (e-mail, nome, alarmes e cascatas sincronizados) são guardados no Firebase na região `eur3` (Europa) e podem ser eliminados a qualquer momento.

## 4. Confirmar
1. Na app, toca no botão de perfil (canto superior direito) e cria uma conta.
2. Cria um alarme. Na consola, em Firestore → Dados, deve aparecer `users/<id>/alarms/...`.
3. Em Authentication → Utilizadores aparece a conta.