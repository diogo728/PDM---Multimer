package pt.ubi.di.pdm.multimer.sync

import com.google.firebase.firestore.DocumentSnapshot
import pt.ubi.di.pdm.multimer.data.model.AlarmEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeStepEntity
import pt.ubi.di.pdm.multimer.data.model.TimerEntity
import pt.ubi.di.pdm.multimer.util.RepeatDays
import pt.ubi.di.pdm.multimer.util.SoundLibrary
import pt.ubi.di.pdm.multimer.util.SoundUtils

/**
 * Converte entre os itens locais e os documentos da conta. Só viajam definições
 * (nunca o estado ligado/desligado) e tudo o que chega é validado e limitado.
 */
object SyncMapper {

    private const val MAX_TEXT = 80
    private const val MAX_STEPS = 60
    private const val MAX_WAIT_MS = 7L * 24 * 3_600 * 1_000

    /** Sons de ficheiros do aparelho não são portáveis: só a biblioteca da app (ou silêncio) viaja. */
    private fun sound(s: String?): String? =
        if (s == null || s == SoundUtils.SILENT || SoundLibrary.find(s) != null) s else null

    private fun clean(s: String?, max: Int = MAX_TEXT): String =
        (s ?: "").filter { !it.isISOControl() }.trim().take(max)

    private fun titleOf(sound: String?): String = SoundLibrary.find(sound)?.title ?: if (sound == SoundUtils.SILENT) "Sem som" else "Carrilhão"

    fun tombstone(now: Long): Map<String, Any?> = hashMapOf("deleted" to true, "updatedAt" to now)

    // ---------------------------------------------------------------- Alarmes

    fun alarmToMap(a: AlarmEntity): Map<String, Any?> = hashMapOf(
        "hour" to a.hour,
        "minute" to a.minute,
        "label" to clean(a.label),
        "repeatDays" to a.repeatDays,
        "vibrate" to a.isVibrationEnabled,
        "sound" to sound(a.soundUri),
        "snoozeEnabled" to a.isSnoozeEnabled,
        "snoozeMinutes" to a.snoozeMinutes,
        "gradual" to a.isGradualVolume,
        "updatedAt" to a.updatedAt,
        "deleted" to false
    )

    fun alarmFrom(d: DocumentSnapshot): AlarmEntity? {
        val hour = d.getLong("hour")?.toInt() ?: return null
        val minute = d.getLong("minute")?.toInt() ?: return null
        if (hour !in 0..23 || minute !in 0..59) return null
        val snooze = (d.getLong("snoozeMinutes") ?: 10L).toInt().coerceIn(1, 60)
        val snd = sound(d.getString("sound"))
        return AlarmEntity(
            hour = hour,
            minute = minute,
            label = clean(d.getString("label")),
            repeatDays = RepeatDays.toStorage(RepeatDays.parse(d.getString("repeatDays") ?: "")),
            isVibrationEnabled = d.getBoolean("vibrate") ?: true,
            soundUri = snd,
            soundTitle = titleOf(snd),
            isSnoozeEnabled = d.getBoolean("snoozeEnabled") ?: true,
            snoozeMinutes = snooze,
            isGradualVolume = d.getBoolean("gradual") ?: true
        )
    }

    // ---------------------------------------------------------------- Cascatas

    fun cascadeToMap(c: CascadeEntity, steps: List<CascadeStepEntity>): Map<String, Any?> {
        val list = steps.sortedBy { it.stepOrder }.map {
            hashMapOf<String, Any?>(
                "title" to clean(it.title),
                "wait" to it.durationInMillis,
                "autoDismiss" to it.autoDismiss,
                "vibrate" to it.isVibrationEnabled,
                "sound" to sound(it.soundUri)
            )
        }
        return hashMapOf(
            "title" to clean(c.title),
            "type" to c.type,
            "intervalMillis" to c.intervalMillis,
            "repeatCount" to c.repeatCount,
            "autoDismiss" to c.autoDismiss,
            "vibrate" to c.isVibrationEnabled,
            "sound" to sound(c.soundUri),
            "createdAt" to c.createdAt,
            "steps" to list,
            "updatedAt" to c.updatedAt,
            "deleted" to false
        )
    }

    fun cascadeFrom(d: DocumentSnapshot): Pair<CascadeEntity, List<CascadeStepEntity>>? =
        cascadeFromMap(d.data ?: emptyMap())

    fun cascadeFromMap(map: Map<String, Any?>): Pair<CascadeEntity, List<CascadeStepEntity>>? {
        val type = (map["type"] as? Number)?.toInt() ?: return null
        if (type != CascadeEntity.TYPE_SEQUENTIAL && type != CascadeEntity.TYPE_CUSTOM) return null
        val interval = (map["intervalMillis"] as? Number)?.toLong() ?: 0L
        val count = (map["repeatCount"] as? Number)?.toInt() ?: 0
        if (type == CascadeEntity.TYPE_SEQUENTIAL && (interval < 1_000L || interval > 24L * 3_600 * 1_000)) return null
        if (count !in 0..999) return null
        val snd = sound(map["sound"] as? String)

        @Suppress("UNCHECKED_CAST")
        val raw = map["steps"] as? List<Map<String, Any?>> ?: emptyList()
        if (raw.size > MAX_STEPS) return null
        val steps = ArrayList<CascadeStepEntity>()
        for ((i, m) in raw.withIndex()) {
            val wait = (m["wait"] as? Number)?.toLong() ?: return null
            if (wait < 1_000L || wait > MAX_WAIT_MS) return null
            val stepSound = sound(m["sound"] as? String)
            steps.add(
                CascadeStepEntity(
                    stepOrder = i,
                    title = clean(m["title"] as? String).ifEmpty { "Passo ${i + 1}" },
                    durationInMillis = wait,
                    autoDismiss = m["autoDismiss"] as? Boolean ?: true,
                    isVibrationEnabled = m["vibrate"] as? Boolean ?: true,
                    soundUri = stepSound,
                    soundTitle = titleOf(stepSound)
                )
            )
        }
        if (type == CascadeEntity.TYPE_CUSTOM && steps.isEmpty()) return null

        val cascade = CascadeEntity(
            title = clean(map["title"] as? String).ifEmpty { "Sem nome" },
            createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
            type = type,
            intervalMillis = interval,
            repeatCount = count,
            autoDismiss = map["autoDismiss"] as? Boolean ?: true,
            isVibrationEnabled = map["vibrate"] as? Boolean ?: true,
            soundUri = snd,
            soundTitle = titleOf(snd)
        )
        return Pair(cascade, steps)
    }

    // ---------------------------------------------------------------- Temporizadores recentes

    fun timerToMap(t: TimerEntity): Map<String, Any?> = hashMapOf(
        "title" to clean(t.title),
        "duration" to t.durationInMillis,
        "vibrate" to t.isVibrationEnabled,
        "sound" to sound(t.soundUri),
        "autoDismiss" to t.autoDismiss,
        "createdAt" to t.createdAt,
        "updatedAt" to t.updatedAt,
        "deleted" to false
    )

    fun timerFrom(d: DocumentSnapshot): TimerEntity? {
        val duration = d.getLong("duration") ?: return null
        if (duration < 1_000L || duration > 24L * 3_600 * 1_000) return null
        return TimerEntity(
            title = clean(d.getString("title")),
            durationInMillis = duration,
            isVibrationEnabled = d.getBoolean("vibrate") ?: true,
            soundUri = sound(d.getString("sound")),
            autoDismiss = d.getBoolean("autoDismiss") ?: false,
            createdAt = d.getLong("createdAt") ?: System.currentTimeMillis()
        )
    }

    // ---------------------------------------------------------------- Definições do temporizador

    fun settingsToMap(soundUri: String?, vibrate: Boolean, autoStop: Boolean, updatedAt: Long): Map<String, Any?> =
        hashMapOf("sound" to sound(soundUri), "vibrate" to vibrate, "autoStop" to autoStop, "updatedAt" to updatedAt)
}
