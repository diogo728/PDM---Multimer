package pt.ubi.di.pdm.multimer.util

import android.content.Context
import android.net.Uri

/**
 * Valores guardados para o som de um alarme, passo ou temporizador:
 *  - "builtin:snd_..." um som da biblioteca da app
 *  - "silent"          sem som (só vibração, se estiver ativa)
 *  - null              por omissão (carrilhão)
 *  - outro texto       um toque antigo do aparelho (alarmes criados em versões anteriores)
 */
object SoundUtils {
    /** Valor guardado quando o utilizador escolhe "Sem som". */
    const val SILENT = "silent"

    fun titleFor(ctx: Context, stored: String?): String {
        if (stored == SILENT) return "Sem som"
        if (stored == null) return SoundLibrary.find(SoundLibrary.DEFAULT_TIMER)?.title ?: "Carrilhão"
        return SoundLibrary.find(stored)?.title ?: "Toque personalizado"
    }

    /** null significa silêncio. */
    fun resolveUri(ctx: Context, stored: String?): Uri? {
        if (stored == SILENT) return null
        if (stored.isNullOrEmpty()) return defaultUri(ctx)
        val sound = SoundLibrary.find(stored)
        if (sound != null) return SoundLibrary.uriFor(ctx, sound)
        return try {
            Uri.parse(stored)
        } catch (e: Exception) {
            defaultUri(ctx)
        }
    }

    fun defaultUri(ctx: Context): Uri? =
        SoundLibrary.find(SoundLibrary.DEFAULT_TIMER)?.let { SoundLibrary.uriFor(ctx, it) }
}
