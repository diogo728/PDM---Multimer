package pt.ubi.di.pdm.multimer.data.repository

import kotlinx.coroutines.flow.Flow
import pt.ubi.di.pdm.multimer.data.local.TimerDao
import pt.ubi.di.pdm.multimer.data.model.TimerEntity
import pt.ubi.di.pdm.multimer.sync.SyncManager

class TimerRepository(private val timerDao: TimerDao) {

    val allTimers: Flow<List<TimerEntity>> = timerDao.getAllTimers()

    suspend fun getTimerById(id: Long): TimerEntity? = timerDao.getTimerById(id)

    suspend fun insertTimer(timer: TimerEntity): Long = timerDao.insertTimer(timer)

    suspend fun updateTimer(timer: TimerEntity) = timerDao.updateTimer(timer)

    suspend fun deleteTimer(timer: TimerEntity) = removeWithTombstone(timer)

    /** Guarda o temporizador como "recente", sem duplicados da mesma duração e etiqueta. */
    suspend fun recordRecent(timer: TimerEntity) {
        for (duplicate in timerDao.findDuplicates(timer.durationInMillis, timer.title)) removeWithTombstone(duplicate)
        val now = SyncIds.now()
        timerDao.insertTimer(timer.copy(id = 0L, syncId = SyncIds.newId(), createdAt = now, updatedAt = now))
        for (old in timerDao.getOverflow()) removeWithTombstone(old)
    }

    private suspend fun removeWithTombstone(timer: TimerEntity) {
        timerDao.deleteTimer(timer)
        if (timer.syncId.isNotBlank()) SyncManager.onLocalDelete(SyncManager.TIMERS, timer.syncId)
    }
}
