package pt.ubi.di.pdm.multimer.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.ui.activity.AlarmRingingActivity
import pt.ubi.di.pdm.multimer.util.AlarmScheduler
import pt.ubi.di.pdm.multimer.util.NotificationStyle
import pt.ubi.di.pdm.multimer.util.Notifications
import pt.ubi.di.pdm.multimer.util.RingPlayer
import pt.ubi.di.pdm.multimer.util.TimeFmt

/** Toca o alarme (som, vibração e notificação em ecrã inteiro) até ser parado ou adiado. */
class AlarmService : Service() {

    private lateinit var player: RingPlayer
    private val handler = Handler(Looper.getMainLooper())
    private val silenceRunnable = Runnable { stopAlarm() }

    private var alarmId = -1L
    private var label = ""
    private var hour = 0
    private var minute = 0
    private var snoozeEnabled = true
    private var snoozeMinutes = 10

    companion object {
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP_ALARM = "pt.ubi.di.pdm.multimer.ACTION_STOP_ALARM"
        const val ACTION_SNOOZE_ALARM = "pt.ubi.di.pdm.multimer.ACTION_SNOOZE_ALARM"

        /** Se ninguém desligar, o alarme cala-se sozinho ao fim de 10 minutos. */
        private const val AUTO_SILENCE_MS = 10 * 60 * 1000L
    }

    override fun onCreate() {
        super.onCreate()
        Notifications.ensureChannels(this)
        player = RingPlayer(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_ALARM -> {
                stopAlarm()
                return START_NOT_STICKY
            }
            ACTION_SNOOZE_ALARM -> {
                snoozeAlarm()
                return START_NOT_STICKY
            }
        }

        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        alarmId = intent.getLongExtra(AlarmScheduler.EXTRA_ALARM_ID, -1L)
        label = intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_LABEL) ?: ""
        hour = intent.getIntExtra(AlarmScheduler.EXTRA_ALARM_HOUR, 0)
        minute = intent.getIntExtra(AlarmScheduler.EXTRA_ALARM_MINUTE, 0)
        snoozeEnabled = intent.getBooleanExtra(AlarmScheduler.EXTRA_ALARM_SNOOZE_ENABLED, true)
        snoozeMinutes = intent.getIntExtra(AlarmScheduler.EXTRA_ALARM_SNOOZE_MINUTES, 10)
        val vibrate = intent.getBooleanExtra(AlarmScheduler.EXTRA_ALARM_VIBRATE, true)
        val soundUri = intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_SOUND_URI)
        val gradual = intent.getBooleanExtra(AlarmScheduler.EXTRA_ALARM_GRADUAL, true)

        startForeground(NOTIFICATION_ID, buildNotification())
        player.start(soundUri, vibrate, loop = true, gradualVolume = gradual)

        handler.removeCallbacks(silenceRunnable)
        handler.postDelayed(silenceRunnable, AUTO_SILENCE_MS)

        try {
            startActivity(ringingIntent())
        } catch (e: Exception) {
            // Sem permissão para abrir em segundo plano: a notificação em ecrã inteiro trata disso
        }
        return START_NOT_STICKY
    }

    private fun ringingIntent(): Intent {
        val title = if (label.isNotEmpty()) label else "Alarme"
        return AlarmRingingActivity.newIntent(
            this,
            AlarmRingingActivity.KIND_ALARM,
            "Alarme",
            TimeFmt.clockWithSuffix(this, hour, minute),
            if (label.isNotEmpty()) title else "",
            if (snoozeEnabled) "Adiar $snoozeMinutes min" else null,
            alarmId
        )
    }

    private fun buildNotification(): Notification {
        val fullScreen = PendingIntent.getActivity(this, 1, ringingIntent(), Notifications.IMMUTABLE_UPDATE)
        val stopPi = Notifications.servicePendingIntent(this, AlarmService::class.java, ACTION_STOP_ALARM, 2)

        val builder = NotificationCompat.Builder(this, Notifications.CHANNEL_ALERT)
            .setSmallIcon(R.drawable.ic_nav_alarm)
            .setContentTitle(TimeFmt.clockWithSuffix(this, hour, minute))
            .setContentText(if (label.isNotEmpty()) label else "A tocar")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(fullScreen)
            .setFullScreenIntent(fullScreen, true)
            .setOngoing(true)
        NotificationStyle.alert(this, builder, "Alarme")

        if (snoozeEnabled) {
            val snoozePi = Notifications.servicePendingIntent(this, AlarmService::class.java, ACTION_SNOOZE_ALARM, 3)
            builder.addAction(0, getString(R.string.t_adiar), snoozePi)
        }
        builder.addAction(0, getString(R.string.t_parar), stopPi)
        return builder.build()
    }

    private fun snoozeAlarm() {
        if (alarmId != -1L && snoozeEnabled) {
            AlarmScheduler.scheduleSnooze(this, alarmId, snoozeMinutes)
        }
        stopAlarm()
    }

    private fun stopAlarm() {
        handler.removeCallbacks(silenceRunnable)
        player.stop()
        sendBroadcast(AlarmRingingActivity.dismissBroadcast(this, AlarmRingingActivity.KIND_ALARM))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacks(silenceRunnable)
        player.stop()
        super.onDestroy()
    }
}
