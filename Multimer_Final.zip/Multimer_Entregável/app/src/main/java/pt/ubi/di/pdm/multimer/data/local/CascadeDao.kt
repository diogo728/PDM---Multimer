package pt.ubi.di.pdm.multimer.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import pt.ubi.di.pdm.multimer.data.model.CascadeEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeStepEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeWithSteps

@Dao
interface CascadeDao {

    @Transaction
    @Query("SELECT * FROM cascades ORDER BY createdAt DESC")
    fun getAllCascadesWithSteps(): Flow<List<CascadeWithSteps>>

    @Transaction
    @Query("SELECT * FROM cascades WHERE id = :cascadeId")
    suspend fun getCascadeWithStepsById(cascadeId: Long): CascadeWithSteps?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCascade(cascade: CascadeEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSteps(steps: List<CascadeStepEntity>)

    @Update
    suspend fun updateCascade(cascade: CascadeEntity)

    @Delete
    suspend fun deleteCascade(cascade: CascadeEntity)

    @Query("DELETE FROM cascade_steps WHERE cascadeId = :cascadeId")
    suspend fun deleteStepsForCascade(cascadeId: Long)

    // --- Sincronização ---
    @Transaction
    @Query("SELECT * FROM cascades WHERE syncId = :syncId LIMIT 1")
    suspend fun getBySyncId(syncId: String): CascadeWithSteps?

    @Transaction
    @Query("SELECT * FROM cascades WHERE updatedAt > syncedAt")
    fun observeDirty(): Flow<List<CascadeWithSteps>>

    @Transaction
    @Query("SELECT * FROM cascades")
    suspend fun getAllOnce(): List<CascadeWithSteps>

    @Query("SELECT COUNT(*) FROM cascades")
    suspend fun count(): Int

    @Query("UPDATE cascades SET syncedAt = :version WHERE syncId = :syncId AND updatedAt = :version")
    suspend fun markSynced(syncId: String, version: Long)

    @Query("UPDATE cascades SET syncedAt = updatedAt")
    suspend fun markAllSynced()

    @Query("DELETE FROM cascades WHERE syncId = :syncId")
    suspend fun deleteBySyncId(syncId: String)
}
