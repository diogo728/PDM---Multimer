package pt.ubi.di.pdm.multimer.ui.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import pt.ubi.di.pdm.multimer.MainActivity
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.data.local.AppDatabase
import pt.ubi.di.pdm.multimer.data.model.CascadeEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeWithSteps
import pt.ubi.di.pdm.multimer.data.repository.AlarmRepository
import pt.ubi.di.pdm.multimer.data.repository.CascadeRepository
import pt.ubi.di.pdm.multimer.share.ShareCodec
import pt.ubi.di.pdm.multimer.util.CascadeFormat
import pt.ubi.di.pdm.multimer.util.RepeatDays
import pt.ubi.di.pdm.multimer.util.TimeFmt
import pt.ubi.di.pdm.multimer.util.enableEdgeToEdge

/**
 * Recebe um alarme partilhado (ligação multimer://, texto partilhado ou código colado/lido),
 * mostra o que vai ser importado e só grava depois de confirmares. Alarmes chegam sempre desligados.
 */
class ImportActivity : AppCompatActivity() {

    private var item: ShareCodec.Item? = null
    private var importing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_import)
        enableEdgeToEdge()

        findViewById<MaterialButton>(R.id.btnImportCancel).setOnClickListener { finish() }
        findViewById<MaterialButton>(R.id.btnImportErrorClose).setOnClickListener { finish() }
        findViewById<MaterialButton>(R.id.btnImportConfirm).setOnClickListener { confirm() }

        val text = when (intent.action) {
            Intent.ACTION_VIEW -> intent.dataString
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)
            else -> intent.getStringExtra(EXTRA_PAYLOAD)
        }
        when (val result = ShareCodec.decode(text)) {
            is ShareCodec.Result.Ok -> showPreview(result.item)
            is ShareCodec.Result.Error -> showError(result.message)
        }
    }

    private fun showError(message: String) {
        findViewById<View>(R.id.layoutImportOk).visibility = View.GONE
        findViewById<View>(R.id.layoutImportError).visibility = View.VISIBLE
        findViewById<TextView>(R.id.tvImportError).text = message
    }

    private fun showPreview(parsed: ShareCodec.Item) {
        item = parsed
        findViewById<View>(R.id.layoutImportError).visibility = View.GONE
        findViewById<View>(R.id.layoutImportOk).visibility = View.VISIBLE

        val kind: String
        val name: String
        val summary: String
        val details: String
        val note: String
        val button: String

        when (parsed) {
            is ShareCodec.Item.AlarmItem -> {
                val a = parsed.alarm
                kind = "Alarme"
                name = if (a.label.isNotEmpty()) a.label else "Alarme"
                summary = TimeFmt.clock(this, a.hour, a.minute) + ", " + RepeatDays.describe(a.repeatDays)
                details = listOf(
                    "Som: ${a.soundTitle}",
                    "Vibração: " + (if (a.isVibrationEnabled) "ligada" else "desligada"),
                    "Adiar: " + (if (a.isSnoozeEnabled) "${a.snoozeMinutes} min" else "desligado"),
                    "Volume crescente: " + (if (a.isGradualVolume) "sim" else "não")
                ).joinToString("\n")
                note = "Chega desligado, na lista de alarmes. Ativa-o quando quiseres. É uma cópia independente."
                button = "Importar para Alarmes"
            }
            is ShareCodec.Item.SequentialItem -> {
                val c = parsed.cascade
                kind = "Alarme sequencial"
                name = c.title
                summary = CascadeFormat.summary(CascadeWithSteps(c, emptyList()))
                details = listOf(
                    "Som: ${c.soundTitle ?: "Carrilhão"}",
                    "Vibração: " + (if (c.isVibrationEnabled) "ligada" else "desligada"),
                    "Desligar manualmente: " + (if (c.autoDismiss) "não" else "sim")
                ).joinToString("\n")
                note = "Fica na aba Cascata, em Sequenciais, e só arranca quando o iniciares. É uma cópia independente."
                button = "Importar para Cascata"
            }
            is ShareCodec.Item.CascadeItem -> {
                val c = parsed.cascade
                kind = "Cascata personalizada"
                name = c.title
                summary = CascadeFormat.summary(CascadeWithSteps(c, parsed.steps))
                val shown = parsed.steps.take(8).mapIndexed { i, s ->
                    "${i + 1}. ${s.title} (${TimeFmt.human(s.durationInMillis)})"
                }
                val more = parsed.steps.size - shown.size
                details = (shown + (if (more > 0) listOf("e mais $more passos") else emptyList())).joinToString("\n")
                note = "Fica na aba Cascata, em Personalizados, e só arranca quando a iniciares. É uma cópia independente."
                button = "Importar para Cascata"
            }
        }

        findViewById<TextView>(R.id.tvImportKind).text = kind
        findViewById<TextView>(R.id.tvImportName).text = name
        findViewById<TextView>(R.id.tvImportSummary).text = summary
        findViewById<TextView>(R.id.tvImportDetails).text = details
        findViewById<TextView>(R.id.tvImportNote).text = note
        findViewById<MaterialButton>(R.id.btnImportConfirm).text = button
    }

    private fun confirm() {
        val toImport = item ?: return
        if (importing) return
        importing = true
        val appContext = applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            val db = AppDatabase.getDatabase(appContext)
            var tab = 0
            var sequential = true
            when (toImport) {
                is ShareCodec.Item.AlarmItem -> AlarmRepository(db.alarmDao()).insert(toImport.alarm)
                is ShareCodec.Item.SequentialItem -> {
                    CascadeRepository(db.cascadeDao()).saveCascade(toImport.cascade, emptyList())
                    tab = 1
                }
                is ShareCodec.Item.CascadeItem -> {
                    CascadeRepository(db.cascadeDao()).saveCascade(toImport.cascade, toImport.steps)
                    tab = 1
                    sequential = false
                }
            }
            withContext(Dispatchers.Main) {
                Toast.makeText(appContext, R.string.t_importado, Toast.LENGTH_SHORT).show()
                startActivity(
                    Intent(appContext, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        .putExtra(MainActivity.EXTRA_OPEN_TAB, tab)
                        .putExtra(MainActivity.EXTRA_OPEN_SEQUENTIAL, if (sequential) 1 else 0)
                )
                finish()
            }
        }
    }

    companion object {
        private const val EXTRA_PAYLOAD = "extra_payload"

        fun newIntent(context: Context, payload: String): Intent =
            Intent(context, ImportActivity::class.java).putExtra(EXTRA_PAYLOAD, payload)
    }
}
