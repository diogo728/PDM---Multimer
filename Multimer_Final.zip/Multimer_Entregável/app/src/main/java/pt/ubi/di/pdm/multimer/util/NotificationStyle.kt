package pt.ubi.di.pdm.multimer.util

import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import pt.ubi.di.pdm.multimer.R

/**
 * Aspeto das notificações, num só sítio para ser fácil de ajustar (versão experimental).
 *  - cor de marca e subtítulo que indica a origem (Alarme, Temporizador, Cascata)
 *  - barra de progresso nas contagens
 *  - notificações em curso coloridas a verde-escuro (desligar com [COLORIZE_RUNNING] = false)
 */
object NotificationStyle {

    /** Interruptor do estilo colorido das notificações em curso. */
    const val COLORIZE_RUNNING = true

    private const val PROGRESS_MAX = 1000

    /** Alertas (alarme a tocar, fim de temporizador, toque de cascata). */
    fun alert(ctx: Context, builder: NotificationCompat.Builder, subText: String): NotificationCompat.Builder {
        return builder
            .setColor(ContextCompat.getColor(ctx, R.color.accent))
            .setSubText(subText)
    }

    /** Contagens em curso (serviço em primeiro plano). */
    fun running(ctx: Context, builder: NotificationCompat.Builder, subText: String): NotificationCompat.Builder {
        builder.setSubText(subText)
        if (COLORIZE_RUNNING) {
            builder.setColor(ContextCompat.getColor(ctx, R.color.notif_running)).setColorized(true)
        } else {
            builder.setColor(ContextCompat.getColor(ctx, R.color.accent))
        }
        return builder
    }

    /** Barra de progresso de 0 a 1. */
    fun progress(builder: NotificationCompat.Builder, fraction: Float): NotificationCompat.Builder {
        val value = (fraction.coerceIn(0f, 1f) * PROGRESS_MAX).toInt()
        return builder.setProgress(PROGRESS_MAX, value, false)
    }
}
