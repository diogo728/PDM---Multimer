package pt.ubi.di.pdm.multimer.util

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/**
 * Toca som e/ou vibração. Em modo "loop" repete até [stop]; sem loop toca uma vez
 * (com um limite máximo) e chama [onFinished].
 */
class RingPlayer(context: Context) {

    private val appContext = context.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var rampStep = 0

    var onFinished: (() -> Unit)? = null

    private val audioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
        .build()

    private val finishRunnable = Runnable {
        stop()
        onFinished?.invoke()
    }

    private val rampRunnable = object : Runnable {
        override fun run() {
            val mp = player ?: return
            rampStep++
            val volume = (RAMP_START + (1f - RAMP_START) * rampStep / RAMP_STEPS).coerceAtMost(1f)
            try {
                mp.setVolume(volume, volume)
            } catch (e: Exception) {
                return
            }
            if (rampStep < RAMP_STEPS) handler.postDelayed(this, RAMP_INTERVAL_MS)
        }
    }

    val isActive: Boolean get() = player != null || vibrator != null

    fun start(
        soundUri: String?,
        vibrate: Boolean,
        loop: Boolean,
        gradualVolume: Boolean = false,
        maxDurationMs: Long = 0L
    ) {
        stop()
        val uri = SoundUtils.resolveUri(appContext, soundUri)
        if (uri != null) startSound(uri, loop, gradualVolume)
        if (vibrate) startVibration(loop)

        if (maxDurationMs > 0L) {
            handler.postDelayed(finishRunnable, maxDurationMs)
        } else if (!loop && player == null) {
            handler.postDelayed(finishRunnable, 1500L)
        }
    }

    fun stop() {
        handler.removeCallbacks(finishRunnable)
        handler.removeCallbacks(rampRunnable)
        player?.let {
            try {
                if (it.isPlaying) it.stop()
            } catch (e: Exception) {
                // ignorar
            }
            try {
                it.release()
            } catch (e: Exception) {
                // ignorar
            }
        }
        player = null
        vibrator?.cancel()
        vibrator = null
    }

    private fun startSound(uri: Uri, loop: Boolean, gradual: Boolean) {
        var mp = createPlayer(uri, loop, gradual)
        if (mp == null) {
            // Som em falta ou ilegível (por exemplo, um toque antigo do aparelho): usa o da app
            val fallback = SoundUtils.defaultUri(appContext)
            if (fallback != null && fallback != uri) mp = createPlayer(fallback, loop, gradual)
        }
        player = mp
        if (mp != null && gradual) {
            rampStep = 0
            handler.postDelayed(rampRunnable, RAMP_INTERVAL_MS)
        }
    }

    private fun createPlayer(uri: Uri, loop: Boolean, gradual: Boolean): MediaPlayer? {
        val mp = MediaPlayer()
        return try {
            mp.setAudioAttributes(audioAttributes)
            mp.setDataSource(appContext, uri)
            mp.isLooping = loop
            mp.prepare()
            if (gradual) mp.setVolume(RAMP_START, RAMP_START)
            if (!loop) {
                mp.setOnCompletionListener {
                    handler.post(finishRunnable)
                }
            }
            mp.start()
            mp
        } catch (e: Exception) {
            try {
                mp.release()
            } catch (ignored: Exception) {
            }
            null
        }
    }

    private fun startVibration(loop: Boolean) {
        val v = obtainVibrator() ?: return
        vibrator = v
        val effect = if (loop) {
            VibrationEffect.createWaveform(longArrayOf(0, 600, 400), 0)
        } else {
            VibrationEffect.createWaveform(longArrayOf(0, 500, 200, 500), -1)
        }
        try {
            @Suppress("DEPRECATION")
            v.vibrate(effect, audioAttributes)
        } catch (e: Exception) {
            // ignorar
        }
    }

    private fun obtainVibrator(): Vibrator? {
        val v: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            appContext.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
        return if (v != null && v.hasVibrator()) v else null
    }

    companion object {
        private const val RAMP_START = 0.15f
        private const val RAMP_STEPS = 40
        private const val RAMP_INTERVAL_MS = 500L
    }
}
