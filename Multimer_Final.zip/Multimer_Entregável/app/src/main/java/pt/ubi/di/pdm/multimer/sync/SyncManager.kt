package pt.ubi.di.pdm.multimer.sync

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import pt.ubi.di.pdm.multimer.data.local.AppDatabase
import pt.ubi.di.pdm.multimer.data.model.AlarmEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeWithSteps
import pt.ubi.di.pdm.multimer.data.model.TimerEntity
import pt.ubi.di.pdm.multimer.data.repository.CascadeRepository
import pt.ubi.di.pdm.multimer.data.repository.SyncIds
import pt.ubi.di.pdm.multimer.util.AlarmScheduler
import pt.ubi.di.pdm.multimer.util.Prefs
import pt.ubi.di.pdm.multimer.util.SoundLibrary
import pt.ubi.di.pdm.multimer.util.SoundUtils
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * Biblioteca conjunta entre os aparelhos de uma conta.
 *
 * A base de dados local continua a ser a única fonte de verdade: os alarmes tocam sem depender
 * da rede. Esta classe só reflete essa base na conta (e vice-versa) enquanto a app está aberta.
 *  - Local para a conta: itens com updatedAt > syncedAt são enviados; sem rede, o Firestore guarda
 *    a escrita em fila e envia-a quando houver ligação.
 *  - Conta para o local: ganha a alteração mais recente. O estado ligado/desligado NUNCA sincroniza:
 *    o que chega de outro aparelho entra desligado e o estado local mantém-se.
 *  - Eliminações viajam como "lápides" (deleted = true) para chegarem aos outros aparelhos.
 */
object SyncManager {

    const val ALARMS = "alarms"
    const val CASCADES = "cascades"
    const val TIMERS = "timers"
    private const val SETTINGS = "settings"
    private const val SETTINGS_DOC = "timer"

    enum class State {
        /** Sem conta iniciada. */
        SIGNED_OUT,
        /** Esta compilação não tem Firebase configurado (falta o google-services.json). */
        UNAVAILABLE,
        /** Há conteúdo neste aparelho e o utilizador ainda não escolheu se o envia. */
        CHOICE_PENDING,
        SYNCED,
        SYNCING,
        /** Sem internet: a sincronização retoma quando houver ligação. */
        OFFLINE_PENDING,
        PAUSED
    }

    private val _state = MutableStateFlow(State.SIGNED_OUT)
    val state: StateFlow<State> get() = _state

    private val lock = Any()
    private val applyMutex = Mutex()
    private var initialized = false
    private var appContext: Context? = null
    private var scope: CoroutineScope? = null
    private val registrations = ArrayList<ListenerRegistration>()
    private val inFlight = ConcurrentHashMap<String, Long>()

    private val dirtyAlarmCount = AtomicInteger(0)
    private val dirtyCascadeCount = AtomicInteger(0)
    private val dirtyTimerCount = AtomicInteger(0)
    @Volatile private var dirtyAlarms: List<AlarmEntity> = emptyList()
    @Volatile private var dirtyCascades: List<CascadeWithSteps> = emptyList()
    @Volatile private var dirtyTimers: List<TimerEntity> = emptyList()

    @Volatile private var online = true
    @Volatile private var started = false
    @Volatile private var activeUid: String? = null

    // ------------------------------------------------------------------ Arranque

    fun isAvailable(ctx: Context): Boolean =
        try {
            FirebaseApp.getApps(ctx.applicationContext).isNotEmpty()
        } catch (e: Exception) {
            false
        }

    /** Chamado uma vez ao abrir a app. Sem Firebase configurado, não faz nada e a app é só offline. */
    fun init(ctx: Context) {
        if (initialized) return
        initialized = true
        appContext = ctx.applicationContext
        if (!isAvailable(ctx)) {
            _state.value = State.UNAVAILABLE
            return
        }
        registerNetwork(ctx.applicationContext)
        FirebaseAuth.getInstance().addAuthStateListener { onAuthChanged() }
    }

    private fun registerNetwork(ctx: Context) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return
        online = cm.activeNetwork != null
        try {
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    online = true
                    if (started) syncNow() else recomputeState()
                }

                override fun onLost(network: Network) {
                    online = false
                    recomputeState()
                }
            })
        } catch (e: Exception) {
            // sem permissão de estado da rede: assume-se que há ligação
        }
    }

    private fun currentUser(): FirebaseUser? {
        val ctx = appContext ?: return null
        if (!isAvailable(ctx)) return null
        return try {
            FirebaseAuth.getInstance().currentUser?.takeIf { !it.isAnonymous }
        } catch (e: Exception) {
            null
        }
    }

    private fun onAuthChanged() {
        val ctx = appContext ?: return
        val user = currentUser()
        if (user == null) {
            stopSync()
            _state.value = State.SIGNED_OUT
            return
        }
        CoroutineScope(Dispatchers.IO).launch {
            when {
                Prefs.syncChoiceMade(ctx, user.uid) -> start(user.uid)
                localItemCount(ctx) == 0 -> {
                    Prefs.setSyncChoiceMade(ctx, user.uid)
                    start(user.uid)
                }
                else -> {
                    stopSync()
                    _state.value = State.CHOICE_PENDING
                }
            }
        }
    }

    private suspend fun localItemCount(ctx: Context): Int {
        val db = AppDatabase.getDatabase(ctx)
        return db.alarmDao().count() + db.cascadeDao().count() + db.timerDao().count()
    }

    /** Quantos itens guardados neste aparelho seriam enviados para a conta. */
    suspend fun localCount(): Int = appContext?.let { localItemCount(it) } ?: 0

    /** O utilizador decidiu se envia para a conta o que já tinha neste aparelho. */
    fun confirmUploadChoice(upload: Boolean) {
        val ctx = appContext ?: return
        val uid = currentUser()?.uid ?: return
        CoroutineScope(Dispatchers.IO).launch {
            if (!upload) {
                // Fica só neste aparelho: marca como já sincronizado para não ser enviado
                val db = AppDatabase.getDatabase(ctx)
                db.alarmDao().markAllSynced()
                db.cascadeDao().markAllSynced()
                db.timerDao().markAllSynced()
            }
            Prefs.setSyncChoiceMade(ctx, uid)
            start(uid)
        }
    }

    fun setPaused(paused: Boolean) {
        val ctx = appContext ?: return
        if (currentUser() == null) return
        Prefs.setSyncPaused(ctx, paused)
        if (paused) {
            stopSync()
            _state.value = State.PAUSED
        } else {
            onAuthChanged()
        }
    }

    private fun start(uid: String) {
        val ctx = appContext ?: return
        synchronized(lock) {
            if (started && activeUid == uid) return
            stopLocked()
            if (Prefs.syncPaused(ctx)) {
                _state.value = State.PAUSED
                return
            }
            started = true
            activeUid = uid
            val s = CoroutineScope(SupervisorJob() + Dispatchers.IO)
            scope = s
            val db = AppDatabase.getDatabase(ctx)

            flushPendingDeletes(ctx, uid)

            // Conta -> local
            registrations.add(userCol(uid, ALARMS).addSnapshotListener { snap, err ->
                if (err != null || snap == null) return@addSnapshotListener
                s.launch {
                    for (change in snap.documentChanges) {
                        if (change.type == DocumentChange.Type.REMOVED || change.document.metadata.hasPendingWrites()) continue
                        applyMutex.withLock { applyAlarm(ctx, change.document) }
                    }
                }
            })
            registrations.add(userCol(uid, CASCADES).addSnapshotListener { snap, err ->
                if (err != null || snap == null) return@addSnapshotListener
                s.launch {
                    for (change in snap.documentChanges) {
                        if (change.type == DocumentChange.Type.REMOVED || change.document.metadata.hasPendingWrites()) continue
                        applyMutex.withLock { applyCascade(ctx, change.document) }
                    }
                }
            })
            registrations.add(userCol(uid, TIMERS).addSnapshotListener { snap, err ->
                if (err != null || snap == null) return@addSnapshotListener
                s.launch {
                    for (change in snap.documentChanges) {
                        if (change.type == DocumentChange.Type.REMOVED || change.document.metadata.hasPendingWrites()) continue
                        applyMutex.withLock { applyTimer(ctx, change.document) }
                    }
                }
            })
            registrations.add(userCol(uid, SETTINGS).document(SETTINGS_DOC).addSnapshotListener { snap, err ->
                if (err != null || snap == null) return@addSnapshotListener
                s.launch { applyMutex.withLock { applySettings(ctx, uid, snap) } }
            })

            // Local -> conta
            s.launch {
                db.alarmDao().observeDirty().collect { list ->
                    dirtyAlarms = list
                    dirtyAlarmCount.set(list.size)
                    list.forEach { pushAlarm(uid, it) }
                    recomputeState()
                }
            }
            s.launch {
                db.cascadeDao().observeDirty().collect { list ->
                    dirtyCascades = list
                    dirtyCascadeCount.set(list.size)
                    list.forEach { pushCascade(uid, it) }
                    recomputeState()
                }
            }
            s.launch {
                db.timerDao().observeDirty().collect { list ->
                    dirtyTimers = list
                    dirtyTimerCount.set(list.size)
                    list.forEach { pushTimer(uid, it) }
                    recomputeState()
                }
            }
        }
        recomputeState()
    }

    /** Pára a sincronização (o conteúdo local fica como está). */
    fun stopSync() {
        synchronized(lock) { stopLocked() }
    }

    private fun stopLocked() {
        registrations.forEach { it.remove() }
        registrations.clear()
        scope?.cancel()
        scope = null
        started = false
        activeUid = null
        inFlight.clear()
        dirtyAlarmCount.set(0)
        dirtyCascadeCount.set(0)
        dirtyTimerCount.set(0)
    }

    private fun recomputeState() {
        val ctx = appContext ?: return
        if (!started) return
        _state.value = when {
            Prefs.syncPaused(ctx) -> State.PAUSED
            !online -> State.OFFLINE_PENDING
            dirtyAlarmCount.get() + dirtyCascadeCount.get() + dirtyTimerCount.get() > 0 -> State.SYNCING
            else -> State.SYNCED
        }
    }

    /** Volta a tentar enviar tudo o que está por enviar. */
    fun syncNow() {
        val uid = activeUid ?: return
        inFlight.clear()
        dirtyAlarms.forEach { pushAlarm(uid, it) }
        dirtyCascades.forEach { pushCascade(uid, it) }
        dirtyTimers.forEach { pushTimer(uid, it) }
        pushSettings(uid, onlyIfNewer = false)
        recomputeState()
    }

    // ------------------------------------------------------------------ Local -> conta

    private fun userCol(uid: String, name: String): CollectionReference =
        FirebaseFirestore.getInstance().collection("users").document(uid).collection(name)

    private fun pushAlarm(uid: String, a: AlarmEntity) {
        if (a.syncId.isBlank()) return
        val key = "$ALARMS/${a.syncId}"
        if (inFlight[key] == a.updatedAt) return
        inFlight[key] = a.updatedAt
        val ctx = appContext ?: return
        userCol(uid, ALARMS).document(a.syncId).set(SyncMapper.alarmToMap(a))
            .addOnSuccessListener {
                scope?.launch {
                    AppDatabase.getDatabase(ctx).alarmDao().markSynced(a.syncId, a.updatedAt)
                    inFlight.remove(key)
                }
            }
            .addOnFailureListener { inFlight.remove(key) }
    }

    private fun pushCascade(uid: String, item: CascadeWithSteps) {
        val c = item.cascade
        if (c.syncId.isBlank()) return
        val key = "$CASCADES/${c.syncId}"
        if (inFlight[key] == c.updatedAt) return
        inFlight[key] = c.updatedAt
        val ctx = appContext ?: return
        userCol(uid, CASCADES).document(c.syncId).set(SyncMapper.cascadeToMap(c, item.steps))
            .addOnSuccessListener {
                scope?.launch {
                    AppDatabase.getDatabase(ctx).cascadeDao().markSynced(c.syncId, c.updatedAt)
                    inFlight.remove(key)
                }
            }
            .addOnFailureListener { inFlight.remove(key) }
    }

    private fun pushTimer(uid: String, t: TimerEntity) {
        if (t.syncId.isBlank()) return
        val key = "$TIMERS/${t.syncId}"
        if (inFlight[key] == t.updatedAt) return
        inFlight[key] = t.updatedAt
        val ctx = appContext ?: return
        userCol(uid, TIMERS).document(t.syncId).set(SyncMapper.timerToMap(t))
            .addOnSuccessListener {
                scope?.launch {
                    AppDatabase.getDatabase(ctx).timerDao().markSynced(t.syncId, t.updatedAt)
                    inFlight.remove(key)
                }
            }
            .addOnFailureListener { inFlight.remove(key) }
    }

    private fun pushSettings(uid: String, onlyIfNewer: Boolean = true) {
        val ctx = appContext ?: return
        val updated = Prefs.timerSettingsUpdatedAt(ctx)
        if (onlyIfNewer && updated <= 0L) return
        userCol(uid, SETTINGS).document(SETTINGS_DOC).set(
            SyncMapper.settingsToMap(
                Prefs.timerSoundUri(ctx), Prefs.timerVibrate(ctx), Prefs.timerAutoStop(ctx), updated
            )
        )
    }

    /** As definições do temporizador mudaram neste aparelho. */
    fun notifySettingsChanged() {
        val uid = activeUid ?: return
        pushSettings(uid)
    }

    // ------------------------------------------------------------------ Eliminações

    /** Chamado quando o utilizador elimina um item: propaga-se aos outros aparelhos. */
    fun onLocalDelete(collection: String, syncId: String) {
        val ctx = appContext ?: return
        val uid = currentUser()?.uid ?: return // sem conta não há nada a propagar
        if (started && activeUid == uid) {
            writeTombstone(uid, collection, syncId)
        } else {
            Prefs.addPendingDelete(ctx, "$uid|$collection|$syncId")
        }
    }

    private fun writeTombstone(uid: String, collection: String, syncId: String) {
        userCol(uid, collection).document(syncId).set(SyncMapper.tombstone(SyncIds.now()))
    }

    private fun flushPendingDeletes(ctx: Context, uid: String) {
        for (entry in Prefs.pendingDeletes(ctx)) {
            val parts = entry.split("|")
            if (parts.size == 3 && parts[0] == uid) {
                writeTombstone(uid, parts[1], parts[2])
                Prefs.removePendingDelete(ctx, entry)
            }
        }
    }

    // ------------------------------------------------------------------ Conta -> local

    private suspend fun applyAlarm(ctx: Context, doc: DocumentSnapshot) {
        val dao = AppDatabase.getDatabase(ctx).alarmDao()
        val syncId = doc.id
        val remoteUpdated = doc.getLong("updatedAt") ?: return
        val local = dao.getBySyncId(syncId)

        if (doc.getBoolean("deleted") == true) {
            if (local != null && remoteUpdated >= local.updatedAt) {
                AlarmScheduler.cancelAlarm(ctx, local)
                dao.deleteBySyncId(syncId)
            }
            return
        }
        if (local != null && local.updatedAt >= remoteUpdated) return // o local é igual ou mais recente

        val parsed = SyncMapper.alarmFrom(doc) ?: return
        if (local == null) {
            // Vindo de outro aparelho: entra sempre DESLIGADO
            dao.insertAlarm(parsed.copy(isEnabled = false, syncId = syncId, updatedAt = remoteUpdated, syncedAt = remoteUpdated))
        } else {
            // O estado ligado/desligado é deste aparelho; se estiver ligado, reagenda com a nova hora
            val updated = parsed.copy(
                id = local.id, isEnabled = local.isEnabled,
                syncId = syncId, updatedAt = remoteUpdated, syncedAt = remoteUpdated
            )
            dao.updateAlarm(updated)
            if (updated.isEnabled) AlarmScheduler.scheduleAlarm(ctx, updated)
        }
    }

    private suspend fun applyCascade(ctx: Context, doc: DocumentSnapshot) {
        val dao = AppDatabase.getDatabase(ctx).cascadeDao()
        val syncId = doc.id
        val remoteUpdated = doc.getLong("updatedAt") ?: return
        val local = dao.getBySyncId(syncId)

        if (doc.getBoolean("deleted") == true) {
            if (local != null && remoteUpdated >= local.cascade.updatedAt) dao.deleteBySyncId(syncId)
            return
        }
        if (local != null && local.cascade.updatedAt >= remoteUpdated) return

        val (cascade, steps) = SyncMapper.cascadeFrom(doc) ?: return
        CascadeRepository(dao).applyRemote(
            cascade.copy(
                id = local?.cascade?.id ?: 0L,
                syncId = syncId, updatedAt = remoteUpdated, syncedAt = remoteUpdated
            ),
            steps
        )
    }

    private suspend fun applyTimer(ctx: Context, doc: DocumentSnapshot) {
        val dao = AppDatabase.getDatabase(ctx).timerDao()
        val syncId = doc.id
        val remoteUpdated = doc.getLong("updatedAt") ?: return
        val local = dao.getBySyncId(syncId)

        if (doc.getBoolean("deleted") == true) {
            if (local != null && remoteUpdated >= local.updatedAt) dao.deleteBySyncId(syncId)
            return
        }
        if (local != null && local.updatedAt >= remoteUpdated) return

        val parsed = SyncMapper.timerFrom(doc) ?: return
        dao.insertTimer(parsed.copy(id = local?.id ?: 0L, syncId = syncId, updatedAt = remoteUpdated, syncedAt = remoteUpdated))
    }

    private fun applySettings(ctx: Context, uid: String, snap: DocumentSnapshot) {
        if (snap.metadata.hasPendingWrites()) return
        val localUpdated = Prefs.timerSettingsUpdatedAt(ctx)
        val remoteUpdated = if (snap.exists()) snap.getLong("updatedAt") ?: 0L else -1L
        when {
            remoteUpdated > localUpdated -> {
                val sound = snap.getString("sound")?.takeIf { it == SoundUtils.SILENT || SoundLibrary.find(it) != null }
                Prefs.applyRemoteTimerSettings(
                    ctx, sound, snap.getBoolean("vibrate") ?: true, snap.getBoolean("autoStop") ?: false, remoteUpdated
                )
            }
            localUpdated > 0L && localUpdated > remoteUpdated -> pushSettings(uid)
        }
    }

    // ------------------------------------------------------------------ Eliminar conta

    /** Apaga da conta tudo o que foi sincronizado (usado ao eliminar a conta). */
    suspend fun deleteRemoteData(uid: String) {
        val fs = FirebaseFirestore.getInstance()
        for (name in listOf(ALARMS, CASCADES, TIMERS)) {
            val docs = userCol(uid, name).get().await().documents
            for (chunk in docs.chunked(400)) {
                val batch = fs.batch()
                chunk.forEach { batch.delete(it.reference) }
                batch.commit().await()
            }
        }
        userCol(uid, SETTINGS).document(SETTINGS_DOC).delete().await()
    }
}
