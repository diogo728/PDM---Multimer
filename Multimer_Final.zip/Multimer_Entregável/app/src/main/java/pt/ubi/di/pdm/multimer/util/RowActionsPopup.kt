package pt.ubi.di.pdm.multimer.util

import android.annotation.SuppressLint
import android.graphics.Rect
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import androidx.core.content.ContextCompat
import pt.ubi.di.pdm.multimer.R

/**
 * Menu flutuante de toque longo: um cartão arredondado que surge junto ao dedo,
 * com animação suave. Substitui o menu de sistema por algo mais próximo do resto da app.
 */
object RowActionsPopup {

    class Action(
        val label: String,
        val iconRes: Int,
        val destructive: Boolean = false,
        val onClick: () -> Unit
    )

    /** Liga o toque longo a [target]; [actions] é avaliado no momento em que o menu abre. */
    @SuppressLint("ClickableViewAccessibility")
    fun attach(target: View, actions: () -> List<Action>) {
        var rawX = 0f
        var rawY = 0f
        target.setOnTouchListener { _, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                rawX = event.rawX
                rawY = event.rawY
            }
            false
        }
        target.setOnLongClickListener { v ->
            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            show(v, rawX.toInt(), rawY.toInt(), actions())
            true
        }
    }

    private fun show(anchor: View, rawX: Int, rawY: Int, actions: List<Action>) {
        if (actions.isEmpty()) return
        val ctx = anchor.context
        val density = ctx.resources.displayMetrics.density
        val inflater = LayoutInflater.from(ctx)

        val content = LinearLayout(ctx)
        content.orientation = LinearLayout.VERTICAL
        content.setBackgroundResource(R.drawable.bg_popup)
        content.clipToOutline = true

        val popup = PopupWindow(content, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        popup.setBackgroundDrawable(ContextCompat.getDrawable(ctx, R.drawable.bg_popup))
        popup.elevation = 18f * density
        popup.animationStyle = R.style.Animation_Multimer_Popup
        popup.isOutsideTouchable = true

        actions.forEachIndexed { index, action ->
            val row = inflater.inflate(R.layout.item_popup_action, content, false)
            val color = ContextCompat.getColor(ctx, if (action.destructive) R.color.destructive else R.color.text_primary)
            row.findViewById<ImageView>(R.id.ivPopupIcon).apply {
                setImageResource(action.iconRes)
                setColorFilter(color)
            }
            row.findViewById<TextView>(R.id.tvPopupLabel).apply {
                text = action.label
                setTextColor(color)
            }
            row.setOnClickListener {
                popup.dismiss()
                action.onClick()
            }
            content.addView(row)
            if (index < actions.size - 1) {
                val divider = View(ctx)
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
                lp.marginStart = (16 * density).toInt()
                divider.layoutParams = lp
                divider.setBackgroundColor(ContextCompat.getColor(ctx, R.color.separator))
                content.addView(divider)
            }
        }

        content.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = content.measuredWidth
        val h = content.measuredHeight

        // Posição: centrado no dedo, preferindo aparecer por cima; nunca fora do ecrã
        val screen = Rect()
        anchor.getWindowVisibleDisplayFrame(screen)
        val margin = (12 * density).toInt()
        val gap = (14 * density).toInt()
        val x = (rawX - w / 2).coerceIn(screen.left + margin, maxOf(screen.left + margin, screen.right - w - margin))
        var y = rawY - h - gap
        if (y < screen.top + margin) y = rawY + gap
        y = y.coerceAtMost(screen.bottom - h - margin)

        popup.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y)
    }
}
