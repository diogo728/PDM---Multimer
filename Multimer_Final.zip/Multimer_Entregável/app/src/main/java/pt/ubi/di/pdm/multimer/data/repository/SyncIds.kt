package pt.ubi.di.pdm.multimer.data.repository

import java.util.UUID

object SyncIds {
    fun newId(): String = UUID.randomUUID().toString()
    fun now(): Long = System.currentTimeMillis()
}
