package pt.ubi.di.pdm.multimer.ui.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import pt.ubi.di.pdm.multimer.R

/** Linha fina entre linhas de uma lista, com recuo à esquerda (como nas listas do iOS). */
class InsetDividerDecoration(context: Context, insetDp: Int = 16) : RecyclerView.ItemDecoration() {
    private val density = context.resources.displayMetrics.density
    private val insetPx = insetDp * density
    private val paint = Paint().apply {
        color = ContextCompat.getColor(context, R.color.separator)
        strokeWidth = maxOf(1f, 0.5f * density)
    }

    override fun onDraw(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
        val count = parent.childCount
        for (i in 0 until count - 1) {
            val child = parent.getChildAt(i)
            val y = child.bottom + child.translationY
            c.drawLine(child.left + insetPx, y, child.right.toFloat(), y, paint)
        }
    }
}
