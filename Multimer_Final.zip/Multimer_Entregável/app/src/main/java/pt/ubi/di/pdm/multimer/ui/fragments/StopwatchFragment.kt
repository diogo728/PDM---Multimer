package pt.ubi.di.pdm.multimer.ui.fragments

import android.content.res.ColorStateList
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import pt.ubi.di.pdm.multimer.MainActivity
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.ui.adapter.LapAdapter
import pt.ubi.di.pdm.multimer.ui.view.InsetDividerDecoration
import pt.ubi.di.pdm.multimer.util.StopwatchStore
import pt.ubi.di.pdm.multimer.util.TimeFmt
import pt.ubi.di.pdm.multimer.util.addSpringPressAnimation

/**
 * Cronómetro. O estado vive em [StopwatchStore], por isso não se perde ao mudar de aba.
 * O modo de foco mostra só os números, em ecrã inteiro, para ter como referência ao estudar.
 */
class StopwatchFragment : Fragment() {

    private lateinit var tvTime: TextView
    private lateinit var tvFocusTime: TextView
    private lateinit var tvFocusHint: TextView
    private lateinit var btnLap: MaterialButton
    private lateinit var btnStartStop: MaterialButton
    private lateinit var cardLaps: View
    private lateinit var layoutFocus: View
    private lateinit var lapAdapter: LapAdapter
    private lateinit var focusBackCallback: OnBackPressedCallback
    private var focusMode = false

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(STATE_FOCUS, focusMode)
    }

    private val ticker = object : Runnable {
        override fun run() {
            updateTime()
            if (StopwatchStore.isRunning) view?.postOnAnimation(this)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_stopwatch, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        StopwatchStore.load(requireContext())

        tvTime = view.findViewById(R.id.tvStopwatchTime)
        tvFocusTime = view.findViewById(R.id.tvFocusTime)
        tvFocusHint = view.findViewById(R.id.tvFocusHint)
        btnLap = view.findViewById(R.id.btnLap)
        btnStartStop = view.findViewById(R.id.btnStartStop)
        cardLaps = view.findViewById(R.id.cardLaps)
        layoutFocus = view.findViewById(R.id.layoutFocus)

        lapAdapter = LapAdapter()
        val rv = view.findViewById<RecyclerView>(R.id.rvLaps)
        rv.layoutManager = LinearLayoutManager(requireContext())
        rv.adapter = lapAdapter
        rv.addItemDecoration(InsetDividerDecoration(requireContext()))

        btnStartStop.addSpringPressAnimation()
        btnLap.addSpringPressAnimation()

        btnStartStop.setOnClickListener { toggle() }
        btnLap.setOnClickListener {
            if (StopwatchStore.isRunning) {
                StopwatchStore.lap(requireContext())
            } else {
                StopwatchStore.reset(requireContext())
            }
            render()
        }

        focusBackCallback = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() = setFocus(false)
        }
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner, focusBackCallback)

        view.findViewById<View>(R.id.btnFocus).setOnClickListener { setFocus(true) }
        view.findViewById<View>(R.id.btnExitFocus).setOnClickListener { setFocus(false) }
        layoutFocus.setOnClickListener { toggle() }

        render()
        if (savedInstanceState?.getBoolean(STATE_FOCUS, false) == true) setFocus(true)
    }

    private fun toggle() {
        val ctx = requireContext()
        if (StopwatchStore.isRunning) StopwatchStore.pause(ctx) else StopwatchStore.start(ctx)
        render()
    }

    private fun setFocus(enabled: Boolean) {
        focusMode = enabled
        layoutFocus.visibility = if (enabled) View.VISIBLE else View.GONE
        focusBackCallback.isEnabled = enabled
        (activity as? MainActivity)?.setFocusMode(enabled)
        render()
    }

    private fun style(button: MaterialButton, bg: Int, fg: Int, text: String) {
        val c = requireContext()
        button.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(c, bg))
        button.setTextColor(ContextCompat.getColor(c, fg))
        button.text = text
    }

    private fun render() {
        if (!isAdded || view == null) return
        val running = StopwatchStore.isRunning
        val hasTime = StopwatchStore.hasTime

        if (running) {
            style(btnStartStop, R.color.destructive_soft, R.color.destructive, "Parar")
            style(btnLap, R.color.neutral_btn_bg, R.color.text_primary, "Volta")
            btnLap.isEnabled = true
            btnLap.alpha = 1f
            tvFocusHint.setText(R.string.t_toca_para_pausar)
        } else {
            style(btnStartStop, R.color.accent_soft, R.color.accent, if (hasTime) "Retomar" else "Iniciar")
            style(btnLap, R.color.neutral_btn_bg, R.color.text_primary, if (hasTime) "Repor" else "Volta")
            btnLap.isEnabled = hasTime
            btnLap.alpha = if (hasTime) 1f else 0.4f
            tvFocusHint.text = if (hasTime) "Toca para retomar" else "Toca para iniciar"
        }

        val laps = StopwatchStore.laps()
        lapAdapter.submit(laps)
        cardLaps.visibility = if (laps.isEmpty()) View.GONE else View.VISIBLE

        view?.keepScreenOn = running
        updateTime()
        view?.removeCallbacks(ticker)
        if (running) view?.postOnAnimation(ticker)
    }

    private fun updateTime() {
        val text = TimeFmt.stopwatch(StopwatchStore.elapsedMs())
        tvTime.text = text
        tvFocusTime.text = text
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    override fun onPause() {
        view?.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroyView() {
        (activity as? MainActivity)?.setFocusMode(false)
        super.onDestroyView()
    }

    companion object {
        private const val STATE_FOCUS = "state_focus"
    }
}
