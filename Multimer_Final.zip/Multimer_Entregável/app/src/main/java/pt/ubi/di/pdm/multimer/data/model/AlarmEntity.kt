package pt.ubi.di.pdm.multimer.data.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "alarms")
data class AlarmEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val hour: Int,
    val minute: Int,
    val isEnabled: Boolean = true,
    val label: String = "",
    val repeatDays: String = "", // "Uma vez", "Todos os dias" ou "Seg, Qua, Sex"
    val isVibrationEnabled: Boolean = true,
    val soundUri: String? = null, // null = toque padrão, "silent" = sem som
    val soundTitle: String = "Toque padrão",
    @ColumnInfo(defaultValue = "1")
    val isSnoozeEnabled: Boolean = true,
    @ColumnInfo(defaultValue = "10")
    val snoozeMinutes: Int = 10,
    @ColumnInfo(defaultValue = "1")
    val isGradualVolume: Boolean = true,
    // --- Sincronização com a conta (ver sync/SyncManager) ---
    @ColumnInfo(defaultValue = "''")
    val syncId: String = "",       // identificador único, igual em todos os aparelhos
    @ColumnInfo(defaultValue = "0")
    val updatedAt: Long = 0L,      // última alteração da definição
    @ColumnInfo(defaultValue = "0")
    val syncedAt: Long = 0L        // última versão já enviada/recebida
)
