package pt.ubi.di.pdm.multimer.sync

import android.content.Context
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthRecentLoginRequiredException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import kotlinx.coroutines.tasks.await
import pt.ubi.di.pdm.multimer.util.Prefs

/** Contas por e-mail e palavra-passe. Tudo opcional: a app funciona sem conta. */
object AuthManager {

    fun available(ctx: Context): Boolean = SyncManager.isAvailable(ctx)

    private fun auth(): FirebaseAuth = FirebaseAuth.getInstance()

    fun currentUser(ctx: Context): FirebaseUser? {
        if (!available(ctx)) return null
        return try {
            auth().currentUser?.takeIf { !it.isAnonymous }
        } catch (e: Exception) {
            null
        }
    }

    fun displayName(user: FirebaseUser): String =
        user.displayName?.takeIf { it.isNotBlank() } ?: user.email?.substringBefore('@') ?: "Conta"

    suspend fun signIn(email: String, password: String) {
        auth().signInWithEmailAndPassword(email.trim(), password).await()
    }

    suspend fun register(name: String, email: String, password: String) {
        val result = auth().createUserWithEmailAndPassword(email.trim(), password).await()
        val user = result.user ?: return
        user.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name.trim()).build()).await()
        user.reload().await()
    }

    suspend fun sendPasswordReset(email: String) {
        auth().sendPasswordResetEmail(email.trim()).await()
    }

    fun signOut() {
        auth().signOut()
    }

    /** Apaga os dados da conta no servidor e a própria conta. O conteúdo deste aparelho fica. */
    suspend fun deleteAccount(ctx: Context, password: String) {
        val user = auth().currentUser ?: return
        val email = user.email ?: return
        user.reauthenticate(EmailAuthProvider.getCredential(email, password)).await()
        SyncManager.stopSync()
        SyncManager.deleteRemoteData(user.uid)
        user.delete().await()
        Prefs.clearSyncChoice(ctx, user.uid)
    }

    fun friendlyError(e: Throwable): String = when (e) {
        is FirebaseAuthWeakPasswordException -> "A palavra-passe é fraca. Usa pelo menos 6 caracteres."
        is FirebaseAuthInvalidCredentialsException -> "E-mail ou palavra-passe incorretos."
        is FirebaseAuthInvalidUserException -> "Não existe nenhuma conta com este e-mail."
        is FirebaseAuthUserCollisionException -> "Já existe uma conta com este e-mail."
        is FirebaseNetworkException -> "Sem ligação à internet. Tenta de novo quando houver rede."
        is FirebaseTooManyRequestsException -> "Demasiadas tentativas. Aguarda um pouco e tenta de novo."
        is FirebaseAuthRecentLoginRequiredException -> "Por segurança, volta a iniciar sessão e tenta de novo."
        else -> "Não foi possível concluir. Verifica os dados e tenta de novo."
    }
}
