package pt.ubi.di.pdm.multimer.util

import android.content.Context
import java.util.Locale

object TimeFmt {

    /** A app usa sempre o formato de 00 a 23 horas. */
    fun clock(ctx: Context, hour: Int, minute: Int): String =
        String.format(Locale.getDefault(), "%02d:%02d", hour, minute)

    fun clockWithSuffix(ctx: Context, hour: Int, minute: Int): String = clock(ctx, hour, minute)

    /** Contagem decrescente: arredonda para cima ("00:01" até chegar mesmo a zero). */
    fun countdown(ms: Long): String {
        val totalSec = (ms.coerceAtLeast(0L) + 999L) / 1000L
        return hms(totalSec)
    }

    /** Tempo decorrido: arredonda para baixo. */
    fun elapsed(ms: Long): String = hms(ms.coerceAtLeast(0L) / 1000L)

    private fun hms(totalSec: Long): String {
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return if (h > 0) String.format(Locale.getDefault(), "%d:%02d:%02d", h, m, s)
        else String.format(Locale.getDefault(), "%02d:%02d", m, s)
    }

    /** Cronómetro: "12:34,56" ou "1:02:34,56". */
    fun stopwatch(ms: Long): String {
        val v = ms.coerceAtLeast(0L)
        val cs = (v % 1000) / 10
        return elapsed(v) + String.format(Locale.getDefault(), ",%02d", cs)
    }

    /** "1 h 20 min 30 s", omitindo as partes a zero. */
    fun human(ms: Long): String {
        val totalSec = (ms.coerceAtLeast(0L) + 500L) / 1000L
        if (totalSec == 0L) return "0 s"
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        val parts = mutableListOf<String>()
        if (h > 0) parts.add("$h h")
        if (m > 0) parts.add("$m min")
        if (s > 0) parts.add("$s s")
        return parts.joinToString(" ")
    }
}
