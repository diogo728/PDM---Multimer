package pt.ubi.di.pdm.multimer.ui.viewmodel

import androidx.lifecycle.*
import kotlinx.coroutines.launch
import pt.ubi.di.pdm.multimer.data.model.CascadeEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeStepEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeWithSteps
import pt.ubi.di.pdm.multimer.data.repository.CascadeRepository

class CascadeViewModel(private val repository: CascadeRepository) : ViewModel() {

    val allCascades = repository.allCascadesWithSteps.asLiveData()

    fun saveCascade(cascade: CascadeEntity, steps: List<CascadeStepEntity>, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.saveCascade(cascade, steps)
            onSaved(id)
        }
    }

    fun deleteCascade(cascade: CascadeEntity) {
        viewModelScope.launch { repository.deleteCascade(cascade) }
    }

    fun loadCascade(id: Long, onLoaded: (CascadeWithSteps?) -> Unit) {
        viewModelScope.launch { onLoaded(repository.getCascadeById(id)) }
    }
}

class CascadeViewModelFactory(private val repository: CascadeRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CascadeViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return CascadeViewModel(repository) as T
        }
        throw IllegalArgumentException("Classe ViewModel desconhecida")
    }
}
