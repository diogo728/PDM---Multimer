package pt.ubi.di.pdm.multimer.util

import android.content.Context
import android.net.Uri
import java.util.Locale

/**
 * Biblioteca de toques integrada na app (ficheiros em res/raw), independente dos sons do aparelho.
 * Organizada por duração para cada toque ser usado no contexto certo.
 */
object SoundLibrary {

    enum class Category(val label: String, val hint: String) {
        SHORT("Curtos", "Até 3 segundos. Ideais para toques repetidos e passos rápidos."),
        MEDIUM("Médios", "Alguns segundos. Bons para temporizadores e passos de uma receita."),
        LONG("Longos", "Meio minuto no máximo. Pensados para alarmes de despertar.")
    }

    class Sound(
        val key: String,
        val title: String,
        val category: Category,
        val seconds: Float
    ) {
        /** Nome do ficheiro em res/raw. */
        val resName: String get() = key.removePrefix(PREFIX)

        val durationLabel: String
            get() = if (seconds < 10f) String.format(Locale.getDefault(), "%.1f s", seconds)
            else String.format(Locale.getDefault(), "%d s", Math.round(seconds))
    }

    const val PREFIX = "builtin:"

    const val DEFAULT_ALARM = "builtin:snd_long_dawn"
    const val DEFAULT_TIMER = "builtin:snd_medium_chime"
    const val DEFAULT_STEP = "builtin:snd_short_bell"

    val all: List<Sound> = listOf(
        Sound("builtin:snd_short_drop", "Gota", Category.SHORT, 1.4f),
        Sound("builtin:snd_short_wood", "Madeira", Category.SHORT, 0.8f),
        Sound("builtin:snd_short_bell", "Sino", Category.SHORT, 2.3f),
        Sound("builtin:snd_short_beep", "Bip duplo", Category.SHORT, 1.3f),
        Sound("builtin:snd_short_marimba", "Marimba", Category.SHORT, 1.9f),

        Sound("builtin:snd_medium_chime", "Carrilhão", Category.MEDIUM, 7.7f),
        Sound("builtin:snd_medium_harp", "Harpa", Category.MEDIUM, 5.6f),
        Sound("builtin:snd_medium_ding", "Campainha", Category.MEDIUM, 7.7f),
        Sound("builtin:snd_medium_sonar", "Sonar", Category.MEDIUM, 8.0f),
        Sound("builtin:snd_medium_glass", "Cristal", Category.MEDIUM, 8.3f),

        Sound("builtin:snd_long_dawn", "Amanhecer", Category.LONG, 25.7f),
        Sound("builtin:snd_long_classic", "Clássico", Category.LONG, 20.7f),
        Sound("builtin:snd_long_digital", "Digital", Category.LONG, 18.4f),
        Sound("builtin:snd_long_windchimes", "Sinos de vento", Category.LONG, 29.9f),
        Sound("builtin:snd_long_rise", "Crescendo", Category.LONG, 23.0f)
    )

    fun byCategory(category: Category): List<Sound> = all.filter { it.category == category }

    fun find(stored: String?): Sound? = all.firstOrNull { it.key == stored }

    fun uriFor(ctx: Context, sound: Sound): Uri =
        Uri.parse("android.resource://" + ctx.packageName + "/raw/" + sound.resName)
}
