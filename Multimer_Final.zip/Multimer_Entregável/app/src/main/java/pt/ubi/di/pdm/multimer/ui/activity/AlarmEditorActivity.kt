package pt.ubi.di.pdm.multimer.ui.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.data.local.AppDatabase
import pt.ubi.di.pdm.multimer.data.model.AlarmEntity
import pt.ubi.di.pdm.multimer.data.repository.AlarmRepository
import pt.ubi.di.pdm.multimer.ui.fragments.SoundPickerSheet
import pt.ubi.di.pdm.multimer.ui.view.WheelPicker
import pt.ubi.di.pdm.multimer.ui.viewmodel.AlarmViewModel
import pt.ubi.di.pdm.multimer.ui.viewmodel.AlarmViewModelFactory
import pt.ubi.di.pdm.multimer.util.AlarmScheduler
import pt.ubi.di.pdm.multimer.util.ExactAlarms
import pt.ubi.di.pdm.multimer.util.RepeatDays
import pt.ubi.di.pdm.multimer.util.Segmented
import pt.ubi.di.pdm.multimer.util.SoundLibrary
import pt.ubi.di.pdm.multimer.util.SoundUtils
import pt.ubi.di.pdm.multimer.util.enableEdgeToEdge
import java.util.Calendar

class AlarmEditorActivity : AppCompatActivity() {

    private val viewModel: AlarmViewModel by lazy {
        val database = AppDatabase.getDatabase(this)
        val repository = AlarmRepository(database.alarmDao())
        ViewModelProvider(this, AlarmViewModelFactory(repository))[AlarmViewModel::class.java]
    }

    private val snoozeOptions = intArrayOf(5, 10, 15, 30)

    private var alarmId = -1L
    private var loadedSyncId = ""
    private var soundUri: String? = null
    private var soundTitle: String? = null

    private lateinit var wheelHour: WheelPicker
    private lateinit var wheelMinute: WheelPicker
    private lateinit var tvSound: TextView
    private lateinit var tvRepeat: TextView
    private lateinit var etLabel: EditText
    private lateinit var switchVibration: MaterialSwitch
    private lateinit var switchGradual: MaterialSwitch
    private lateinit var switchSnooze: MaterialSwitch
    private lateinit var snoozeLayout: View
    private lateinit var snoozeSegmented: Segmented
    private lateinit var dayViews: Map<String, TextView>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alarm_editor)
        enableEdgeToEdge()

        wheelHour = findViewById(R.id.wheelHour)
        wheelMinute = findViewById(R.id.wheelMinute)
        tvSound = findViewById(R.id.tvSelectedSound)
        tvRepeat = findViewById(R.id.tvRepeatSummary)
        etLabel = findViewById(R.id.etAlarmLabel)
        switchVibration = findViewById(R.id.switchVibration)
        switchGradual = findViewById(R.id.switchGradual)
        switchSnooze = findViewById(R.id.switchSnooze)
        snoozeLayout = findViewById(R.id.layoutSnoozeOptions)

        dayViews = mapOf(
            "Seg" to findViewById<TextView>(R.id.chipMon),
            "Ter" to findViewById<TextView>(R.id.chipTue),
            "Qua" to findViewById<TextView>(R.id.chipWed),
            "Qui" to findViewById<TextView>(R.id.chipThu),
            "Sex" to findViewById<TextView>(R.id.chipFri),
            "Sáb" to findViewById<TextView>(R.id.chipSat),
            "Dom" to findViewById<TextView>(R.id.chipSun)
        )
        dayViews.values.forEach { chip ->
            chip.setOnClickListener {
                chip.isSelected = !chip.isSelected
                updateRepeatSummary()
            }
        }

        snoozeSegmented = Segmented(
            listOf<View>(findViewById<View>(R.id.snooze5), findViewById<View>(R.id.snooze10), findViewById<View>(R.id.snooze15), findViewById<View>(R.id.snooze30))
        )
        snoozeSegmented.select(1)
        switchSnooze.setOnCheckedChangeListener { _, checked ->
            snoozeLayout.visibility = if (checked) View.VISIBLE else View.GONE
        }

        wheelHour.setNumberRange(0, 23)
        wheelMinute.setNumberRange(0, 59)

        val tvTitle = findViewById<TextView>(R.id.tvAlarmEditorTitle)
        val cardDelete = findViewById<View>(R.id.cardDeleteAlarm)

        alarmId = intent.getLongExtra(EXTRA_ALARM_ID, -1L)
        if (alarmId != -1L) {
            tvTitle.setText(R.string.t_editar_alarme)
            cardDelete.visibility = View.VISIBLE
            viewModel.loadAlarm(alarmId) { alarm -> if (alarm != null) populate(alarm) else finish() }
        } else {
            tvTitle.setText(R.string.t_novo_alarme)
            val now = Calendar.getInstance()
            setTime(now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE))
            soundUri = SoundLibrary.DEFAULT_ALARM
            soundTitle = SoundUtils.titleFor(this, soundUri)
            tvSound.text = soundTitle
            updateRepeatSummary()
        }

        supportFragmentManager.setFragmentResultListener(SoundPickerSheet.REQUEST_KEY, this) { _, b ->
            soundUri = b.getString(SoundPickerSheet.RESULT_VALUE)
            soundTitle = b.getString(SoundPickerSheet.RESULT_TITLE)
            tvSound.text = SoundUtils.titleFor(this, soundUri)
        }
        findViewById<View>(R.id.layoutSelectSound).setOnClickListener {
            SoundPickerSheet.newInstance(soundUri, SoundPickerSheet.CONTEXT_ALARM).show(supportFragmentManager, "sound_picker")
        }
        findViewById<MaterialButton>(R.id.btnCancelAlarmEditor).setOnClickListener { finish() }
        findViewById<MaterialButton>(R.id.btnSaveAlarmEditor).setOnClickListener { save() }
        findViewById<MaterialButton>(R.id.btnDeleteAlarmEditor).setOnClickListener {
            if (alarmId != -1L) {
                AlarmScheduler.cancelById(this, alarmId)
                viewModel.deleteAlarm(AlarmEntity(id = alarmId, hour = 0, minute = 0))
            }
            finish()
        }
    }

    private fun populate(alarm: AlarmEntity) {
        loadedSyncId = alarm.syncId
        setTime(alarm.hour, alarm.minute)
        etLabel.setText(alarm.label)
        switchVibration.isChecked = alarm.isVibrationEnabled
        switchGradual.isChecked = alarm.isGradualVolume
        switchSnooze.isChecked = alarm.isSnoozeEnabled
        snoozeLayout.visibility = if (alarm.isSnoozeEnabled) View.VISIBLE else View.GONE
        val idx = snoozeOptions.indexOf(alarm.snoozeMinutes)
        snoozeSegmented.select(if (idx >= 0) idx else 1)
        soundUri = alarm.soundUri
        soundTitle = SoundUtils.titleFor(this, alarm.soundUri)
        tvSound.text = soundTitle

        val days = RepeatDays.parse(alarm.repeatDays)
        dayViews.forEach { (code, view) -> view.isSelected = days.contains(code) }
        updateRepeatSummary()
    }

    private fun setTime(hour: Int, minute: Int) {
        wheelHour.value = hour
        wheelMinute.value = minute
    }

    private fun selectedHour(): Int = wheelHour.value

    private fun selectedDays(): Set<String> = dayViews.filter { it.value.isSelected }.keys

    private fun updateRepeatSummary() {
        tvRepeat.text = RepeatDays.describeSet(selectedDays())
    }

    private fun save() {
        val hour = selectedHour()
        val minute = wheelMinute.value
        val repeat = RepeatDays.toStorage(selectedDays())

        val alarm = AlarmEntity(
            id = if (alarmId != -1L) alarmId else 0L,
            hour = hour,
            minute = minute,
            isEnabled = true,
            label = etLabel.text.toString().trim(),
            repeatDays = repeat,
            isVibrationEnabled = switchVibration.isChecked,
            soundUri = soundUri,
            soundTitle = soundTitle ?: SoundUtils.titleFor(this, soundUri),
            isSnoozeEnabled = switchSnooze.isChecked,
            snoozeMinutes = snoozeOptions[snoozeSegmented.selectedIndex],
            isGradualVolume = switchGradual.isChecked,
            syncId = loadedSyncId
        )

        val appContext = applicationContext
        if (alarmId == -1L) {
            viewModel.insertAlarm(alarm) { newId -> AlarmScheduler.scheduleAlarm(appContext, alarm.copy(id = newId)) }
        } else {
            viewModel.updateAlarm(alarm)
            AlarmScheduler.scheduleAlarm(appContext, alarm)
        }

        if (!ExactAlarms.canScheduleExact(this)) {
            // Sem esta permissão o sistema pode atrasar o alarme vários minutos
            AlertDialog.Builder(this)
                .setTitle(R.string.t_alarme_pode_atrasar)
                .setMessage("Sem a permissão \"Alarmes e lembretes\", o Android pode adiar este alarme alguns minutos. Ativa-a para tocar à hora exata.")
                .setPositiveButton(R.string.t_abrir_definicoes) { _, _ ->
                    ExactAlarms.settingsIntent(this)?.let {
                        try {
                            startActivity(it)
                        } catch (e: Exception) {
                            // sem ecrã de definições disponível
                        }
                    }
                }
                .setNegativeButton(R.string.t_agora_nao, null)
                .setOnDismissListener { finish() }
                .show()
            return
        }

        Toast.makeText(this, AlarmScheduler.formatTimeUntil(hour, minute, repeat), Toast.LENGTH_SHORT).show()
        finish()
    }

    companion object {
        const val EXTRA_ALARM_ID = "extra_alarm_id"

        fun newIntent(context: Context, alarmId: Long = -1L): Intent {
            return Intent(context, AlarmEditorActivity::class.java).apply {
                putExtra(EXTRA_ALARM_ID, alarmId)
            }
        }
    }
}
