package pt.ubi.di.pdm.multimer.util

import android.text.Editable
import android.text.TextWatcher
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

/** Efeito de mola ao tocar (escala suavemente e volta com um ligeiro ressalto). */
fun View.addSpringPressAnimation(pressedScale: Float = 0.96f) {
    val scaleXAnim = SpringAnimation(this, SpringAnimation.SCALE_X, 1f).apply {
        spring = SpringForce().apply {
            stiffness = SpringForce.STIFFNESS_MEDIUM
            dampingRatio = SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY
        }
    }
    val scaleYAnim = SpringAnimation(this, SpringAnimation.SCALE_Y, 1f).apply {
        spring = SpringForce().apply {
            stiffness = SpringForce.STIFFNESS_MEDIUM
            dampingRatio = SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY
        }
    }

    setOnTouchListener { _, event ->
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                scaleXAnim.animateToFinalPosition(pressedScale)
                scaleYAnim.animateToFinalPosition(pressedScale)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                scaleXAnim.animateToFinalPosition(1f)
                scaleYAnim.animateToFinalPosition(1f)
            }
        }
        false
    }
}

fun View.dpToPx(dp: Int): Int = (dp * resources.displayMetrics.density).toInt()

/** Acrescenta aos paddings atuais o espaço das barras do sistema (e do teclado). */
fun View.applySystemBarsPadding(top: Boolean = true, bottom: Boolean = true) {
    val l = paddingLeft
    val t = paddingTop
    val r = paddingRight
    val b = paddingBottom
    ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
        val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
        v.setPadding(l + i.left, t + (if (top) i.top else 0), r + i.right, b + (if (bottom) i.bottom else 0))
        insets
    }
    ViewCompat.requestApplyInsets(this)
}

/** Ecrã de ponta a ponta. Chamar depois de setContentView. */
fun AppCompatActivity.enableEdgeToEdge() {
    WindowCompat.setDecorFitsSystemWindows(window, false)
    findViewById<ViewGroup>(android.R.id.content).getChildAt(0)?.applySystemBarsPadding()
}

fun EditText.onTextChanged(callback: (String) -> Unit) {
    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: Editable?) {
            callback(s?.toString() ?: "")
        }
    })
}
