package pt.ubi.di.pdm.multimer.ui.fragments

import android.content.res.ColorStateList
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.data.model.CascadeStepEntity
import pt.ubi.di.pdm.multimer.ui.view.WheelPicker
import pt.ubi.di.pdm.multimer.util.SoundLibrary
import pt.ubi.di.pdm.multimer.util.SoundUtils

/** Folha para criar ou editar um passo. O resultado volta por FragmentResult (sobrevive a rotações). */
class StepEditorSheet : BottomSheetDialogFragment() {

    private var position = -1
    private var soundUri: String? = null
    private var soundTitle: String? = null
    private lateinit var tvSound: TextView

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.sheet_step_editor, container, false)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(STATE_SOUND_URI, soundUri)
        outState.putString(STATE_SOUND_TITLE, soundTitle)
    }

    override fun onStart() {
        super.onStart()
        val dlg = dialog as? BottomSheetDialog ?: return
        dlg.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dlg.behavior.skipCollapsed = true
        dlg.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.backgroundTintList =
            ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.bg_grouped))
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val args = requireArguments()
        position = args.getInt(ARG_POSITION, -1)
        val defaultTitle = args.getString(ARG_DEFAULT_TITLE) ?: "Passo"

        val etTitle = view.findViewById<EditText>(R.id.etStepTitle)
        val wheelH = view.findViewById<WheelPicker>(R.id.wheelHours)
        val wheelM = view.findViewById<WheelPicker>(R.id.wheelMinutes)
        val wheelS = view.findViewById<WheelPicker>(R.id.wheelSeconds)
        val switchVibration = view.findViewById<MaterialSwitch>(R.id.switchStepVibration)
        val switchManual = view.findViewById<MaterialSwitch>(R.id.switchStepManual)
        tvSound = view.findViewById(R.id.tvSelectedSound)

        val editing = position >= 0
        val duration = args.getLong(ARG_DURATION, 60_000L)
        val totalSec = duration / 1000L

        view.findViewById<TextView>(R.id.tvStepSheetTitle).text = if (editing) "Editar passo" else "Novo passo"
        etTitle.setText(if (editing) args.getString(ARG_TITLE) else "")
        etTitle.hint = defaultTitle
        wheelH.setNumberRange(0, 23, (totalSec / 3600).toInt().coerceIn(0, 23))
        wheelM.setNumberRange(0, 59, ((totalSec % 3600) / 60).toInt())
        wheelS.setNumberRange(0, 59, (totalSec % 60).toInt())
        switchVibration.isChecked = args.getBoolean(ARG_VIBRATE, true)
        switchManual.isChecked = !args.getBoolean(ARG_AUTO_DISMISS, true)
        soundUri = if (savedInstanceState != null) savedInstanceState.getString(STATE_SOUND_URI)
            else if (editing) args.getString(ARG_SOUND_URI) else SoundLibrary.DEFAULT_STEP
        soundTitle = if (savedInstanceState != null) savedInstanceState.getString(STATE_SOUND_TITLE) else args.getString(ARG_SOUND_TITLE)
        tvSound.text = SoundUtils.titleFor(requireContext(), soundUri)

        parentFragmentManager.setFragmentResultListener(SoundPickerSheet.REQUEST_KEY, viewLifecycleOwner) { _, b ->
            soundUri = b.getString(SoundPickerSheet.RESULT_VALUE)
            soundTitle = b.getString(SoundPickerSheet.RESULT_TITLE)
            tvSound.text = SoundUtils.titleFor(requireContext(), soundUri)
        }
        view.findViewById<View>(R.id.layoutSelectSound).setOnClickListener {
            SoundPickerSheet.newInstance(soundUri, SoundPickerSheet.CONTEXT_STEP)
                .show(parentFragmentManager, "sound_picker")
        }
        view.findViewById<MaterialButton>(R.id.btnStepCancel).setOnClickListener { dismiss() }

        view.findViewById<MaterialButton>(R.id.btnStepSave).setOnClickListener {
            val ms = (wheelH.value * 3600L + wheelM.value * 60L + wheelS.value) * 1000L
            if (ms <= 0L) {
                Toast.makeText(requireContext(), R.string.t_define_um_tempo_de_espera, Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val title = etTitle.text.toString().trim().ifEmpty { defaultTitle }
            parentFragmentManager.setFragmentResult(
                REQUEST_KEY,
                bundleOf(
                    ARG_POSITION to position,
                    ARG_TITLE to title,
                    ARG_DURATION to ms,
                    ARG_VIBRATE to switchVibration.isChecked,
                    ARG_AUTO_DISMISS to !switchManual.isChecked,
                    ARG_SOUND_URI to soundUri,
                    ARG_SOUND_TITLE to soundTitle,
                    RESULT_DELETE to false
                )
            )
            dismiss()
        }

        if (editing) {
            view.findViewById<View>(R.id.card_btnStepDelete).visibility = View.VISIBLE
            view.findViewById<MaterialButton>(R.id.btnStepDelete).setOnClickListener {
                parentFragmentManager.setFragmentResult(
                    REQUEST_KEY, bundleOf(ARG_POSITION to position, RESULT_DELETE to true)
                )
                dismiss()
            }
        }
    }

    companion object {
        const val REQUEST_KEY = "step_editor_result"
        const val ARG_POSITION = "position"
        const val ARG_TITLE = "title"
        const val ARG_DURATION = "duration"
        const val ARG_VIBRATE = "vibrate"
        const val ARG_AUTO_DISMISS = "auto_dismiss"
        const val ARG_SOUND_URI = "sound_uri"
        const val ARG_SOUND_TITLE = "sound_title"
        const val ARG_DEFAULT_TITLE = "default_title"
        const val RESULT_DELETE = "delete"
        private const val STATE_SOUND_URI = "state_sound_uri"
        private const val STATE_SOUND_TITLE = "state_sound_title"

        fun newInstance(position: Int, step: CascadeStepEntity?, defaultTitle: String): StepEditorSheet {
            val sheet = StepEditorSheet()
            val b = Bundle()
            b.putInt(ARG_POSITION, position)
            b.putString(ARG_DEFAULT_TITLE, defaultTitle)
            if (step != null) {
                b.putString(ARG_TITLE, step.title)
                b.putLong(ARG_DURATION, step.durationInMillis)
                b.putBoolean(ARG_VIBRATE, step.isVibrationEnabled)
                b.putBoolean(ARG_AUTO_DISMISS, step.autoDismiss)
                b.putString(ARG_SOUND_URI, step.soundUri)
                b.putString(ARG_SOUND_TITLE, step.soundTitle)
            }
            sheet.arguments = b
            return sheet
        }
    }
}
