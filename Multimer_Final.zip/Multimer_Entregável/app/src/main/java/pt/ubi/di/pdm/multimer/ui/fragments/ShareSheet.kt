package pt.ubi.di.pdm.multimer.ui.fragments

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.share.ShareCodec
import pt.ubi.di.pdm.multimer.ui.activity.QrProjectionActivity
import pt.ubi.di.pdm.multimer.util.QrCodes

/** Partilha de uma COPIA: QR code para projetar ou mostrar, texto para enviar por qualquer aplicação. */
class ShareSheet : BottomSheetDialogFragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.sheet_share, container, false)
    }

    override fun onStart() {
        super.onStart()
        val dlg = dialog as? BottomSheetDialog ?: return
        dlg.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dlg.behavior.skipCollapsed = true
        dlg.behavior.isDraggable = false // o arrastar não fecha nem atrapalha o scroll
        dlg.setCanceledOnTouchOutside(false)
        dlg.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.backgroundTintList =
            ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.bg_grouped))
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val args = requireArguments()
        val link = args.getString(ARG_LINK) ?: ""
        val title = args.getString(ARG_TITLE) ?: ""
        val kind = args.getString(ARG_KIND) ?: ""
        val summary = args.getString(ARG_SUMMARY) ?: ""
        val ctx = requireContext()

        view.findViewById<MaterialButton>(R.id.btnShareClose).setOnClickListener { dismiss() }
        view.findViewById<TextView>(R.id.tvShareName).text = title
        view.findViewById<TextView>(R.id.tvShareSummary).text = "$kind, $summary"

        val fits = ShareCodec.fitsInQr(link)
        val cardQr = view.findViewById<View>(R.id.cardQr)
        val tooBig = view.findViewById<View>(R.id.tvQrTooBig)
        if (fits) {
            val size = (260 * resources.displayMetrics.density).toInt()
            val bitmap = QrCodes.bitmap(link, size)
            if (bitmap != null) {
                view.findViewById<ImageView>(R.id.ivQr).setImageBitmap(bitmap)
                cardQr.visibility = View.VISIBLE
                tooBig.visibility = View.GONE
            } else {
                cardQr.visibility = View.GONE
                tooBig.visibility = View.VISIBLE
            }
        } else {
            cardQr.visibility = View.GONE
            tooBig.visibility = View.VISIBLE
        }

        val container = view.findViewById<LinearLayout>(R.id.containerShareActions)
        val inflater = LayoutInflater.from(ctx)
        val rows = ArrayList<Triple<String, String, () -> Unit>>()
        val cascadeId = args.getLong(ARG_CASCADE_ID, -1L)
        if (cascadeId != -1L) {
            rows.add(Triple("Criar sala ao vivo", "Todos correm esta cascata ao mesmo tempo, comandados por ti") {
                Toast.makeText(ctx, R.string.em_desenvolvimento, Toast.LENGTH_SHORT).show()
            })
        }
        if (fits) {
            rows.add(Triple("Projetar em ecrã inteiro", "Para mostrar a uma turma ou a um grupo") {
                startActivity(QrProjectionActivity.newIntent(ctx, link, title))
            })
        }
        rows.add(Triple("Partilhar com outras apps", "Mensagem, e-mail, Bluetooth e mais") {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "$kind \"$title\" para o Multimer:\n$link")
            }
            startActivity(Intent.createChooser(send, "Partilhar"))
        })
        rows.add(Triple("Copiar código", "Cola-o noutra pessoa ou em Receber") {
            val clipboard = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Multimer", link))
            Toast.makeText(ctx, R.string.t_codigo_copiado, Toast.LENGTH_SHORT).show()
        })

        rows.forEachIndexed { index, (name, desc, action) ->
            val row = inflater.inflate(R.layout.item_template_row, container, false)
            row.findViewById<TextView>(R.id.tvTemplateName).text = name
            row.findViewById<TextView>(R.id.tvTemplateDesc).text = desc
            row.setOnClickListener { action() }
            container.addView(row)
            if (index < rows.size - 1) {
                val divider = View(ctx)
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
                lp.marginStart = (16 * resources.displayMetrics.density).toInt()
                divider.layoutParams = lp
                divider.setBackgroundColor(ContextCompat.getColor(ctx, R.color.separator))
                container.addView(divider)
            }
        }
    }

    companion object {
        private const val ARG_LINK = "link"
        private const val ARG_TITLE = "title"
        private const val ARG_KIND = "kind"
        private const val ARG_SUMMARY = "summary"
        private const val ARG_CASCADE_ID = "cascade_id"

        fun newInstance(link: String, title: String, kind: String, summary: String, cascadeId: Long = -1L): ShareSheet {
            val sheet = ShareSheet()
            sheet.arguments = bundleOf(
                ARG_LINK to link, ARG_TITLE to title, ARG_KIND to kind, ARG_SUMMARY to summary, ARG_CASCADE_ID to cascadeId
            )
            return sheet
        }
    }
}
