package pt.ubi.di.pdm.multimer.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.data.local.AppDatabase
import pt.ubi.di.pdm.multimer.data.model.CascadeEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeWithSteps
import pt.ubi.di.pdm.multimer.data.repository.CascadeRepository
import pt.ubi.di.pdm.multimer.service.CascadeService
import pt.ubi.di.pdm.multimer.ui.activity.CustomCascadeEditorActivity
import pt.ubi.di.pdm.multimer.ui.activity.IntervalCascadeEditorActivity
import pt.ubi.di.pdm.multimer.ui.adapter.CascadeAdapter
import pt.ubi.di.pdm.multimer.ui.view.InsetDividerDecoration
import pt.ubi.di.pdm.multimer.ui.view.SwipeCallback
import pt.ubi.di.pdm.multimer.ui.viewmodel.CascadeViewModel
import pt.ubi.di.pdm.multimer.ui.viewmodel.CascadeViewModelFactory
import pt.ubi.di.pdm.multimer.share.ShareCodec
import pt.ubi.di.pdm.multimer.util.CascadeFormat
import pt.ubi.di.pdm.multimer.util.RowActionsPopup
import pt.ubi.di.pdm.multimer.util.Segmented

class CascadeFragment : Fragment() {

    private val viewModel: CascadeViewModel by lazy {
        val database = AppDatabase.getDatabase(requireContext())
        val repository = CascadeRepository(database.cascadeDao())
        ViewModelProvider(this, CascadeViewModelFactory(repository))[CascadeViewModel::class.java]
    }

    private lateinit var adapter: CascadeAdapter
    private lateinit var rv: RecyclerView
    private lateinit var segmented: Segmented
    private lateinit var cardList: View
    private lateinit var layoutEmpty: View
    private lateinit var tvHint: TextView
    private lateinit var tvEmptyTitle: TextView
    private lateinit var tvEmptyBody: TextView

    private var all: List<CascadeWithSteps> = emptyList()
    private var showSequential = true

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(STATE_SEQUENTIAL, showSequential)
    }

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            updateRunning()
            handler.postDelayed(this, 250L)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_cascade, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rv = view.findViewById(R.id.rvCascades)
        cardList = view.findViewById(R.id.cardCascadeList)
        layoutEmpty = view.findViewById(R.id.layoutCascadeEmpty)
        tvHint = view.findViewById(R.id.tvCascadeHint)
        tvEmptyTitle = view.findViewById(R.id.tvCascadeEmptyTitle)
        tvEmptyBody = view.findViewById(R.id.tvCascadeEmptyBody)

        showSequential = savedInstanceState?.getBoolean(STATE_SEQUENTIAL, true) ?: true
        segmented = Segmented(
            listOf<View>(view.findViewById<View>(R.id.segSequential), view.findViewById<View>(R.id.segCustom))
        ) { index ->
            showSequential = index == 0
            refreshList()
        }

        adapter = CascadeAdapter(
            onPlayClick = { item, running ->
                if (running) sendAction(CascadeService.ACTION_STOP_CASCADE, item.cascade.id) else startCascade(item)
            },
            onPauseClick = { item ->
                val paused = CascadeService.runs[item.cascade.id]?.paused == true
                sendAction(if (paused) CascadeService.ACTION_RESUME_CASCADE else CascadeService.ACTION_PAUSE_CASCADE, item.cascade.id)
                handler.postDelayed({ updateRunning() }, 120L)
            },
            onSkipClick = { item -> sendAction(CascadeService.ACTION_NEXT_STEP, item.cascade.id) },
            onItemClick = { item -> openEditor(item.cascade.id, item.cascade.type) },
            actionsFor = { item ->
                listOf(
                    RowActionsPopup.Action("Partilhar", R.drawable.ic_share) { share(item) },
                    RowActionsPopup.Action("Duplicar", R.drawable.ic_duplicate) { duplicate(item) },
                    RowActionsPopup.Action("Eliminar", R.drawable.ic_trash, destructive = true) { confirmDelete(item) }
                )
            }
        )
        rv.layoutManager = LinearLayoutManager(requireContext())
        rv.adapter = adapter
        rv.itemAnimator = null
        rv.addItemDecoration(InsetDividerDecoration(requireContext()))

        ItemTouchHelper(SwipeCallback(requireContext(), false, null) { position ->
            adapter.itemAt(position)?.let { confirmDelete(it) { adapter.notifyItemChanged(position) } }
        }).attachToRecyclerView(rv)

        view.findViewById<View>(R.id.btnCascadeEmptyAdd).setOnClickListener { showNewSheet() }
        view.findViewById<View>(R.id.btnReceiveCascade).setOnClickListener {
            ImportSheet().show(parentFragmentManager, "import")
        }

        parentFragmentManager.setFragmentResultListener(NewCascadeSheet.REQUEST_KEY, viewLifecycleOwner) { _, b ->
            val type = b.getInt(NewCascadeSheet.ARG_TYPE, currentType())
            when (b.getString(NewCascadeSheet.RESULT_MODE)) {
                NewCascadeSheet.MODE_TEMPLATE -> openEditor(-1L, type, templateKey = b.getString(NewCascadeSheet.RESULT_KEY))
                NewCascadeSheet.MODE_BASE -> openEditor(-1L, type, baseId = b.getLong(NewCascadeSheet.RESULT_ID, -1L))
                else -> openEditor(-1L, type)
            }
        }

        segmented.select(if (showSequential) 0 else 1)

        viewModel.allCascades.observe(viewLifecycleOwner) { list ->
            all = list ?: emptyList()
            refreshList()
        }
        refreshList()
    }

    private fun currentType(): Int =
        if (showSequential) CascadeEntity.TYPE_SEQUENTIAL else CascadeEntity.TYPE_CUSTOM

    private fun refreshList() {
        val filtered = all.filter { it.cascade.type == currentType() }
        adapter.submitList(filtered)
        val empty = filtered.isEmpty()
        cardList.visibility = if (empty) View.GONE else View.VISIBLE
        layoutEmpty.visibility = if (empty) View.VISIBLE else View.GONE

        if (showSequential) {
            tvHint.setText(R.string.t_tocam_de_x_em_x_2)
            tvEmptyTitle.setText(R.string.t_sem_alarmes_sequenciais)
            tvEmptyBody.setText(R.string.t_por_exemplo_4_toques_de)
        } else {
            tvHint.setText(R.string.t_varios_avisos_diferentes_num_s)
            tvEmptyTitle.setText(R.string.t_sem_cascatas_personalizadas)
            tvEmptyBody.setText(R.string.t_junta_passos_como_envolver_os)
        }
    }

    /** Atualiza o progresso de cada linha visível, sem recarregar a lista. */
    private fun updateRunning() {
        if (!isAdded || view == null) return
        for (i in 0 until rv.childCount) {
            val holder = rv.getChildViewHolder(rv.getChildAt(i))
            if (holder is CascadeAdapter.CascadeViewHolder) holder.updateRun()
        }
    }

    private fun startCascade(item: CascadeWithSteps) {
        val intent = Intent(requireContext(), CascadeService::class.java).apply {
            action = CascadeService.ACTION_START_CASCADE
            putExtra(CascadeService.EXTRA_CASCADE_ID, item.cascade.id)
        }
        ContextCompat.startForegroundService(requireContext(), intent)
        handler.postDelayed({ updateRunning() }, 300L)
    }

    private fun sendAction(action: String, cascadeId: Long) {
        val intent = Intent(requireContext(), CascadeService::class.java)
            .setAction(action)
            .putExtra(CascadeService.EXTRA_CASCADE_ID, cascadeId)
        requireContext().startService(intent)
        handler.postDelayed({ updateRunning() }, 150L)
    }

    /** Mostra o separador pedido (usado depois de importar). */
    fun showType(sequential: Boolean) {
        showSequential = sequential
        if (view != null) {
            segmented.select(if (sequential) 0 else 1)
            refreshList()
        }
    }

    /** Chamado pelo botão flutuante da atividade. */
    fun onAddClicked() = showNewSheet()

    private fun showNewSheet() {
        val type = currentType()
        val existing = all.filter { it.cascade.type == type }
        NewCascadeSheet.newInstance(
            type,
            existing.map { it.cascade.id }.toLongArray(),
            existing.map { it.cascade.title }.toTypedArray()
        ).show(parentFragmentManager, "new_cascade")
    }

    private fun share(item: CascadeWithSteps) {
        val kind = if (item.cascade.type == CascadeEntity.TYPE_SEQUENTIAL) "Alarme sequencial" else "Cascata"
        ShareSheet.newInstance(
            ShareCodec.encodeCascade(item), item.cascade.title, kind, CascadeFormat.summary(item), item.cascade.id
        ).show(parentFragmentManager, "share")
    }

    private fun duplicate(item: CascadeWithSteps) {
        val copy = item.cascade.copy(
            id = 0L,
            title = item.cascade.title + " (cópia)",
            createdAt = System.currentTimeMillis(),
            syncId = "", updatedAt = 0L, syncedAt = 0L
        )
        viewModel.saveCascade(copy, item.steps.map { it.copy(id = 0L, cascadeId = 0L) })
    }

    private fun openEditor(id: Long, type: Int, templateKey: String? = null, baseId: Long = -1L) {
        val ctx = requireContext()
        val intent = if (type == CascadeEntity.TYPE_SEQUENTIAL) {
            IntervalCascadeEditorActivity.newIntent(ctx, id, templateKey, baseId)
        } else {
            CustomCascadeEditorActivity.newIntent(ctx, id, templateKey, baseId)
        }
        startActivity(intent)
    }

    private fun confirmDelete(item: CascadeWithSteps, onCancel: () -> Unit = {}) {
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle(R.string.confirm_delete_title)
            .setMessage(R.string.confirm_delete_cascade)
            .setPositiveButton(R.string.t_eliminar) { _, _ -> deleteWithUndo(item) }
            .setNegativeButton(R.string.t_cancelar) { _, _ -> onCancel() }
            .setOnCancelListener { onCancel() }
            .show()
    }

    private fun deleteWithUndo(item: CascadeWithSteps) {
        if (CascadeService.isRunning(item.cascade.id)) {
            sendAction(CascadeService.ACTION_STOP_CASCADE, item.cascade.id)
        }
        viewModel.deleteCascade(item.cascade)

        val root = requireActivity().findViewById<View>(R.id.rootLayoutMain)
        Snackbar.make(root, "\"${item.cascade.title}\" eliminada", Snackbar.LENGTH_LONG)
            .setAnchorView(R.id.fabAdd)
            .setAction(R.string.t_anular) { viewModel.saveCascade(item.cascade, item.steps) }
            .show()
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    companion object {
        private const val STATE_SEQUENTIAL = "state_sequential"
    }
}
