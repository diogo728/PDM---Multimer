package pt.ubi.di.pdm.multimer.service

import android.os.SystemClock

/**
 * Estado de uma cascata em execução. O serviço escreve; a interface só lê.
 * Cada passo é uma espera ([Step.waitMs]) seguida de um toque.
 */
class CascadeRun(
    val cascadeId: Long,
    val title: String,
    val isSequential: Boolean,
    private val customSteps: List<Step>?,
    private val seqStep: Step?,
    /** Número de toques de uma sequencial; 0 significa sem fim. */
    private val seqCount: Int
) {
    class Step(
        val title: String,
        val waitMs: Long,
        val autoDismiss: Boolean,
        val vibrate: Boolean,
        val soundUri: String?
    )

    // --- Estado visível à interface ---
    @Volatile var index = 0
    @Volatile var paused = false
    @Volatile var ringing = false
    @Volatile var finished = false
    @Volatile var stepTitle = ""
    @Volatile var stepDurationMs = 0L
    @Volatile var stepEndAtElapsed = 0L
    @Volatile var pausedRemainingMs = 0L
    @Volatile var muted = false
    @Volatile var silent = false

    // --- Uso interno do serviço ---
    var generation = 0
    var dueRunnable: Runnable? = null
    var finishing = false

    /** Número de passos; 0 se não tem fim. */
    val stepCount: Int get() = customSteps?.size ?: seqCount
    val isInfinite: Boolean get() = customSteps == null && seqCount <= 0

    fun stepAt(i: Int): Step? {
        if (customSteps != null) return customSteps.getOrNull(i)
        val seq = seqStep ?: return null
        if (seqCount > 0 && i >= seqCount) return null
        val name = if (seqCount > 0) "Toque ${i + 1} de $seqCount" else "Toque ${i + 1}"
        return Step(name, seq.waitMs, seq.autoDismiss, seq.vibrate, seq.soundUri)
    }

    fun remainingMs(): Long {
        if (finished) return 0L
        if (paused) return pausedRemainingMs
        return (stepEndAtElapsed - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
    }

    /** Soma das esperas dos passos depois do atual; -1 se não tem fim. */
    fun afterCurrentMs(): Long {
        if (customSteps != null) return customSteps.drop(index + 1).sumOf { it.waitMs }
        val seq = seqStep ?: return 0L
        if (seqCount <= 0) return -1L
        return (seqCount - index - 1).coerceAtLeast(0) * seq.waitMs
    }

    /** Tempo que falta até ao fim de tudo; -1 se não tem fim. */
    fun overallRemainingMs(): Long {
        val after = afterCurrentMs()
        return if (after < 0L) -1L else remainingMs() + after
    }

    /** Fração (0 a 1) do passo atual que já passou. */
    fun stepFraction(): Float {
        if (finished) return 1f
        val total = stepDurationMs
        if (total <= 0L) return 0f
        return ((total - remainingMs()).toFloat() / total.toFloat()).coerceIn(0f, 1f)
    }

    /** Fração (0 a 1) do conjunto já concluída: do tempo total nas personalizadas, dos toques nas sequenciais. */
    fun overallFraction(): Float {
        if (finished) return 1f
        if (customSteps != null) {
            val total = customSteps.sumOf { it.waitMs }.toFloat()
            if (total <= 0f) return 0f
            val before = customSteps.take(index).sumOf { it.waitMs }.toFloat()
            val current = stepDurationMs.toFloat() * stepFraction()
            return ((before + current) / total).coerceIn(0f, 1f)
        }
        if (seqCount > 0) return ((index + stepFraction()) / seqCount).coerceIn(0f, 1f)
        return stepFraction()
    }

    /**
     * Pesos dos segmentos da barra de progresso. Nas personalizadas, proporcionais ao tempo
     * de cada passo (com um mínimo para os curtos continuarem visíveis); nas sequenciais,
     * iguais. Sem fim ou com demasiados toques, um único segmento.
     */
    fun timelineWeights(): List<Float> {
        if (customSteps != null) {
            val total = customSteps.sumOf { it.waitMs }.toFloat().coerceAtLeast(1f)
            return customSteps.map { maxOf(it.waitMs.toFloat(), total * 0.06f) }
        }
        return if (seqCount in 1..MAX_SEGMENTS) List(seqCount) { 1f } else listOf(1f)
    }

    /** Progresso (segmento atual, fração dentro dele) para a barra devolvida por [timelineWeights]. */
    fun timelineProgress(): Pair<Int, Float> {
        val segments = timelineWeights().size
        if (customSteps != null || seqCount in 1..MAX_SEGMENTS) {
            return if (finished) Pair(segments, 0f) else Pair(index.coerceAtMost(segments - 1), stepFraction())
        }
        if (seqCount > MAX_SEGMENTS) {
            val done = if (finished) 1f else (index + stepFraction()) / seqCount
            return Pair(0, done.coerceIn(0f, 1f))
        }
        return Pair(0, if (finished) 1f else stepFraction())
    }

    companion object {
        const val MAX_SEGMENTS = 24
    }
}
