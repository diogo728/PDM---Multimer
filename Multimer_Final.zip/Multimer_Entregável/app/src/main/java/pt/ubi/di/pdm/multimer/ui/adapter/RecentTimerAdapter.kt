package pt.ubi.di.pdm.multimer.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.data.model.TimerEntity
import pt.ubi.di.pdm.multimer.util.TimeFmt

class RecentTimerAdapter(
    private val onSelect: (TimerEntity) -> Unit,
    private val onPlay: (TimerEntity) -> Unit
) : ListAdapter<TimerEntity, RecentTimerAdapter.VH>(Diff()) {

    fun itemAt(position: Int): TimerEntity? = currentList.getOrNull(position)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        return VH(LayoutInflater.from(parent.context).inflate(R.layout.item_recent_timer, parent, false))
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvTime: TextView = itemView.findViewById(R.id.tvRecentTime)
        private val tvLabel: TextView = itemView.findViewById(R.id.tvRecentLabel)
        private val btnPlay: ImageButton = itemView.findViewById(R.id.btnRecentPlay)

        fun bind(timer: TimerEntity) {
            tvTime.text = TimeFmt.elapsed(timer.durationInMillis)
            tvLabel.text = if (timer.title.isNotEmpty()) timer.title else TimeFmt.human(timer.durationInMillis)
            itemView.setOnClickListener { onSelect(timer) }
            btnPlay.setOnClickListener { onPlay(timer) }
        }
    }

    class Diff : DiffUtil.ItemCallback<TimerEntity>() {
        override fun areItemsTheSame(a: TimerEntity, b: TimerEntity) = a.id == b.id
        override fun areContentsTheSame(a: TimerEntity, b: TimerEntity) = a == b
    }
}
