package pt.ubi.di.pdm.multimer.ui.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.data.local.AppDatabase
import pt.ubi.di.pdm.multimer.data.model.CascadeEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeStepEntity
import pt.ubi.di.pdm.multimer.data.repository.CascadeRepository
import pt.ubi.di.pdm.multimer.ui.adapter.StepAdapter
import pt.ubi.di.pdm.multimer.ui.fragments.StepEditorSheet
import pt.ubi.di.pdm.multimer.ui.view.InsetDividerDecoration
import pt.ubi.di.pdm.multimer.ui.view.SwipeCallback
import pt.ubi.di.pdm.multimer.ui.viewmodel.CascadeViewModel
import pt.ubi.di.pdm.multimer.ui.viewmodel.CascadeViewModelFactory
import pt.ubi.di.pdm.multimer.util.CascadeTemplates
import pt.ubi.di.pdm.multimer.util.TimeFmt
import pt.ubi.di.pdm.multimer.util.enableEdgeToEdge

/** Cascata personalizada: uma lista de passos, cada um com o seu tempo, som e modo de desligar. */
class CustomCascadeEditorActivity : AppCompatActivity() {

    private val viewModel: CascadeViewModel by lazy {
        val database = AppDatabase.getDatabase(this)
        ViewModelProvider(this, CascadeViewModelFactory(CascadeRepository(database.cascadeDao())))[CascadeViewModel::class.java]
    }

    private val steps = mutableListOf<CascadeStepEntity>()
    private lateinit var adapter: StepAdapter
    private lateinit var etTitle: EditText
    private lateinit var tvSummary: TextView
    private lateinit var cardSteps: View
    private var cascadeId = -1L
    private var createdAt = System.currentTimeMillis()
    private var loadedSyncId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_custom_editor)
        enableEdgeToEdge()

        etTitle = findViewById(R.id.etCascadeTitle)
        tvSummary = findViewById(R.id.tvCustomSummary)
        cardSteps = findViewById(R.id.cardSteps)
        val rv = findViewById<RecyclerView>(R.id.rvSteps)

        lateinit var touchHelper: ItemTouchHelper
        adapter = StepAdapter(
            steps,
            onClick = { position -> openStepSheet(position) },
            onStartDrag = { holder -> touchHelper.startDrag(holder) }
        )
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter
        rv.addItemDecoration(InsetDividerDecoration(this))

        val callback = SwipeCallback(this, true, { from, to -> adapter.move(from, to) }) { position ->
            adapter.removeAt(position)
            updateSummary()
        }
        callback.onDragFinished = {
            rv.post {
                adapter.refreshAll()
                updateSummary()
            }
        }
        touchHelper = ItemTouchHelper(callback)
        touchHelper.attachToRecyclerView(rv)

        supportFragmentManager.setFragmentResultListener(StepEditorSheet.REQUEST_KEY, this) { _, bundle ->
            onStepResult(bundle)
        }

        findViewById<View>(R.id.btnAddStep).setOnClickListener { openStepSheet(-1) }
        findViewById<MaterialButton>(R.id.btnCancelEditor).setOnClickListener { finish() }
        findViewById<MaterialButton>(R.id.btnSaveEditor).setOnClickListener { save() }
        findViewById<MaterialButton>(R.id.btnDeleteEditor).setOnClickListener {
            if (cascadeId != -1L) viewModel.deleteCascade(CascadeEntity(id = cascadeId, title = ""))
            finish()
        }

        cascadeId = intent.getLongExtra(EXTRA_CASCADE_ID, -1L)
        if (cascadeId != -1L) {
            findViewById<TextView>(R.id.tvEditorTitle).text = "Editar cascata"
            findViewById<View>(R.id.card_btnDeleteEditor).visibility = View.VISIBLE
            viewModel.loadCascade(cascadeId) { data ->
                if (data == null) {
                    finish()
                } else {
                    createdAt = data.cascade.createdAt
                    loadedSyncId = data.cascade.syncId
                    etTitle.setText(data.cascade.title)
                    steps.clear()
                    steps.addAll(data.steps.sortedBy { it.stepOrder })
                    adapter.notifyDataSetChanged()
                    updateSummary()
                }
            }
        } else {
            // Novo: em branco, a partir de um modelo ou como cópia de uma existente
            val templateKey = intent.getStringExtra(EXTRA_TEMPLATE_KEY)
            val baseId = intent.getLongExtra(EXTRA_BASE_ID, -1L)
            if (templateKey != null) {
                CascadeTemplates.find(templateKey)?.let { t ->
                    etTitle.setText(t.name)
                    steps.addAll(t.steps.map { it.copy(id = 0L, cascadeId = 0L) })
                    adapter.notifyDataSetChanged()
                }
            } else if (baseId != -1L) {
                viewModel.loadCascade(baseId) { data ->
                    if (data != null) {
                        etTitle.setText(data.cascade.title + " (cópia)")
                        steps.clear()
                        steps.addAll(data.steps.sortedBy { it.stepOrder }.map { it.copy(id = 0L, cascadeId = 0L) })
                        adapter.notifyDataSetChanged()
                        updateSummary()
                    }
                }
            }
        }
        updateSummary()
    }

    private fun openStepSheet(position: Int) {
        val step = if (position >= 0) steps[position] else null
        StepEditorSheet.newInstance(position, step, "Passo ${(if (position >= 0) position else steps.size) + 1}")
            .show(supportFragmentManager, "step_editor")
    }

    private fun onStepResult(b: Bundle) {
        val position = b.getInt(StepEditorSheet.ARG_POSITION, -1)
        if (b.getBoolean(StepEditorSheet.RESULT_DELETE, false)) {
            if (position in steps.indices) {
                adapter.removeAt(position)
                updateSummary()
            }
            return
        }
        val old = if (position in steps.indices) steps[position] else null
        val step = CascadeStepEntity(
            id = old?.id ?: 0L,
            cascadeId = old?.cascadeId ?: 0L,
            stepOrder = if (position >= 0) position else steps.size,
            title = b.getString(StepEditorSheet.ARG_TITLE) ?: "Passo",
            durationInMillis = b.getLong(StepEditorSheet.ARG_DURATION, 60_000L),
            autoDismiss = b.getBoolean(StepEditorSheet.ARG_AUTO_DISMISS, true),
            isVibrationEnabled = b.getBoolean(StepEditorSheet.ARG_VIBRATE, true),
            soundUri = b.getString(StepEditorSheet.ARG_SOUND_URI),
            soundTitle = b.getString(StepEditorSheet.ARG_SOUND_TITLE)
        )
        if (position in steps.indices) {
            steps[position] = step
            adapter.refreshAll()
        } else {
            steps.add(step)
            adapter.notifyItemInserted(steps.size - 1)
        }
        updateSummary()
    }

    private fun updateSummary() {
        cardSteps.visibility = if (steps.isEmpty()) View.GONE else View.VISIBLE
        tvSummary.text = if (steps.isEmpty()) {
            "Sem passos ainda. Adiciona o primeiro."
        } else {
            val n = steps.size
            val total = steps.sumOf { it.durationInMillis }
            (if (n == 1) "1 passo" else "$n passos") + ", " + TimeFmt.human(total) + " no total."
        }
    }

    private fun save() {
        if (steps.isEmpty()) {
            Toast.makeText(this, R.string.t_adiciona_pelo_menos_um_passo, Toast.LENGTH_SHORT).show()
            return
        }
        val title = etTitle.text.toString().trim().ifEmpty { "Cascata" }
        val cascade = CascadeEntity(
            id = if (cascadeId != -1L) cascadeId else 0L,
            title = title,
            createdAt = createdAt,
            type = CascadeEntity.TYPE_CUSTOM,
            syncId = loadedSyncId
        )
        viewModel.saveCascade(cascade, steps.toList())
        finish()
    }

    companion object {
        const val EXTRA_CASCADE_ID = "extra_cascade_id"
        const val EXTRA_TEMPLATE_KEY = "extra_template_key"
        const val EXTRA_BASE_ID = "extra_base_id"

        fun newIntent(context: Context, cascadeId: Long = -1L, templateKey: String? = null, baseId: Long = -1L): Intent {
            return Intent(context, CustomCascadeEditorActivity::class.java).apply {
                putExtra(EXTRA_CASCADE_ID, cascadeId)
                putExtra(EXTRA_TEMPLATE_KEY, templateKey)
                putExtra(EXTRA_BASE_ID, baseId)
            }
        }
    }
}
