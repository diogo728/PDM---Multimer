package pt.ubi.di.pdm.multimer.data.model

import androidx.room.ColumnInfo
import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.ForeignKey.Companion.CASCADE
import androidx.room.PrimaryKey
import androidx.room.Relation

/**
 * Uma cascata pode ser:
 *  - SEQUENCIAL: toca de [intervalMillis] em [intervalMillis], [repeatCount] vezes (0 = até parar).
 *    Os parâmetros do toque ficam na própria cascata e não há passos.
 *  - PERSONALIZADA: uma lista de passos, cada um com o seu tempo de espera e o seu toque.
 */
@Entity(tableName = "cascades")
data class CascadeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val title: String,
    val createdAt: Long = System.currentTimeMillis(),
    @ColumnInfo(defaultValue = "1")
    val type: Int = TYPE_CUSTOM,
    @ColumnInfo(defaultValue = "0")
    val intervalMillis: Long = 0L,
    @ColumnInfo(defaultValue = "0")
    val repeatCount: Int = 0,
    @ColumnInfo(defaultValue = "1")
    val autoDismiss: Boolean = true,
    @ColumnInfo(defaultValue = "1")
    val isVibrationEnabled: Boolean = true,
    val soundUri: String? = null,
    val soundTitle: String? = null,
    // --- Sincronização com a conta (ver sync/SyncManager) ---
    @ColumnInfo(defaultValue = "''")
    val syncId: String = "",       // identificador único, igual em todos os aparelhos
    @ColumnInfo(defaultValue = "0")
    val updatedAt: Long = 0L,      // última alteração da definição
    @ColumnInfo(defaultValue = "0")
    val syncedAt: Long = 0L        // última versão já enviada/recebida
) {
    companion object {
        const val TYPE_SEQUENTIAL = 0
        const val TYPE_CUSTOM = 1
    }
}

@Entity(
    tableName = "cascade_steps",
    foreignKeys = [
        ForeignKey(
            entity = CascadeEntity::class,
            parentColumns = ["id"],
            childColumns = ["cascadeId"],
            onDelete = CASCADE
        )
    ]
)
data class CascadeStepEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val cascadeId: Long = 0L,
    val stepOrder: Int,
    val title: String,
    val durationInMillis: Long, // espera desde o passo anterior até este tocar
    val autoDismiss: Boolean = true, // true = toca uma vez e segue; false = toca até ser desligado
    val isVibrationEnabled: Boolean = true,
    val soundUri: String? = null,
    val soundTitle: String? = null
)

data class CascadeWithSteps(
    @Embedded val cascade: CascadeEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "cascadeId"
    )
    val steps: List<CascadeStepEntity>
)
