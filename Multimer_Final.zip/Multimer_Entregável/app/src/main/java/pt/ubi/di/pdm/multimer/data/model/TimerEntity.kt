package pt.ubi.di.pdm.multimer.data.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "timers")
data class TimerEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,                                   // ID único
    val title: String,                                  // Nome do timer
    val durationInMillis: Long,                         // Duração total (milissegundos)
    val isVibrationEnabled: Boolean = true,             // Alerta vibratório
    val soundUri: String? = null,                       // Som personalizado/padrão
    val autoDismiss: Boolean = false,                   // Cessar manual ou automaticamente
    val nextTimerId: Long? = null,                      // ID do timer em cascata (caso exista)
    val createdAt: Long = System.currentTimeMillis(),   // Data de criação
    // --- Sincronização com a conta (ver sync/SyncManager) ---
    @ColumnInfo(defaultValue = "''")
    val syncId: String = "",       // identificador único, igual em todos os aparelhos
    @ColumnInfo(defaultValue = "0")
    val updatedAt: Long = 0L,      // última alteração da definição
    @ColumnInfo(defaultValue = "0")
    val syncedAt: Long = 0L        // última versão já enviada/recebida
)
