package pt.ubi.di.pdm.multimer.service

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import pt.ubi.di.pdm.multimer.MainActivity
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.ui.activity.AlarmRingingActivity
import pt.ubi.di.pdm.multimer.util.ExactAlarms
import pt.ubi.di.pdm.multimer.util.NotificationStyle
import pt.ubi.di.pdm.multimer.util.Notifications
import pt.ubi.di.pdm.multimer.util.RingPlayer
import pt.ubi.di.pdm.multimer.util.TimeFmt

/**
 * Temporizador. O fim é garantido pelo AlarmManager (funciona com o ecrã desligado);
 * o Handler só serve para reagir ao segundo quando a app está acordada.
 */
class CountdownService : Service() {

    private lateinit var player: RingPlayer
    private val handler = Handler(Looper.getMainLooper())
    private var dueRunnable: Runnable? = null
    private var generation = 0

    private val progressTick = object : Runnable {
        override fun run() {
            if (isRunning && !isPaused && !isRinging) {
                refreshNotification()
                handler.postDelayed(this, PROGRESS_REFRESH_MS)
            }
        }
    }

    private fun restartProgressTick() {
        handler.removeCallbacks(progressTick)
        handler.postDelayed(progressTick, PROGRESS_REFRESH_MS)
    }

    private var soundUri: String? = null
    private var vibrate = true
    private var autoStop = false

    companion object {
        const val NOTIFICATION_ID = 3003

        const val EXTRA_DURATION_MS = "extra_duration_ms"
        const val EXTRA_LABEL = "extra_label"
        const val EXTRA_SOUND_URI = "extra_sound_uri"
        const val EXTRA_VIBRATE = "extra_vibrate"
        const val EXTRA_AUTO_STOP = "extra_auto_stop"
        private const val EXTRA_GENERATION = "extra_generation"

        const val ACTION_START_COUNTDOWN = "pt.ubi.di.pdm.multimer.ACTION_START_COUNTDOWN"
        const val ACTION_PAUSE_COUNTDOWN = "pt.ubi.di.pdm.multimer.ACTION_PAUSE_COUNTDOWN"
        const val ACTION_RESUME_COUNTDOWN = "pt.ubi.di.pdm.multimer.ACTION_RESUME_COUNTDOWN"
        const val ACTION_CANCEL_COUNTDOWN = "pt.ubi.di.pdm.multimer.ACTION_CANCEL_COUNTDOWN"
        const val ACTION_STOP_RING = "pt.ubi.di.pdm.multimer.ACTION_STOP_RING_TIMER"
        const val ACTION_ADD_MINUTE = "pt.ubi.di.pdm.multimer.ACTION_ADD_MINUTE"
        private const val ACTION_DUE = "pt.ubi.di.pdm.multimer.ACTION_TIMER_DUE"

        private const val PROGRESS_REFRESH_MS = 5_000L
        private const val RING_MAX_MS = 10 * 60 * 1000L
        private const val AUTO_STOP_RING_MS = 12_000L

        // Estado lido pela interface
        @Volatile var isRunning = false
        @Volatile var isPaused = false
        @Volatile var isRinging = false
        @Volatile var totalMs = 0L
        @Volatile var label = ""
        @Volatile private var endAtElapsed = 0L
        @Volatile private var pausedRemainingMs = 0L

        fun remainingMs(): Long {
            if (!isRunning || isRinging) return 0L
            if (isPaused) return pausedRemainingMs
            return (endAtElapsed - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
        }

        /** Hora de relógio (ms) a que o temporizador termina. */
        fun endsAtWallClock(): Long = System.currentTimeMillis() + remainingMs()
    }

    override fun onCreate() {
        super.onCreate()
        Notifications.ensureChannels(this)
        player = RingPlayer(this)
        player.onFinished = { finishAndStop() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Quem chama startForegroundService() exige startForeground() em poucos segundos
        startForeground(NOTIFICATION_ID, buildNotification())

        if (intent != null) handleCommand(intent)

        if (!isRunning) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        refreshNotification()
        return START_NOT_STICKY
    }

    private fun handleCommand(intent: Intent) {
        when (intent.action) {
            ACTION_START_COUNTDOWN -> {
                val duration = intent.getLongExtra(EXTRA_DURATION_MS, 0L)
                if (duration > 0L) {
                    soundUri = intent.getStringExtra(EXTRA_SOUND_URI)
                    vibrate = intent.getBooleanExtra(EXTRA_VIBRATE, true)
                    autoStop = intent.getBooleanExtra(EXTRA_AUTO_STOP, false)
                    startCountdown(duration, intent.getStringExtra(EXTRA_LABEL) ?: "")
                }
            }
            ACTION_PAUSE_COUNTDOWN -> pauseCountdown()
            ACTION_RESUME_COUNTDOWN -> resumeCountdown()
            ACTION_ADD_MINUTE -> addMinute()
            ACTION_CANCEL_COUNTDOWN, ACTION_STOP_RING -> finishAndStop()
            ACTION_DUE -> onDue(intent.getIntExtra(EXTRA_GENERATION, -1))
        }
    }

    private fun startCountdown(durationMs: Long, newLabel: String) {
        player.stop()
        label = newLabel
        totalMs = durationMs
        isRunning = true
        isPaused = false
        isRinging = false
        pausedRemainingMs = 0L
        endAtElapsed = SystemClock.elapsedRealtime() + durationMs
        scheduleDue(durationMs)
        restartProgressTick()
    }

    private fun pauseCountdown() {
        if (!isRunning || isPaused || isRinging) return
        pausedRemainingMs = remainingMs()
        isPaused = true
        cancelDue()
    }

    private fun resumeCountdown() {
        if (!isRunning || !isPaused) return
        isPaused = false
        endAtElapsed = SystemClock.elapsedRealtime() + pausedRemainingMs
        scheduleDue(pausedRemainingMs)
        restartProgressTick()
    }

    /** +1 min: acrescenta tempo ao que corre, ou recomeça com 1 minuto se já estiver a tocar. */
    private fun addMinute() {
        if (!isRunning) return
        if (isRinging) {
            player.stop()
            sendBroadcast(AlarmRingingActivity.dismissBroadcast(this, AlarmRingingActivity.KIND_TIMER))
            isRinging = false
            isPaused = false
            totalMs = 60_000L
            endAtElapsed = SystemClock.elapsedRealtime() + 60_000L
            scheduleDue(60_000L)
        } else if (isPaused) {
            pausedRemainingMs += 60_000L
            totalMs += 60_000L
        } else {
            endAtElapsed += 60_000L
            totalMs += 60_000L
            scheduleDue(remainingMs())
        }
    }

    private fun onDue(gen: Int) {
        if (gen != generation || !isRunning || isPaused || isRinging) return
        if (remainingMs() > 800L) {
            scheduleDue(remainingMs())
            return
        }
        isRinging = true
        cancelDue()
        player.start(
            soundUri, vibrate,
            loop = !autoStop,
            gradualVolume = false,
            maxDurationMs = if (autoStop) AUTO_STOP_RING_MS else RING_MAX_MS
        )
        if (!autoStop) {
            try {
                startActivity(ringingIntent())
            } catch (e: Exception) {
                // a notificação em ecrã inteiro trata disso
            }
        }
    }

    private fun finishAndStop() {
        cancelDue()
        player.stop()
        isRunning = false
        isPaused = false
        isRinging = false
        pausedRemainingMs = 0L
        sendBroadcast(AlarmRingingActivity.dismissBroadcast(this, AlarmRingingActivity.KIND_TIMER))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // --- Agendamento ---

    private fun scheduleDue(remaining: Long) {
        cancelDue()
        val gen = ++generation
        val runnable = Runnable { onDue(gen) }
        dueRunnable = runnable
        handler.postDelayed(runnable, remaining)
        ExactAlarms.setElapsed(this, SystemClock.elapsedRealtime() + remaining, duePendingIntent(gen))
    }

    private fun cancelDue() {
        dueRunnable?.let { handler.removeCallbacks(it) }
        dueRunnable = null
        ExactAlarms.cancel(this, duePendingIntent(0))
    }

    private fun duePendingIntent(gen: Int): PendingIntent {
        val intent = Intent(this, CountdownService::class.java)
            .setAction(ACTION_DUE)
            .putExtra(EXTRA_GENERATION, gen)
        return PendingIntent.getForegroundService(this, 10, intent, Notifications.IMMUTABLE_UPDATE)
    }

    // --- Notificações ---

    private fun ringingIntent(): Intent {
        return AlarmRingingActivity.newIntent(
            this, AlarmRingingActivity.KIND_TIMER,
            "Temporizador", "Terminou", label, "Mais 1 min"
        )
    }

    private fun refreshNotification() {
        getSystemService(NotificationManager::class.java)?.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val title = if (label.isNotBlank()) label else "Temporizador"

        if (isRunning && isRinging) {
            val fullScreen = PendingIntent.getActivity(this, 11, ringingIntent(), Notifications.IMMUTABLE_UPDATE)
            val ringBuilder = NotificationCompat.Builder(this, Notifications.CHANNEL_ALERT)
                .setSmallIcon(R.drawable.ic_nav_countdown)
                .setContentTitle(getString(R.string.t_o_tempo_acabou))
                .setContentText(title)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setContentIntent(fullScreen)
                .setFullScreenIntent(fullScreen, true)
                .setOngoing(true)
                .addAction(0, getString(R.string.t_mais_1_min), Notifications.servicePendingIntent(this, CountdownService::class.java, ACTION_ADD_MINUTE, 12))
                .addAction(0, getString(R.string.t_parar), Notifications.servicePendingIntent(this, CountdownService::class.java, ACTION_STOP_RING, 13))
            return NotificationStyle.alert(this, ringBuilder, "Temporizador").build()
        }

        val openPi = PendingIntent.getActivity(this, 14, Intent(this, MainActivity::class.java), Notifications.IMMUTABLE_UPDATE)
        val builder = NotificationCompat.Builder(this, Notifications.CHANNEL_RUNNING)
            .setSmallIcon(R.drawable.ic_nav_countdown)
            .setContentTitle(title)
            .setContentIntent(openPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
        NotificationStyle.running(this, builder, "Temporizador")

        if (!isRunning) return builder.setContentText(getString(R.string.t_a_terminar)).build()

        // Barra de progresso do tempo já decorrido (atualizada de poucos em poucos segundos)
        val total = totalMs
        if (total > 0L) NotificationStyle.progress(builder, (total - remainingMs()).toFloat() / total.toFloat())

        if (isPaused) {
            builder.setContentText("Em pausa, faltam " + TimeFmt.countdown(pausedRemainingMs))
            builder.addAction(0, getString(R.string.t_retomar), Notifications.servicePendingIntent(this, CountdownService::class.java, ACTION_RESUME_COUNTDOWN, 15))
        } else {
            // O sistema atualiza a contagem sozinho, sem acordar a app
            builder.setUsesChronometer(true)
                .setChronometerCountDown(true)
                .setShowWhen(true)
                .setWhen(System.currentTimeMillis() + remainingMs())
                .setContentText(getString(R.string.t_em_contagem))
            builder.addAction(0, getString(R.string.t_pausar), Notifications.servicePendingIntent(this, CountdownService::class.java, ACTION_PAUSE_COUNTDOWN, 16))
        }
        builder.addAction(0, getString(R.string.t_mais_1_min), Notifications.servicePendingIntent(this, CountdownService::class.java, ACTION_ADD_MINUTE, 17))
        builder.addAction(0, getString(R.string.t_cancelar), Notifications.servicePendingIntent(this, CountdownService::class.java, ACTION_CANCEL_COUNTDOWN, 18))
        return builder.build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacks(progressTick)
        cancelDue()
        player.stop()
        super.onDestroy()
    }
}
