package pt.ubi.di.pdm.multimer.ui.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.data.local.AppDatabase
import pt.ubi.di.pdm.multimer.data.model.CascadeEntity
import pt.ubi.di.pdm.multimer.data.repository.CascadeRepository
import pt.ubi.di.pdm.multimer.ui.fragments.SoundPickerSheet
import pt.ubi.di.pdm.multimer.ui.viewmodel.CascadeViewModel
import pt.ubi.di.pdm.multimer.ui.viewmodel.CascadeViewModelFactory
import pt.ubi.di.pdm.multimer.util.CascadeTemplates
import pt.ubi.di.pdm.multimer.util.Segmented
import pt.ubi.di.pdm.multimer.util.SoundLibrary
import pt.ubi.di.pdm.multimer.util.SoundUtils
import pt.ubi.di.pdm.multimer.util.TimeFmt
import pt.ubi.di.pdm.multimer.util.enableEdgeToEdge
import pt.ubi.di.pdm.multimer.util.onTextChanged

/**
 * Alarme sequencial: toca de X em X tempo. O número de toques e o período total
 * estão ligados (período = toques x intervalo), por isso editar um ajusta o outro.
 */
class IntervalCascadeEditorActivity : AppCompatActivity() {

    private val viewModel: CascadeViewModel by lazy {
        val database = AppDatabase.getDatabase(this)
        ViewModelProvider(this, CascadeViewModelFactory(CascadeRepository(database.cascadeDao())))[CascadeViewModel::class.java]
    }

    private val unitMs = longArrayOf(1_000L, 60_000L, 3_600_000L)

    private var cascadeId = -1L
    private var createdAt = System.currentTimeMillis()
    private var loadedSyncId = ""
    private var soundUri: String? = null
    private var soundTitle: String? = null
    private var syncing = false

    private lateinit var etTitle: EditText
    private lateinit var etInterval: EditText
    private lateinit var etCount: EditText
    private lateinit var etPeriod: EditText
    private lateinit var tvSummary: TextView
    private lateinit var tvSound: TextView
    private lateinit var switchUnlimited: MaterialSwitch
    private lateinit var switchVibration: MaterialSwitch
    private lateinit var switchManual: MaterialSwitch
    private lateinit var layoutLimited: View
    private lateinit var intervalUnit: Segmented
    private lateinit var periodUnit: Segmented

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_interval_editor)
        enableEdgeToEdge()

        etTitle = findViewById(R.id.etCascadeTitle)
        etInterval = findViewById(R.id.etIntervalValue)
        etCount = findViewById(R.id.etCount)
        etPeriod = findViewById(R.id.etPeriodValue)
        tvSummary = findViewById(R.id.tvIntervalSummary)
        tvSound = findViewById(R.id.tvSelectedSound)
        switchUnlimited = findViewById(R.id.switchUnlimited)
        switchVibration = findViewById(R.id.switchVibration)
        switchManual = findViewById(R.id.switchManual)
        layoutLimited = findViewById(R.id.layoutLimited)

        intervalUnit = Segmented(
            listOf<View>(findViewById<View>(R.id.segIntSec), findViewById<View>(R.id.segIntMin), findViewById<View>(R.id.segIntHour))
        ) { syncPeriodFromCount() }
        periodUnit = Segmented(
            listOf<View>(findViewById<View>(R.id.segPerSec), findViewById<View>(R.id.segPerMin), findViewById<View>(R.id.segPerHour))
        ) { syncCountFromPeriod() }

        etInterval.onTextChanged { syncPeriodFromCount() }
        etCount.onTextChanged { syncPeriodFromCount() }
        etPeriod.onTextChanged { syncCountFromPeriod() }
        switchUnlimited.setOnCheckedChangeListener { _, unlimited ->
            layoutLimited.visibility = if (unlimited) View.GONE else View.VISIBLE
            updateSummary()
        }

        // Valores iniciais: de 10 em 10 minutos, 12 vezes (2 h)
        intervalUnit.select(1)
        etInterval.setText("10")
        etCount.setText("12")
        syncPeriodFromCount()
        soundUri = SoundLibrary.DEFAULT_STEP
        soundTitle = SoundUtils.titleFor(this, soundUri)
        tvSound.text = soundTitle

        val tvTitle = findViewById<TextView>(R.id.tvEditorTitle)
        cascadeId = intent.getLongExtra(EXTRA_CASCADE_ID, -1L)
        if (cascadeId != -1L) {
            tvTitle.setText(R.string.t_editar_sequencia)
            findViewById<View>(R.id.card_btnDeleteEditor).visibility = View.VISIBLE
            viewModel.loadCascade(cascadeId) { data -> if (data != null) populate(data.cascade) else finish() }
        } else {
            // Novo: em branco, a partir de um modelo ou como cópia de uma existente
            val templateKey = intent.getStringExtra(EXTRA_TEMPLATE_KEY)
            val baseId = intent.getLongExtra(EXTRA_BASE_ID, -1L)
            if (templateKey != null) {
                CascadeTemplates.find(templateKey)?.let { populate(it.cascade) }
            } else if (baseId != -1L) {
                viewModel.loadCascade(baseId) { data ->
                    if (data != null) {
                        populate(data.cascade)
                        etTitle.setText(data.cascade.title + " (cópia)")
                    }
                }
            }
        }

        supportFragmentManager.setFragmentResultListener(SoundPickerSheet.REQUEST_KEY, this) { _, b ->
            soundUri = b.getString(SoundPickerSheet.RESULT_VALUE)
            soundTitle = b.getString(SoundPickerSheet.RESULT_TITLE)
            tvSound.text = SoundUtils.titleFor(this, soundUri)
        }
        findViewById<View>(R.id.layoutSelectSound).setOnClickListener {
            SoundPickerSheet.newInstance(soundUri, SoundPickerSheet.CONTEXT_STEP).show(supportFragmentManager, "sound_picker")
        }
        findViewById<MaterialButton>(R.id.btnCancelEditor).setOnClickListener { finish() }
        findViewById<MaterialButton>(R.id.btnSaveEditor).setOnClickListener { save() }
        findViewById<MaterialButton>(R.id.btnDeleteEditor).setOnClickListener {
            if (cascadeId != -1L) {
                viewModel.deleteCascade(CascadeEntity(id = cascadeId, title = ""))
            }
            finish()
        }
    }

    private fun populate(c: CascadeEntity) {
        if (cascadeId != -1L) loadedSyncId = c.syncId
        createdAt = c.createdAt
        etTitle.setText(c.title)
        val (value, unit) = bestUnit(c.intervalMillis)
        syncing = true
        intervalUnit.select(unit)
        etInterval.setText(value.toString())
        etCount.setText(if (c.repeatCount > 0) c.repeatCount.toString() else "12")
        syncing = false
        switchUnlimited.isChecked = c.repeatCount <= 0
        layoutLimited.visibility = if (c.repeatCount <= 0) View.GONE else View.VISIBLE
        switchVibration.isChecked = c.isVibrationEnabled
        switchManual.isChecked = !c.autoDismiss
        soundUri = c.soundUri
        soundTitle = c.soundTitle
        tvSound.text = SoundUtils.titleFor(this, c.soundUri)
        syncPeriodFromCount()
    }

    private fun intervalMs(): Long =
        (etInterval.text.toString().toLongOrNull() ?: 0L) * unitMs[intervalUnit.selectedIndex]

    private fun count(): Int = etCount.text.toString().toIntOrNull() ?: 0

    private fun periodMs(): Long =
        (etPeriod.text.toString().toLongOrNull() ?: 0L) * unitMs[periodUnit.selectedIndex]

    /** Devolve (valor, índice da unidade) na maior unidade que representa o tempo sem perder precisão. */
    private fun bestUnit(ms: Long): Pair<Long, Int> {
        if (ms <= 0L) return Pair(0L, 1)
        return when {
            ms % 3_600_000L == 0L -> Pair(ms / 3_600_000L, 2)
            ms % 60_000L == 0L -> Pair(ms / 60_000L, 1)
            else -> Pair(ms / 1_000L, 0)
        }
    }

    private fun syncPeriodFromCount() {
        if (syncing) return
        syncing = true
        val total = intervalMs() * count()
        if (total > 0L) {
            val (v, u) = bestUnit(total)
            periodUnit.select(u)
            etPeriod.setText(v.toString())
        } else {
            etPeriod.setText("")
        }
        syncing = false
        updateSummary()
    }

    private fun syncCountFromPeriod() {
        if (syncing) return
        syncing = true
        val interval = intervalMs()
        val c = if (interval > 0L) (periodMs() / interval).toInt() else 0
        etCount.setText(if (c > 0) c.toString() else "")
        syncing = false
        updateSummary()
    }

    private fun updateSummary() {
        val interval = intervalMs()
        tvSummary.text = when {
            interval <= 0L -> "Define o intervalo entre toques."
            switchUnlimited.isChecked -> "Toca a cada ${TimeFmt.human(interval)}, até parares."
            count() <= 0 -> "Define quantos toques queres."
            else -> {
                val c = count()
                val vezes = if (c == 1) "1 vez" else "$c vezes"
                "Toca $vezes, a cada ${TimeFmt.human(interval)}, durante ${TimeFmt.human(interval * c)}."
            }
        }
    }

    private fun save() {
        val interval = intervalMs()
        val unlimited = switchUnlimited.isChecked
        if (interval <= 0L) {
            Toast.makeText(this, R.string.t_define_o_intervalo_entre_toque, Toast.LENGTH_SHORT).show()
            return
        }
        if (!unlimited && count() <= 0) {
            Toast.makeText(this, R.string.t_define_quantos_toques_queres, Toast.LENGTH_SHORT).show()
            return
        }
        val title = etTitle.text.toString().trim().ifEmpty { "A cada ${TimeFmt.human(interval)}" }
        val cascade = CascadeEntity(
            id = if (cascadeId != -1L) cascadeId else 0L,
            title = title,
            createdAt = createdAt,
            type = CascadeEntity.TYPE_SEQUENTIAL,
            intervalMillis = interval,
            repeatCount = if (unlimited) 0 else count(),
            autoDismiss = !switchManual.isChecked,
            isVibrationEnabled = switchVibration.isChecked,
            soundUri = soundUri,
            soundTitle = soundTitle,
            syncId = loadedSyncId
        )
        viewModel.saveCascade(cascade, emptyList())
        finish()
    }

    companion object {
        const val EXTRA_CASCADE_ID = "extra_cascade_id"
        const val EXTRA_TEMPLATE_KEY = "extra_template_key"
        const val EXTRA_BASE_ID = "extra_base_id"

        fun newIntent(context: Context, cascadeId: Long = -1L, templateKey: String? = null, baseId: Long = -1L): Intent {
            return Intent(context, IntervalCascadeEditorActivity::class.java).apply {
                putExtra(EXTRA_CASCADE_ID, cascadeId)
                putExtra(EXTRA_TEMPLATE_KEY, templateKey)
                putExtra(EXTRA_BASE_ID, baseId)
            }
        }
    }
}
