package pt.ubi.di.pdm.multimer.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.materialswitch.MaterialSwitch
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.data.model.AlarmEntity
import pt.ubi.di.pdm.multimer.util.RepeatDays
import pt.ubi.di.pdm.multimer.util.RowActionsPopup
import pt.ubi.di.pdm.multimer.util.TimeFmt

class AlarmAdapter(
    private val onSwitchChanged: (AlarmEntity, Boolean) -> Unit,
    private val onItemClick: (AlarmEntity) -> Unit,
    private val actionsFor: (AlarmEntity) -> List<RowActionsPopup.Action>
) : ListAdapter<AlarmEntity, AlarmAdapter.AlarmViewHolder>(DiffCallback()) {

    fun alarmAt(position: Int): AlarmEntity? = currentList.getOrNull(position)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlarmViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_alarm, parent, false)
        return AlarmViewHolder(view)
    }

    override fun onBindViewHolder(holder: AlarmViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class AlarmViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvTime: TextView = itemView.findViewById(R.id.tvAlarmTime)
        private val tvDetails: TextView = itemView.findViewById(R.id.tvAlarmDetails)
        private val switchAlarm: MaterialSwitch = itemView.findViewById(R.id.switchAlarm)

        fun bind(alarm: AlarmEntity) {
            val ctx = itemView.context
            tvTime.text = TimeFmt.clock(ctx, alarm.hour, alarm.minute)

            val repeat = RepeatDays.describe(alarm.repeatDays)
            val base = if (alarm.label.isNotEmpty()) alarm.label + ", " + repeat else repeat
            // Campo de data do registo: última alteração (guardada em updatedAt)
            val changed = if (alarm.updatedAt > 0L) {
                val date = java.text.DateFormat.getDateInstance(java.text.DateFormat.SHORT).format(java.util.Date(alarm.updatedAt))
                ctx.getString(R.string.alarm_changed_on, date)
            } else ""
            tvDetails.text = if (changed.isEmpty()) base else base + ", " + changed

            val dim = if (alarm.isEnabled) 1f else 0.45f
            tvTime.alpha = dim
            tvDetails.alpha = dim

            switchAlarm.setOnCheckedChangeListener(null)
            switchAlarm.isChecked = alarm.isEnabled
            switchAlarm.setOnCheckedChangeListener { _, isChecked -> onSwitchChanged(alarm, isChecked) }

            itemView.setOnClickListener { onItemClick(alarm) }
            RowActionsPopup.attach(itemView) { actionsFor(alarm) }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<AlarmEntity>() {
        override fun areItemsTheSame(oldItem: AlarmEntity, newItem: AlarmEntity) = oldItem.id == newItem.id
        override fun areContentsTheSame(oldItem: AlarmEntity, newItem: AlarmEntity) = oldItem == newItem
    }
}
