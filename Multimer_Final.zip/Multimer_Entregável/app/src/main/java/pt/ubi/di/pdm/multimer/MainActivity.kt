package pt.ubi.di.pdm.multimer

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.content.res.ColorStateList
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.asLiveData
import eightbitlab.com.blurview.BlurView
import eightbitlab.com.blurview.RenderEffectBlur
import eightbitlab.com.blurview.RenderScriptBlur
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import pt.ubi.di.pdm.multimer.data.local.AppDatabase
import pt.ubi.di.pdm.multimer.data.repository.AlarmRepository
import pt.ubi.di.pdm.multimer.ui.activity.AlarmEditorActivity
import pt.ubi.di.pdm.multimer.sync.AuthManager
import pt.ubi.di.pdm.multimer.sync.SyncManager
import pt.ubi.di.pdm.multimer.ui.fragments.AccountSheet
import pt.ubi.di.pdm.multimer.ui.fragments.AlarmsFragment
import pt.ubi.di.pdm.multimer.ui.fragments.CascadeFragment
import pt.ubi.di.pdm.multimer.ui.fragments.CountdownFragment
import pt.ubi.di.pdm.multimer.ui.fragments.StopwatchFragment
import pt.ubi.di.pdm.multimer.util.AlarmScheduler
import pt.ubi.di.pdm.multimer.util.Notifications
import pt.ubi.di.pdm.multimer.util.Prefs
import pt.ubi.di.pdm.multimer.util.dpToPx

class MainActivity : AppCompatActivity() {

    private lateinit var navCard: View
    private lateinit var navHost: View
    private lateinit var tabViews: List<View>
    private var selectedTab = 0
    private var focusMode = false
    private var contentMaxWidth = 0
    private lateinit var fab: View
    private lateinit var btnProfile: View
    private lateinit var tvSyncBanner: TextView

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        askSpecialPermissionsOnce()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Notifications.ensureChannels(this)

        val blurViewNav = findViewById<BlurView>(R.id.blurViewNav)
        val rootLayout = findViewById<ViewGroup>(R.id.rootLayoutMain)
        navCard = findViewById(R.id.cardBottomNavContainer)
        navHost = findViewById(R.id.navHostFragment)
        fab = findViewById(R.id.fabAdd)
        btnProfile = findViewById(R.id.btnProfile)
        tvSyncBanner = findViewById(R.id.tvSyncBanner)
        SyncManager.init(this)

        // Ecrã de ponta a ponta: o conteúdo desce sob a barra de estado e a barra de abas flutua acima do gesto
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val navBaseMargin = navCard.dpToPx(12)
        val fabBaseMargin = navCard.dpToPx(20)
        val profileTopMargin = navCard.dpToPx(30)
        contentMaxWidth = navCard.dpToPx(640)
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            navHost.setPadding(bars.left, bars.top, bars.right, 0)
            val lp = navCard.layoutParams as ViewGroup.MarginLayoutParams
            lp.bottomMargin = navBaseMargin + bars.bottom
            navCard.layoutParams = lp
            val fabLp = fab.layoutParams as ViewGroup.MarginLayoutParams
            fabLp.marginEnd = fabBaseMargin + bars.right
            fab.layoutParams = fabLp
            // O perfil e o aviso acompanham a barra de estado
            (btnProfile.layoutParams as ViewGroup.MarginLayoutParams).topMargin = bars.top + profileTopMargin
            btnProfile.requestLayout()
            (tvSyncBanner.layoutParams as ViewGroup.MarginLayoutParams).topMargin = bars.top + navCard.dpToPx(4)
            tvSyncBanner.requestLayout()
            insets
        }

        // Vidro fosco (falha em silêncio em dispositivos sem suporte)
        try {
            val windowBackground = window.decorView.background
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                blurViewNav.setupWith(rootLayout, RenderEffectBlur())
                    .setFrameClearDrawable(windowBackground)
                    .setBlurRadius(20f)
            } else {
                @Suppress("DEPRECATION")
                blurViewNav.setupWith(rootLayout, RenderScriptBlur(this))
                    .setFrameClearDrawable(windowBackground)
                    .setBlurRadius(20f)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Barra de abas própria: ícone e texto empilhados e centrados, sem sobreposições
        tabViews = listOf<View>(
            findViewById<View>(R.id.tabAlarms),
            findViewById<View>(R.id.tabCascade),
            findViewById<View>(R.id.tabCountdown),
            findViewById<View>(R.id.tabStopwatch)
        )
        tabViews.forEachIndexed { index, view -> view.setOnClickListener { selectTab(index) } }

        btnProfile.setOnClickListener { openAccount() }
        tvSyncBanner.setOnClickListener { openAccount() }
        SyncManager.state.asLiveData().observe(this) { updateProfile(it) }

        fab.setOnClickListener {
            when (selectedTab) {
                0 -> startActivity(AlarmEditorActivity.newIntent(this))
                1 -> (supportFragmentManager.findFragmentByTag(TAB_TAGS[1]) as? CascadeFragment)?.onAddClicked()
            }
        }

        if (savedInstanceState == null) {
            selectTab(0)
            handleOpenTab(intent)
            requestPermissionsFlow()
            rescheduleAlarms()
        } else {
            // Na rotação o gestor de fragmentos já repôs o ecrã; só falta o destaque da aba
            selectedTab = savedInstanceState.getInt(STATE_TAB, 0)
            highlightTab(selectedTab)
            showTab(selectedTab)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(STATE_TAB, selectedTab)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleOpenTab(intent)
    }

    /** Depois de importar, mostra a aba (e o separador da Cascata) onde o conteúdo foi parar. */
    private fun handleOpenTab(source: Intent?) {
        val tab = source?.getIntExtra(EXTRA_OPEN_TAB, -1) ?: -1
        if (tab !in 0..3) return
        selectTab(tab)
        val sequential = source?.getIntExtra(EXTRA_OPEN_SEQUENTIAL, -1) ?: -1
        if (tab == 1 && sequential != -1) {
            supportFragmentManager.executePendingTransactions()
            (supportFragmentManager.findFragmentByTag(TAB_TAGS[1]) as? CascadeFragment)?.showType(sequential == 1)
        }
        source?.removeExtra(EXTRA_OPEN_TAB)
    }

    private fun highlightTab(index: Int) {
        tabViews.forEachIndexed { i, v -> v.isSelected = (i == index) }
        updateFab()
    }

    /** O botão de criar só existe nas abas Alarmes e Cascata, e some no modo de foco. */
    private fun openAccount() {
        AccountSheet().show(supportFragmentManager, "account")
    }

    /** O botão de perfil mostra a inicial do nome (ou um ícone) e um ponto com o estado da sincronização. */
    private fun updateProfile(state: SyncManager.State) {
        val user = AuthManager.currentUser(this)
        val icon = findViewById<View>(R.id.ivProfileIcon)
        val initial = findViewById<TextView>(R.id.tvProfileInitial)
        if (user != null) {
            icon.visibility = View.GONE
            initial.visibility = View.VISIBLE
            initial.text = AuthManager.displayName(user).take(1).uppercase()
        } else {
            icon.visibility = View.VISIBLE
            initial.visibility = View.GONE
        }

        val dot = findViewById<View>(R.id.viewSyncDot)
        val color = when (state) {
            SyncManager.State.SYNCED -> R.color.accent
            SyncManager.State.SYNCING, SyncManager.State.OFFLINE_PENDING, SyncManager.State.CHOICE_PENDING -> R.color.caution
            SyncManager.State.PAUSED -> R.color.text_tertiary
            else -> 0
        }
        if (color == 0) {
            dot.visibility = View.GONE
        } else {
            dot.visibility = View.VISIBLE
            dot.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, color))
        }

        // Aviso: só quando a sincronização não pode estar feita
        when (state) {
            SyncManager.State.CHOICE_PENDING -> {
                tvSyncBanner.setText(R.string.t_toca_para_escolher_o_que)
                tvSyncBanner.visibility = if (focusMode) View.GONE else View.VISIBLE
            }
            else -> tvSyncBanner.visibility = View.GONE
        }
    }

    private fun updateFab() {
        val show = !focusMode && (selectedTab == 0 || selectedTab == 1)
        fab.visibility = if (show) View.VISIBLE else View.GONE
    }

    /**
     * Ao abrir a app volta a agendar todos os alarmes ativos. É inofensivo (substitui o que existe)
     * e repara qualquer agendamento perdido, por exemplo se o sistema tiver terminado a app.
     */
    private fun rescheduleAlarms() {
        val appContext = applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            val repository = AlarmRepository(AppDatabase.getDatabase(appContext).alarmDao())
            for (alarm in repository.getEnabledAlarms()) AlarmScheduler.scheduleAlarm(appContext, alarm)
        }
    }

    private fun selectTab(index: Int) {
        selectedTab = index
        highlightTab(index)
        showTab(index)
    }

    private fun createTab(index: Int): Fragment = when (index) {
        1 -> CascadeFragment()
        2 -> CountdownFragment()
        3 -> StopwatchFragment()
        else -> AlarmsFragment()
    }

    /**
     * Os quatro ecrãs ficam sempre criados; trocar de aba só mostra um e esconde os outros.
     * Assim não há reconstrução nem animação (a causa da "imagem parada" ao mudar de aba),
     * cada aba mantém o seu estado e só a visível está ativa (os relógios das outras param).
     */
    private fun showTab(index: Int) {
        val fm = supportFragmentManager
        val tx = fm.beginTransaction().setReorderingAllowed(true)
        for (i in TAB_TAGS.indices) {
            var fragment = fm.findFragmentByTag(TAB_TAGS[i])
            if (fragment == null) {
                fragment = createTab(i)
                tx.add(R.id.navHostFragment, fragment, TAB_TAGS[i])
            }
            if (i == index) {
                tx.show(fragment)
                tx.setMaxLifecycle(fragment, Lifecycle.State.RESUMED)
            } else {
                tx.hide(fragment)
                tx.setMaxLifecycle(fragment, Lifecycle.State.STARTED)
            }
        }
        tx.commit()
    }

    /** O modo de foco do cronómetro esconde a barra de abas e as barras do sistema. */
    fun setFocusMode(enabled: Boolean) {
        focusMode = enabled
        updateFab()
        btnProfile.visibility = if (enabled) View.GONE else View.VISIBLE
        if (enabled) tvSyncBanner.visibility = View.GONE else updateProfile(SyncManager.state.value)
        // No modo de foco o conteúdo ocupa o ecrã todo; no resto fica limitado a uma coluna legível
        val hostLp = navHost.layoutParams as ConstraintLayout.LayoutParams
        hostLp.matchConstraintMaxWidth = if (enabled) navHost.dpToPx(4000) else contentMaxWidth
        navHost.layoutParams = hostLp
        navCard.visibility = if (enabled) View.GONE else View.VISIBLE
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (enabled) {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    // --- Permissões ---

    private fun requestPermissionsFlow() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            askSpecialPermissionsOnce()
        }
    }

    /**
     * Alarmes exatos e ecrã inteiro podem estar desligados nas definições do sistema.
     * Pergunta uma vez e explica porquê, em vez de falhar em silêncio.
     */
    private fun askSpecialPermissionsOnce() {
        if (Prefs.permissionsAsked(this)) return

        val needExact = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            !(getSystemService(ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
        val needFullScreen = Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE &&
            !(getSystemService(NotificationManager::class.java)).canUseFullScreenIntent()
        if (!needExact && !needFullScreen) return

        Prefs.setPermissionsAsked(this)
        val message = if (needExact) {
            "Para os alarmes tocarem à hora certa, a app precisa da permissão de alarmes e lembretes."
        } else {
            "Para o alarme aparecer sobre o ecrã de bloqueio, a app precisa da permissão de notificações em ecrã inteiro."
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.t_permissao_necessaria)
            .setMessage(message)
            .setPositiveButton(R.string.t_abrir_definicoes) { _, _ ->
                val intent = if (needExact && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName"))
                } else {
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                }
                try {
                    startActivity(intent)
                } catch (e: Exception) {
                    // sem ecrã de definições disponível
                }
            }
            .setNegativeButton(R.string.t_agora_nao, null)
            .show()
    }

    companion object {
        const val EXTRA_OPEN_TAB = "extra_open_tab"
        const val EXTRA_OPEN_SEQUENTIAL = "extra_open_sequential"
        private const val STATE_TAB = "state_tab"
        private val TAB_TAGS = listOf("tab_alarms", "tab_cascade", "tab_countdown", "tab_stopwatch")
    }
}
