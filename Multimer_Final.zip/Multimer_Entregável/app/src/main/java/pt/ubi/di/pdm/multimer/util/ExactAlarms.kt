package pt.ubi.di.pdm.multimer.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.os.Build

/**
 * Agendamento exato para temporizadores e passos de cascata. Um Handler pára de contar com o
 * ecrã desligado; o AlarmManager acorda o telemóvel à hora certa.
 */
object ExactAlarms {

    fun canScheduleExact(ctx: Context): Boolean {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return false
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
    }

    /** Ecrã do sistema onde se concede "Alarmes e lembretes"; null se não for necessário. */
    fun settingsIntent(ctx: Context): android.content.Intent? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return null
        return android.content.Intent(
            android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
            android.net.Uri.parse("package:" + ctx.packageName)
        )
    }

    fun setElapsed(ctx: Context, triggerAtElapsed: Long, pi: PendingIntent) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        try {
            if (canScheduleExact(ctx)) {
                am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAtElapsed, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAtElapsed, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAtElapsed, pi)
        }
    }

    fun cancel(ctx: Context, pi: PendingIntent) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        am.cancel(pi)
    }
}
