package pt.ubi.di.pdm.multimer.ui.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/**
 * Moldura do leitor de QR: escurece tudo menos um quadrado de cantos arredondados, ao centro,
 * e desenha quatro cantos brancos. O tamanho (FRAME_DP) tem de ser igual a zxing_framing_rect_* em view_scanner.xml.
 */
class ScanFrameView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    private val d = resources.displayMetrics.density
    private val frame = FRAME_DP * d
    private val radius = 28f * d
    private val len = 38f * d

    private val dim = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x99000000.toInt() }
    private val corner = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 4f * d
        strokeCap = Paint.Cap.ROUND
    }
    private val mask = Path()
    private val corners = Path()
    private val box = RectF()

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val l = cx - frame / 2f
        val t = cy - frame / 2f
        val r = cx + frame / 2f
        val b = cy + frame / 2f
        box.set(l, t, r, b)

        mask.reset()
        mask.fillType = Path.FillType.EVEN_ODD
        mask.addRect(0f, 0f, width.toFloat(), height.toFloat(), Path.Direction.CW)
        mask.addRoundRect(box, radius, radius, Path.Direction.CW)
        canvas.drawPath(mask, dim)

        corners.reset()
        val rr = radius
        // canto superior esquerdo
        corners.moveTo(l, t + len); corners.lineTo(l, t + rr)
        corners.arcTo(RectF(l, t, l + 2 * rr, t + 2 * rr), 180f, 90f); corners.lineTo(l + len, t)
        // canto superior direito
        corners.moveTo(r - len, t); corners.lineTo(r - rr, t)
        corners.arcTo(RectF(r - 2 * rr, t, r, t + 2 * rr), 270f, 90f); corners.lineTo(r, t + len)
        // canto inferior direito
        corners.moveTo(r, b - len); corners.lineTo(r, b - rr)
        corners.arcTo(RectF(r - 2 * rr, b - 2 * rr, r, b), 0f, 90f); corners.lineTo(r - len, b)
        // canto inferior esquerdo
        corners.moveTo(l + len, b); corners.lineTo(l + rr, b)
        corners.arcTo(RectF(l, b - 2 * rr, l + 2 * rr, b), 90f, 90f); corners.lineTo(l, b - len)
        canvas.drawPath(corners, corner)
    }

    companion object {
        const val FRAME_DP = 260f
    }
}
