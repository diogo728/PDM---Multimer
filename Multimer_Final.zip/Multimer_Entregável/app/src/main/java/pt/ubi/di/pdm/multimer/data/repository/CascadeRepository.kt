package pt.ubi.di.pdm.multimer.data.repository

import kotlinx.coroutines.flow.Flow
import pt.ubi.di.pdm.multimer.data.local.CascadeDao
import pt.ubi.di.pdm.multimer.data.model.CascadeEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeStepEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeWithSteps
import pt.ubi.di.pdm.multimer.sync.SyncManager

class CascadeRepository(private val cascadeDao: CascadeDao) {

    val allCascadesWithSteps: Flow<List<CascadeWithSteps>> = cascadeDao.getAllCascadesWithSteps()

    suspend fun getCascadeById(id: Long): CascadeWithSteps? = cascadeDao.getCascadeWithStepsById(id)

    suspend fun saveCascade(cascade: CascadeEntity, steps: List<CascadeStepEntity>): Long {
        val stamped = cascade.copy(
            syncId = cascade.syncId.ifBlank { SyncIds.newId() },
            updatedAt = SyncIds.now()
        )
        return write(stamped, steps)
    }

    /** Aplica o que veio da conta, sem o contar como alteração local (não volta a ser enviado). */
    suspend fun applyRemote(cascade: CascadeEntity, steps: List<CascadeStepEntity>): Long = write(cascade, steps)

    private suspend fun write(cascade: CascadeEntity, steps: List<CascadeStepEntity>): Long {
        val cascadeId = cascadeDao.insertCascade(cascade)
        cascadeDao.deleteStepsForCascade(cascadeId)
        val updatedSteps = steps.mapIndexed { index, step ->
            step.copy(cascadeId = cascadeId, stepOrder = index)
        }
        cascadeDao.insertSteps(updatedSteps)
        return cascadeId
    }

    suspend fun deleteCascade(cascade: CascadeEntity) {
        val full = if (cascade.syncId.isBlank()) cascadeDao.getCascadeWithStepsById(cascade.id)?.cascade ?: cascade else cascade
        cascadeDao.deleteCascade(full)
        if (full.syncId.isNotBlank()) SyncManager.onLocalDelete(SyncManager.CASCADES, full.syncId)
    }
}
