package pt.ubi.di.pdm.multimer.ui.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.util.QrCodes

/** QR code em ecrã inteiro e com brilho máximo, para projetar numa aula ou mostrar a um grupo. */
class QrProjectionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_qr_projection)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val attrs = window.attributes
        attrs.screenBrightness = 1f
        window.attributes = attrs

        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())

        val link = intent.getStringExtra(EXTRA_LINK) ?: ""
        findViewById<TextView>(R.id.tvProjectTitle).text = intent.getStringExtra(EXTRA_TITLE) ?: ""
        val bitmap = QrCodes.bitmap(link, 1000)
        if (bitmap != null) findViewById<ImageView>(R.id.ivProjectQr).setImageBitmap(bitmap) else finish()

        findViewById<View>(R.id.rootProjection).setOnClickListener { finish() }
    }

    companion object {
        private const val EXTRA_LINK = "extra_link"
        private const val EXTRA_TITLE = "extra_title"

        fun newIntent(context: Context, link: String, title: String): Intent =
            Intent(context, QrProjectionActivity::class.java)
                .putExtra(EXTRA_LINK, link)
                .putExtra(EXTRA_TITLE, title)
    }
}
