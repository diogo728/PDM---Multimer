package pt.ubi.di.pdm.multimer.ui.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import pt.ubi.di.pdm.multimer.R

/**
 * Deslizar para a direita revela um fundo vermelho com "Eliminar" (como no Outlook).
 * Opcionalmente permite reordenar (arrastar pela pega).
 */
class SwipeCallback(
    private val context: Context,
    canReorder: Boolean,
    private val onMoveItem: ((Int, Int) -> Unit)?,
    private val onSwipedItem: (Int) -> Unit
) : ItemTouchHelper.SimpleCallback(
    if (canReorder) ItemTouchHelper.UP or ItemTouchHelper.DOWN else 0,
    ItemTouchHelper.RIGHT
) {
    private val density = context.resources.displayMetrics.density
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.swipe_delete)
    }
    private val icon = ContextCompat.getDrawable(context, R.drawable.ic_trash)?.mutate()?.apply {
        setTint(ContextCompat.getColor(context, R.color.white))
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.white)
        textSize = 15f * density
        typeface = ResourcesCompat.getFont(context, R.font.multimer_sans_medium)
    }

    override fun getSwipeThreshold(viewHolder: RecyclerView.ViewHolder): Float = 0.4f

    /** Chamado quando o utilizador larga um item depois de o arrastar. */
    var onDragFinished: (() -> Unit)? = null

    override fun isLongPressDragEnabled(): Boolean = false

    override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
        super.clearView(recyclerView, viewHolder)
        onDragFinished?.invoke()
    }

    override fun onMove(
        recyclerView: RecyclerView,
        viewHolder: RecyclerView.ViewHolder,
        target: RecyclerView.ViewHolder
    ): Boolean {
        val from = viewHolder.bindingAdapterPosition
        val to = target.bindingAdapterPosition
        if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false
        onMoveItem?.invoke(from, to)
        return onMoveItem != null
    }

    override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
        val pos = viewHolder.bindingAdapterPosition
        if (pos != RecyclerView.NO_POSITION) onSwipedItem(pos)
    }

    override fun onChildDraw(
        c: Canvas,
        recyclerView: RecyclerView,
        viewHolder: RecyclerView.ViewHolder,
        dX: Float,
        dY: Float,
        actionState: Int,
        isCurrentlyActive: Boolean
    ) {
        val item = viewHolder.itemView
        if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE && dX > 0f) {
            c.drawRect(item.left.toFloat(), item.top.toFloat(), item.left + dX, item.bottom.toFloat(), bgPaint)
            val size = (24 * density).toInt()
            val margin = (22 * density).toInt()
            val gap = (10 * density).toInt()
            val label = "Eliminar"
            val labelW = labelPaint.measureText(label)
            val top = item.top + (item.height - size) / 2
            if (dX > size + margin * 2) {
                icon?.let {
                    it.setBounds(item.left + margin, top, item.left + margin + size, top + size)
                    it.draw(c)
                }
                val textX = item.left + margin + size + gap
                if (dX > textX - item.left + labelW + margin) {
                    val baseline = item.top + item.height / 2f - (labelPaint.ascent() + labelPaint.descent()) / 2f
                    c.drawText(label, textX.toFloat(), baseline, labelPaint)
                }
            }
        }
        super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive)
    }
}
