package pt.ubi.di.pdm.multimer.ui.fragments

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.data.local.AppDatabase
import pt.ubi.di.pdm.multimer.data.model.AlarmEntity
import pt.ubi.di.pdm.multimer.data.repository.AlarmRepository
import pt.ubi.di.pdm.multimer.ui.activity.AlarmEditorActivity
import pt.ubi.di.pdm.multimer.ui.adapter.AlarmAdapter
import pt.ubi.di.pdm.multimer.ui.view.InsetDividerDecoration
import pt.ubi.di.pdm.multimer.ui.view.SwipeCallback
import pt.ubi.di.pdm.multimer.ui.viewmodel.AlarmViewModel
import pt.ubi.di.pdm.multimer.ui.viewmodel.AlarmViewModelFactory
import pt.ubi.di.pdm.multimer.util.AlarmScheduler
import pt.ubi.di.pdm.multimer.share.ShareCodec
import pt.ubi.di.pdm.multimer.util.RepeatDays
import pt.ubi.di.pdm.multimer.util.RowActionsPopup
import pt.ubi.di.pdm.multimer.util.TimeFmt

class AlarmsFragment : Fragment() {

    private val viewModel: AlarmViewModel by lazy {
        val database = AppDatabase.getDatabase(requireContext())
        val repository = AlarmRepository(database.alarmDao())
        ViewModelProvider(this, AlarmViewModelFactory(repository))[AlarmViewModel::class.java]
    }

    private lateinit var adapter: AlarmAdapter
    private lateinit var tvSummary: TextView
    private lateinit var cardList: View
    private lateinit var layoutEmpty: View
    private var alarms: List<AlarmEntity> = emptyList()

    private val handler = Handler(Looper.getMainLooper())
    private val refreshRunnable = object : Runnable {
        override fun run() {
            updateSummary()
            handler.postDelayed(this, 30_000L)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_alarms, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val rv = view.findViewById<RecyclerView>(R.id.rvAlarms)
        tvSummary = view.findViewById(R.id.tvNextAlarmSummary)
        cardList = view.findViewById(R.id.cardAlarmList)
        layoutEmpty = view.findViewById(R.id.layoutEmptyState)

        adapter = AlarmAdapter(
            onSwitchChanged = { alarm, enabled -> setAlarmEnabled(alarm, enabled) },
            onItemClick = { alarm -> openEditor(alarm.id) },
            actionsFor = { alarm ->
                listOf(
                    RowActionsPopup.Action("Partilhar", R.drawable.ic_share) { shareAlarm(alarm) },
                    // A cópia fica desligada, pronta a ajustar a hora
                    RowActionsPopup.Action("Duplicar", R.drawable.ic_duplicate) {
                        viewModel.insertAlarm(alarm.copy(id = 0L, isEnabled = false, syncId = "", updatedAt = 0L, syncedAt = 0L))
                    },
                    RowActionsPopup.Action("Eliminar", R.drawable.ic_trash, destructive = true) { confirmDelete(alarm) }
                )
            }
        )
        rv.layoutManager = LinearLayoutManager(requireContext())
        rv.adapter = adapter
        rv.addItemDecoration(InsetDividerDecoration(requireContext()))

        ItemTouchHelper(SwipeCallback(requireContext(), false, null) { position ->
            adapter.alarmAt(position)?.let { confirmDelete(it) { adapter.notifyItemChanged(position) } }
        }).attachToRecyclerView(rv)

        view.findViewById<View>(R.id.btnEmptyAdd).setOnClickListener { openEditor(-1L) }
        view.findViewById<View>(R.id.btnReceiveAlarm).setOnClickListener {
            ImportSheet().show(parentFragmentManager, "import")
        }

        viewModel.allAlarms.observe(viewLifecycleOwner) { list ->
            alarms = list
            adapter.submitList(list)
            val empty = list.isEmpty()
            cardList.visibility = if (empty) View.GONE else View.VISIBLE
            layoutEmpty.visibility = if (empty) View.VISIBLE else View.GONE
            updateSummary()
        }
    }

    private fun shareAlarm(alarm: AlarmEntity) {
        val ctx = requireContext()
        val time = TimeFmt.clock(ctx, alarm.hour, alarm.minute)
        val summary = time + ", " + RepeatDays.describe(alarm.repeatDays)
        ShareSheet.newInstance(
            ShareCodec.encodeAlarm(alarm),
            if (alarm.label.isNotEmpty()) alarm.label else "Alarme das $time",
            "Alarme", summary
        ).show(parentFragmentManager, "share")
    }

    private fun setAlarmEnabled(alarm: AlarmEntity, enabled: Boolean) {
        val updated = alarm.copy(isEnabled = enabled)
        viewModel.setEnabled(alarm.id, enabled)
        if (enabled) {
            AlarmScheduler.scheduleAlarm(requireContext(), updated)
        } else {
            AlarmScheduler.cancelAlarm(requireContext(), updated)
        }
    }

    private fun confirmDelete(alarm: AlarmEntity, onCancel: () -> Unit = {}) {
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle(R.string.confirm_delete_title)
            .setMessage(R.string.confirm_delete_alarm)
            .setPositiveButton(R.string.t_eliminar) { _, _ -> deleteWithUndo(alarm) }
            .setNegativeButton(R.string.t_cancelar) { _, _ -> onCancel() }
            .setOnCancelListener { onCancel() }
            .show()
    }

    private fun deleteWithUndo(alarm: AlarmEntity) {
        val ctx = requireContext().applicationContext
        AlarmScheduler.cancelAlarm(ctx, alarm)
        viewModel.deleteAlarm(alarm)

        val root = requireActivity().findViewById<View>(R.id.rootLayoutMain)
        Snackbar.make(root, R.string.t_alarme_eliminado, Snackbar.LENGTH_LONG)
            .setAnchorView(R.id.fabAdd)
            .setAction(R.string.t_anular) {
                viewModel.insertAlarm(alarm) { newId ->
                    if (alarm.isEnabled) AlarmScheduler.scheduleAlarm(ctx, alarm.copy(id = newId))
                }
            }
            .show()
    }

    private fun updateSummary() {
        if (!isAdded) return
        val next = alarms.filter { it.isEnabled }.minByOrNull {
            AlarmScheduler.calculateNextTriggerMillis(it.hour, it.minute, it.repeatDays)
        }
        tvSummary.text = if (next == null) {
            "Nenhum alarme ativo"
        } else {
            "Próximo alarme daqui a " + AlarmScheduler.formatDurationUntil(next.hour, next.minute, next.repeatDays)
        }
    }

    private fun openEditor(id: Long) {
        startActivity(AlarmEditorActivity.newIntent(requireContext(), id))
    }

    override fun onResume() {
        super.onResume()
        handler.post(refreshRunnable)
    }

    override fun onPause() {
        handler.removeCallbacks(refreshRunnable)
        super.onPause()
    }
}
