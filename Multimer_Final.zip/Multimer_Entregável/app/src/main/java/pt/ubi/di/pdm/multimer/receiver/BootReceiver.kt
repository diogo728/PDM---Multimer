package pt.ubi.di.pdm.multimer.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import pt.ubi.di.pdm.multimer.data.local.AppDatabase
import pt.ubi.di.pdm.multimer.data.repository.AlarmRepository
import pt.ubi.di.pdm.multimer.util.AlarmScheduler

/**
 * Reagenda os alarmes ativos quando o sistema os pode ter perdido ou quando a hora deixa de bater certo:
 * reinício, atualização da app, mudança de hora (manual ou automática) e mudança de fuso horário.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED &&
            action != Intent.ACTION_TIME_CHANGED &&
            action != Intent.ACTION_TIMEZONE_CHANGED
        ) return

        // O fuso pode ter mudado: descarta o valor em cache antes de calcular as horas
        java.util.TimeZone.setDefault(null)

        val appContext = context.applicationContext
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getDatabase(appContext)
                val repository = AlarmRepository(db.alarmDao())
                for (alarm in repository.getEnabledAlarms()) {
                    AlarmScheduler.scheduleAlarm(appContext, alarm)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
