package pt.ubi.di.pdm.multimer.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import pt.ubi.di.pdm.multimer.data.local.AppDatabase
import pt.ubi.di.pdm.multimer.data.model.AlarmEntity
import pt.ubi.di.pdm.multimer.service.AlarmService
import pt.ubi.di.pdm.multimer.util.AlarmScheduler
import pt.ubi.di.pdm.multimer.util.RepeatDays

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val alarmId = intent.getLongExtra(AlarmScheduler.EXTRA_ALARM_ID, -1L)
        val isSnooze = intent.getBooleanExtra(AlarmScheduler.EXTRA_IS_SNOOZE, false)
        val appContext = context.applicationContext
        val pending = goAsync()

        // Toca já, sem esperar pela base de dados (a soneca ainda lê da base, pois não leva os dados)
        val hasPayload = !isSnooze && intent.hasExtra(AlarmScheduler.EXTRA_ALARM_HOUR)
        if (hasPayload) ringFromPayload(appContext, intent)

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = AppDatabase.getDatabase(appContext).alarmDao()
                val alarm = dao.getAlarmById(alarmId)
                if (alarm == null || (!alarm.isEnabled && !isSnooze)) return@launch

                if (!hasPayload) ring(appContext, alarm)

                if (!isSnooze) {
                    if (RepeatDays.isRepeating(alarm.repeatDays)) {
                        // Alarme repetido: agenda já a próxima ocorrência
                        AlarmScheduler.scheduleAlarm(appContext, alarm)
                    } else {
                        // Alarme único: fica desligado depois de tocar
                        dao.updateAlarm(alarm.copy(isEnabled = false))
                    }
                }
            } finally {
                pending.finish()
            }
        }
    }

    private fun ringFromPayload(context: Context, source: Intent) {
        val serviceIntent = Intent(context, AlarmService::class.java).apply {
            putExtra(AlarmScheduler.EXTRA_ALARM_ID, source.getLongExtra(AlarmScheduler.EXTRA_ALARM_ID, -1L))
            putExtra(AlarmScheduler.EXTRA_ALARM_LABEL, source.getStringExtra(AlarmScheduler.EXTRA_ALARM_LABEL) ?: "")
            putExtra(AlarmScheduler.EXTRA_ALARM_HOUR, source.getIntExtra(AlarmScheduler.EXTRA_ALARM_HOUR, 0))
            putExtra(AlarmScheduler.EXTRA_ALARM_MINUTE, source.getIntExtra(AlarmScheduler.EXTRA_ALARM_MINUTE, 0))
            putExtra(AlarmScheduler.EXTRA_ALARM_VIBRATE, source.getBooleanExtra(AlarmScheduler.EXTRA_ALARM_VIBRATE, true))
            putExtra(AlarmScheduler.EXTRA_ALARM_SOUND_URI, source.getStringExtra(AlarmScheduler.EXTRA_ALARM_SOUND_URI))
            putExtra(AlarmScheduler.EXTRA_ALARM_GRADUAL, source.getBooleanExtra(AlarmScheduler.EXTRA_ALARM_GRADUAL, true))
            putExtra(AlarmScheduler.EXTRA_ALARM_SNOOZE_ENABLED, source.getBooleanExtra(AlarmScheduler.EXTRA_ALARM_SNOOZE_ENABLED, true))
            putExtra(AlarmScheduler.EXTRA_ALARM_SNOOZE_MINUTES, source.getIntExtra(AlarmScheduler.EXTRA_ALARM_SNOOZE_MINUTES, 10))
        }
        ContextCompat.startForegroundService(context, serviceIntent)
    }

    private fun ring(context: Context, alarm: AlarmEntity) {
        val serviceIntent = Intent(context, AlarmService::class.java).apply {
            putExtra(AlarmScheduler.EXTRA_ALARM_ID, alarm.id)
            putExtra(AlarmScheduler.EXTRA_ALARM_LABEL, alarm.label)
            putExtra(AlarmScheduler.EXTRA_ALARM_HOUR, alarm.hour)
            putExtra(AlarmScheduler.EXTRA_ALARM_MINUTE, alarm.minute)
            putExtra(AlarmScheduler.EXTRA_ALARM_VIBRATE, alarm.isVibrationEnabled)
            putExtra(AlarmScheduler.EXTRA_ALARM_SOUND_URI, alarm.soundUri)
            putExtra(AlarmScheduler.EXTRA_ALARM_GRADUAL, alarm.isGradualVolume)
            putExtra(AlarmScheduler.EXTRA_ALARM_SNOOZE_ENABLED, alarm.isSnoozeEnabled)
            putExtra(AlarmScheduler.EXTRA_ALARM_SNOOZE_MINUTES, alarm.snoozeMinutes)
        }
        ContextCompat.startForegroundService(context, serviceIntent)
    }
}
