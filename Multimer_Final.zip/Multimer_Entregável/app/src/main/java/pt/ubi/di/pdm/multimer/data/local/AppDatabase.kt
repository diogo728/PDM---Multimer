package pt.ubi.di.pdm.multimer.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import pt.ubi.di.pdm.multimer.data.model.AlarmEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeStepEntity
import pt.ubi.di.pdm.multimer.data.model.TimerEntity

@Database(
    entities = [TimerEntity::class, AlarmEntity::class, CascadeEntity::class, CascadeStepEntity::class],
    version = 6,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun timerDao(): TimerDao
    abstract fun alarmDao(): AlarmDao
    abstract fun cascadeDao(): CascadeDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /** Uma coluna da versão 5 e o valor a usar quando a base de dados antiga não a tem. */
        private class Col(val name: String, val ddl: String, val fallback: String, val notNull: Boolean)

        private val ALARM_COLS = listOf(
            Col("id", "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL", "NULL", false),
            Col("hour", "`hour` INTEGER NOT NULL", "0", true),
            Col("minute", "`minute` INTEGER NOT NULL", "0", true),
            Col("isEnabled", "`isEnabled` INTEGER NOT NULL", "1", true),
            Col("label", "`label` TEXT NOT NULL", "''", true),
            Col("repeatDays", "`repeatDays` TEXT NOT NULL", "'Uma vez'", true),
            Col("isVibrationEnabled", "`isVibrationEnabled` INTEGER NOT NULL", "1", true),
            Col("soundUri", "`soundUri` TEXT", "NULL", false),
            Col("soundTitle", "`soundTitle` TEXT NOT NULL", "'Toque padrão'", true),
            Col("isSnoozeEnabled", "`isSnoozeEnabled` INTEGER NOT NULL DEFAULT 1", "1", true),
            Col("snoozeMinutes", "`snoozeMinutes` INTEGER NOT NULL DEFAULT 10", "10", true),
            Col("isGradualVolume", "`isGradualVolume` INTEGER NOT NULL DEFAULT 1", "1", true),
            Col("syncId", "`syncId` TEXT NOT NULL DEFAULT ''", "''", true),
            Col("updatedAt", "`updatedAt` INTEGER NOT NULL DEFAULT 0", "0", true),
            Col("syncedAt", "`syncedAt` INTEGER NOT NULL DEFAULT 0", "0", true)
        )

        private val TIMER_COLS = listOf(
            Col("id", "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL", "NULL", false),
            Col("title", "`title` TEXT NOT NULL", "''", true),
            Col("durationInMillis", "`durationInMillis` INTEGER NOT NULL", "0", true),
            Col("isVibrationEnabled", "`isVibrationEnabled` INTEGER NOT NULL", "1", true),
            Col("soundUri", "`soundUri` TEXT", "NULL", false),
            Col("autoDismiss", "`autoDismiss` INTEGER NOT NULL", "0", true),
            Col("nextTimerId", "`nextTimerId` INTEGER", "NULL", false),
            Col("createdAt", "`createdAt` INTEGER NOT NULL", "0", true),
            Col("syncId", "`syncId` TEXT NOT NULL DEFAULT ''", "''", true),
            Col("updatedAt", "`updatedAt` INTEGER NOT NULL DEFAULT 0", "0", true),
            Col("syncedAt", "`syncedAt` INTEGER NOT NULL DEFAULT 0", "0", true)
        )

        private val CASCADE_COLS = listOf(
            Col("id", "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL", "NULL", false),
            Col("title", "`title` TEXT NOT NULL", "''", true),
            Col("createdAt", "`createdAt` INTEGER NOT NULL", "0", true),
            Col("type", "`type` INTEGER NOT NULL DEFAULT 1", "1", true),
            Col("intervalMillis", "`intervalMillis` INTEGER NOT NULL DEFAULT 0", "0", true),
            Col("repeatCount", "`repeatCount` INTEGER NOT NULL DEFAULT 0", "0", true),
            Col("autoDismiss", "`autoDismiss` INTEGER NOT NULL DEFAULT 1", "1", true),
            Col("isVibrationEnabled", "`isVibrationEnabled` INTEGER NOT NULL DEFAULT 1", "1", true),
            Col("soundUri", "`soundUri` TEXT", "NULL", false),
            Col("soundTitle", "`soundTitle` TEXT", "NULL", false),
            Col("syncId", "`syncId` TEXT NOT NULL DEFAULT ''", "''", true),
            Col("updatedAt", "`updatedAt` INTEGER NOT NULL DEFAULT 0", "0", true),
            Col("syncedAt", "`syncedAt` INTEGER NOT NULL DEFAULT 0", "0", true)
        )

        private val STEP_COLS = listOf(
            Col("id", "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL", "NULL", false),
            Col("cascadeId", "`cascadeId` INTEGER NOT NULL", "0", true),
            Col("stepOrder", "`stepOrder` INTEGER NOT NULL", "0", true),
            Col("title", "`title` TEXT NOT NULL", "''", true),
            Col("durationInMillis", "`durationInMillis` INTEGER NOT NULL", "60000", true),
            Col("autoDismiss", "`autoDismiss` INTEGER NOT NULL", "1", true),
            Col("isVibrationEnabled", "`isVibrationEnabled` INTEGER NOT NULL", "1", true),
            Col("soundUri", "`soundUri` TEXT", "NULL", false),
            Col("soundTitle", "`soundTitle` TEXT", "NULL", false)
        )

        private fun createSql(table: String, cols: List<Col>, extra: String = ""): String =
            "CREATE TABLE IF NOT EXISTS `$table` (" + cols.joinToString(", ") { it.ddl } + extra + ")"

        private const val STEP_FK =
            ", FOREIGN KEY(`cascadeId`) REFERENCES `cascades`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE"

        private fun tableExists(db: SupportSQLiteDatabase, table: String): Boolean {
            db.query("SELECT name FROM sqlite_master WHERE type='table' AND name='$table'").use { return it.count > 0 }
        }

        private fun columnsOf(db: SupportSQLiteDatabase, table: String): Set<String> {
            val result = HashSet<String>()
            db.query("PRAGMA table_info(`$table`)").use {
                val idx = it.getColumnIndex("name")
                while (it.moveToNext()) result.add(it.getString(idx))
            }
            return result
        }

        /** Copia a tabela para uma cópia simples (sem chaves estrangeiras) e devolve as suas colunas. */
        private fun backup(db: SupportSQLiteDatabase, table: String): Set<String>? {
            if (!tableExists(db, table)) return null
            db.execSQL("DROP TABLE IF EXISTS `${table}_bak`")
            db.execSQL("CREATE TABLE `${table}_bak` AS SELECT * FROM `$table`")
            return columnsOf(db, "${table}_bak")
        }

        /** Preenche a tabela nova com o que a antiga tinha; o que faltar leva o valor por omissão. */
        private fun restore(db: SupportSQLiteDatabase, table: String, cols: List<Col>, old: Set<String>?) {
            if (old == null) return
            val target = cols.joinToString(", ") { "`${it.name}`" }
            val source = cols.joinToString(", ") { c ->
                when {
                    !old.contains(c.name) -> c.fallback
                    c.notNull && c.fallback != "NULL" -> "COALESCE(`${c.name}`, ${c.fallback})"
                    else -> "`${c.name}`"
                }
            }
            try {
                db.execSQL("INSERT OR IGNORE INTO `$table` ($target) SELECT $source FROM `${table}_bak`")
            } catch (e: Exception) {
                // Dados incompatíveis: a tabela nova fica vazia em vez de impedir a app de abrir
            }
            db.execSQL("DROP TABLE IF EXISTS `${table}_bak`")
        }

        /**
         * Leva qualquer versão anterior (1 a 5) para a versão 6 sem perder dados.
         * Em vez de ALTER TABLE, recria as tabelas com o esquema exato, copiando as colunas
         * que existirem. A ordem evita que apagar a tabela das cascatas apague os seus passos.
         */
        private fun upgradeToLatest(db: SupportSQLiteDatabase) {
            val oldAlarms = backup(db, "alarms")
            val oldTimers = backup(db, "timers")
            val oldCascades = backup(db, "cascades")
            val oldSteps = backup(db, "cascade_steps")

            // Primeiro os filhos, depois os pais
            db.execSQL("DROP TABLE IF EXISTS `cascade_steps`")
            db.execSQL("DROP TABLE IF EXISTS `cascades`")
            db.execSQL("DROP TABLE IF EXISTS `alarms`")
            db.execSQL("DROP TABLE IF EXISTS `timers`")

            db.execSQL(createSql("alarms", ALARM_COLS))
            db.execSQL(createSql("timers", TIMER_COLS))
            db.execSQL(createSql("cascades", CASCADE_COLS))
            db.execSQL(createSql("cascade_steps", STEP_COLS, STEP_FK))

            restore(db, "alarms", ALARM_COLS, oldAlarms)
            restore(db, "timers", TIMER_COLS, oldTimers)
            restore(db, "cascades", CASCADE_COLS, oldCascades)
            restore(db, "cascade_steps", STEP_COLS, oldSteps)

            // Cada item existente ganha um identificador único (igual em todos os aparelhos) e uma marca de alteração
            val now = System.currentTimeMillis()
            for (table in listOf("alarms", "timers", "cascades")) {
                db.execSQL("UPDATE `$table` SET syncId = lower(hex(randomblob(16))) WHERE syncId = ''")
                db.execSQL("UPDATE `$table` SET updatedAt = $now WHERE updatedAt = 0")
            }

            // As antigas "sequências" (passos chamados "Alerta N") passam a ser cascatas sequenciais.
            if (oldCascades != null && !oldCascades.contains("type")) {
                db.execSQL(
                    "UPDATE cascades SET type = 0, " +
                        "intervalMillis = (SELECT durationInMillis FROM cascade_steps " +
                        "WHERE cascadeId = cascades.id ORDER BY stepOrder LIMIT 1), " +
                        "repeatCount = (SELECT COUNT(*) FROM cascade_steps WHERE cascadeId = cascades.id) " +
                        "WHERE id IN (SELECT cascadeId FROM cascade_steps GROUP BY cascadeId " +
                        "HAVING COUNT(*) > 1 AND SUM(CASE WHEN title LIKE 'Alerta %' THEN 0 ELSE 1 END) = 0)"
                )
                db.execSQL("DELETE FROM cascade_steps WHERE cascadeId IN (SELECT id FROM cascades WHERE type = 0)")
            }
        }

        private fun migration(from: Int) = object : Migration(from, 6) {
            override fun migrate(db: SupportSQLiteDatabase) = upgradeToLatest(db)
        }

        val MIGRATION_1_6: Migration = migration(1)
        val MIGRATION_2_6: Migration = migration(2)
        val MIGRATION_3_6: Migration = migration(3)
        val MIGRATION_4_6: Migration = migration(4)
        val MIGRATION_5_6: Migration = migration(5)

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "multimer_database"
                )
                    .addMigrations(MIGRATION_1_6, MIGRATION_2_6, MIGRATION_3_6, MIGRATION_4_6, MIGRATION_5_6)
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
