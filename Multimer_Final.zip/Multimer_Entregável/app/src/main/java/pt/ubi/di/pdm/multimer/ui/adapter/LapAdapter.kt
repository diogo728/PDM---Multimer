package pt.ubi.di.pdm.multimer.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.util.StopwatchStore
import pt.ubi.di.pdm.multimer.util.TimeFmt

/** Lista de voltas, da mais recente para a mais antiga; a melhor fica a verde e a pior a vermelho. */
class LapAdapter : RecyclerView.Adapter<LapAdapter.VH>() {

    private var laps: List<StopwatchStore.Lap> = emptyList()
    private var bestNumber = -1
    private var worstNumber = -1

    fun submit(newLaps: List<StopwatchStore.Lap>) {
        laps = newLaps
        if (newLaps.size >= 3) {
            bestNumber = newLaps.minByOrNull { it.lapMs }?.number ?: -1
            worstNumber = newLaps.maxByOrNull { it.lapMs }?.number ?: -1
        } else {
            bestNumber = -1
            worstNumber = -1
        }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        return VH(LayoutInflater.from(parent.context).inflate(R.layout.item_lap, parent, false))
    }

    override fun getItemCount(): Int = laps.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val lap = laps[position]
        val ctx = holder.itemView.context
        holder.number.text = "Volta ${lap.number}"
        holder.time.text = TimeFmt.stopwatch(lap.lapMs)
        val color = when (lap.number) {
            bestNumber -> R.color.accent
            worstNumber -> R.color.destructive
            else -> R.color.text_primary
        }
        holder.number.setTextColor(ContextCompat.getColor(ctx, color))
        holder.time.setTextColor(ContextCompat.getColor(ctx, color))
    }

    class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val number: TextView = itemView.findViewById(R.id.tvLapNumber)
        val time: TextView = itemView.findViewById(R.id.tvLapTime)
    }
}
