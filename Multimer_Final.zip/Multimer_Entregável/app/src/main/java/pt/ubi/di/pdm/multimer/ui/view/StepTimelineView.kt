package pt.ubi.di.pdm.multimer.ui.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import pt.ubi.di.pdm.multimer.R

/**
 * Barra de progresso por passos. Os passos concluídos ficam preenchidos, o atual vai enchendo
 * e os restantes ficam vazios. Pausada, o preenchimento passa a laranja.
 */
class StepTimelineView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val density = resources.displayMetrics.density
    private val gapPx = 3f * density
    private val rect = RectF()

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.ring_track)
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.accent)
    }
    private val accentColor = ContextCompat.getColor(context, R.color.accent)
    private val pausedColor = ContextCompat.getColor(context, R.color.caution)

    private var weights: List<Float> = listOf(1f)
    private var currentIndex = 0
    private var currentFraction = 0f
    private var paused = false

    fun setSegments(newWeights: List<Float>) {
        if (newWeights.isEmpty() || newWeights == weights) return
        weights = newWeights
        invalidate()
    }

    fun setProgress(index: Int, fraction: Float, isPaused: Boolean) {
        val f = fraction.coerceIn(0f, 1f)
        if (index == currentIndex && isPaused == paused && kotlin.math.abs(f - currentFraction) < 0.002f) return
        currentIndex = index
        currentFraction = f
        paused = isPaused
        fillPaint.color = if (isPaused) pausedColor else accentColor
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val n = weights.size
        val h = height.toFloat()
        val radius = h / 2f
        val usable = width - gapPx * (n - 1)
        if (usable <= 0f) return
        val sum = weights.sum()
        var left = 0f
        for (i in 0 until n) {
            val segW = usable * weights[i] / sum
            rect.set(left, 0f, left + segW, h)
            canvas.drawRoundRect(rect, radius, radius, trackPaint)

            val fillW = when {
                i < currentIndex -> segW
                i == currentIndex -> segW * currentFraction
                else -> 0f
            }
            if (fillW > 0f) {
                rect.set(left, 0f, left + maxOf(fillW, minOf(h, segW)), h)
                if (fillW < h && i == currentIndex) rect.right = left + maxOf(fillW, h * 0.6f)
                canvas.drawRoundRect(rect, radius, radius, fillPaint)
            }
            left += segW + gapPx
        }
    }
}
