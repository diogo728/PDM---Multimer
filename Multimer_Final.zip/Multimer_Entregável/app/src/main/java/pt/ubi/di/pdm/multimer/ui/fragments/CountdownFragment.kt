package pt.ubi.di.pdm.multimer.ui.fragments

import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.data.local.AppDatabase
import pt.ubi.di.pdm.multimer.data.model.TimerEntity
import pt.ubi.di.pdm.multimer.data.repository.TimerRepository
import pt.ubi.di.pdm.multimer.service.CountdownService
import pt.ubi.di.pdm.multimer.sync.SyncManager
import pt.ubi.di.pdm.multimer.ui.adapter.RecentTimerAdapter
import pt.ubi.di.pdm.multimer.ui.view.InsetDividerDecoration
import pt.ubi.di.pdm.multimer.ui.view.RingProgressView
import pt.ubi.di.pdm.multimer.ui.view.SwipeCallback
import pt.ubi.di.pdm.multimer.ui.view.WheelPicker
import pt.ubi.di.pdm.multimer.ui.viewmodel.TimerViewModel
import pt.ubi.di.pdm.multimer.ui.viewmodel.TimerViewModelFactory
import pt.ubi.di.pdm.multimer.util.Prefs
import pt.ubi.di.pdm.multimer.util.SoundUtils
import pt.ubi.di.pdm.multimer.util.TimeFmt
import pt.ubi.di.pdm.multimer.util.addSpringPressAnimation
import java.util.Calendar

/** Temporizador clássico: roda de horas, minutos e segundos, anel de progresso e recentes. */
class CountdownFragment : Fragment() {

    private val viewModel: TimerViewModel by lazy {
        val db = AppDatabase.getDatabase(requireContext())
        ViewModelProvider(this, TimerViewModelFactory(TimerRepository(db.timerDao())))[TimerViewModel::class.java]
    }

    private lateinit var wheelH: WheelPicker
    private lateinit var wheelM: WheelPicker
    private lateinit var wheelS: WheelPicker
    private lateinit var layoutPicker: View
    private lateinit var layoutRunning: View
    private lateinit var layoutSettings: View
    private lateinit var ring: RingProgressView
    private lateinit var tvRemaining: TextView
    private lateinit var tvRunLabel: TextView
    private lateinit var tvEndsAt: TextView
    private lateinit var btnCancel: MaterialButton
    private lateinit var btnAddMinute: MaterialButton
    private lateinit var spacerAdd: View
    private lateinit var btnMain: MaterialButton
    private lateinit var etLabel: EditText
    private lateinit var tvSound: TextView
    private lateinit var switchVibrate: MaterialSwitch
    private lateinit var switchAuto: MaterialSwitch
    private lateinit var tvRecentsHeader: View
    private lateinit var cardRecents: View
    private lateinit var adapter: RecentTimerAdapter

    private var soundUri: String? = null
    private var soundTitle: String = "Toque padrão"
    private var startRequestedAt = 0L

    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            render()
            handler.postDelayed(this, 200L)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_countdown, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val ctx = requireContext()

        wheelH = view.findViewById(R.id.wheelTimerH)
        wheelM = view.findViewById(R.id.wheelTimerM)
        wheelS = view.findViewById(R.id.wheelTimerS)
        layoutPicker = view.findViewById(R.id.layoutPicker)
        layoutRunning = view.findViewById(R.id.layoutRunning)
        layoutSettings = view.findViewById(R.id.layoutTimerSettings)
        ring = view.findViewById(R.id.ringTimer)
        tvRemaining = view.findViewById(R.id.tvTimerRemaining)
        tvRunLabel = view.findViewById(R.id.tvTimerRunLabel)
        tvEndsAt = view.findViewById(R.id.tvTimerEndsAt)
        btnCancel = view.findViewById(R.id.btnTimerCancel)
        btnAddMinute = view.findViewById(R.id.btnTimerAddMinute)
        spacerAdd = view.findViewById(R.id.spacerAddMinute)
        btnMain = view.findViewById(R.id.btnTimerMain)
        etLabel = view.findViewById(R.id.etTimerLabel)
        tvSound = view.findViewById(R.id.tvSelectedSound)
        switchVibrate = view.findViewById(R.id.switchTimerVibrate)
        switchAuto = view.findViewById(R.id.switchTimerAuto)
        tvRecentsHeader = view.findViewById(R.id.tvRecentsHeader)
        cardRecents = view.findViewById(R.id.cardRecents)

        wheelH.setNumberRange(0, 23, 0)
        wheelM.setNumberRange(0, 59, 10)
        wheelS.setNumberRange(0, 59, 0)

        soundUri = Prefs.timerSoundUri(ctx)
        soundTitle = SoundUtils.titleFor(ctx, soundUri)
        tvSound.text = soundTitle
        switchVibrate.isChecked = Prefs.timerVibrate(ctx)
        switchAuto.isChecked = Prefs.timerAutoStop(ctx)
        switchVibrate.setOnCheckedChangeListener { _, c ->
            Prefs.setTimerVibrate(ctx, c)
            SyncManager.notifySettingsChanged()
        }
        switchAuto.setOnCheckedChangeListener { _, c ->
            Prefs.setTimerAutoStop(ctx, c)
            SyncManager.notifySettingsChanged()
        }

        btnMain.addSpringPressAnimation()
        btnCancel.addSpringPressAnimation()

        parentFragmentManager.setFragmentResultListener(SoundPickerSheet.REQUEST_KEY, viewLifecycleOwner) { _, b ->
            soundUri = b.getString(SoundPickerSheet.RESULT_VALUE)
            soundTitle = b.getString(SoundPickerSheet.RESULT_TITLE) ?: SoundUtils.titleFor(ctx, soundUri)
            tvSound.text = soundTitle
            Prefs.setTimerSound(ctx, soundUri, soundTitle)
            SyncManager.notifySettingsChanged()
        }
        view.findViewById<View>(R.id.layoutSelectSound).setOnClickListener {
            SoundPickerSheet.newInstance(soundUri, SoundPickerSheet.CONTEXT_TIMER)
                .show(parentFragmentManager, "sound_picker")
        }

        btnMain.setOnClickListener { onMainClicked() }
        btnCancel.setOnClickListener {
            if (CountdownService.isRunning) send(CountdownService.ACTION_CANCEL_COUNTDOWN)
        }
        btnAddMinute.setOnClickListener { send(CountdownService.ACTION_ADD_MINUTE) }

        adapter = RecentTimerAdapter(
            onSelect = { t -> applyToPicker(t) },
            onPlay = { t ->
                applyToPicker(t)
                start(t.durationInMillis, t.title, t.soundUri, t.isVibrationEnabled, t.autoDismiss, false)
            }
        )
        val rv = view.findViewById<RecyclerView>(R.id.rvRecents)
        rv.layoutManager = LinearLayoutManager(ctx)
        rv.adapter = adapter
        rv.addItemDecoration(InsetDividerDecoration(ctx))
        ItemTouchHelper(SwipeCallback(ctx, false, null) { position ->
            adapter.itemAt(position)?.let { viewModel.deleteTimer(it) }
        }).attachToRecyclerView(rv)

        viewModel.recentTimers.observe(viewLifecycleOwner) { list ->
            val items = list ?: emptyList()
            adapter.submitList(items)
            val v = if (items.isEmpty()) View.GONE else View.VISIBLE
            tvRecentsHeader.visibility = v
            cardRecents.visibility = v
        }
        render()
    }

    private fun selectedDuration(): Long =
        (wheelH.value * 3600L + wheelM.value * 60L + wheelS.value) * 1000L

    private fun applyToPicker(t: TimerEntity) {
        val sec = t.durationInMillis / 1000L
        wheelH.value = (sec / 3600).toInt().coerceIn(0, 23)
        wheelM.value = ((sec % 3600) / 60).toInt()
        wheelS.value = (sec % 60).toInt()
        etLabel.setText(t.title)
    }

    private fun onMainClicked() {
        when {
            !CountdownService.isRunning -> {
                val duration = selectedDuration()
                if (duration <= 0L) return
                start(duration, etLabel.text.toString().trim(), soundUri, switchVibrate.isChecked, switchAuto.isChecked, true)
            }
            CountdownService.isRinging -> send(CountdownService.ACTION_STOP_RING)
            CountdownService.isPaused -> send(CountdownService.ACTION_RESUME_COUNTDOWN)
            else -> send(CountdownService.ACTION_PAUSE_COUNTDOWN)
        }
    }

    private fun start(durationMs: Long, label: String, sound: String?, vibrate: Boolean, autoStop: Boolean, record: Boolean) {
        val ctx = requireContext()
        val intent = Intent(ctx, CountdownService::class.java).apply {
            action = CountdownService.ACTION_START_COUNTDOWN
            putExtra(CountdownService.EXTRA_DURATION_MS, durationMs)
            putExtra(CountdownService.EXTRA_LABEL, label)
            putExtra(CountdownService.EXTRA_SOUND_URI, sound)
            putExtra(CountdownService.EXTRA_VIBRATE, vibrate)
            putExtra(CountdownService.EXTRA_AUTO_STOP, autoStop)
        }
        ContextCompat.startForegroundService(ctx, intent)
        startRequestedAt = SystemClock.elapsedRealtime()
        viewModel.recordRecent(
            TimerEntity(
                title = label,
                durationInMillis = durationMs,
                isVibrationEnabled = vibrate,
                soundUri = sound,
                autoDismiss = autoStop
            )
        )
        handler.postDelayed({ render() }, 150L)
    }

    private fun send(action: String) {
        requireContext().startService(Intent(requireContext(), CountdownService::class.java).setAction(action))
        handler.postDelayed({ render() }, 120L)
    }

    private fun style(button: MaterialButton, bg: Int, fg: Int, text: String) {
        val c = requireContext()
        button.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(c, bg))
        button.setTextColor(ContextCompat.getColor(c, fg))
        button.text = text
    }

    private fun render() {
        if (!isAdded || view == null) return
        val running = CountdownService.isRunning
        val justStarted = SystemClock.elapsedRealtime() - startRequestedAt < 1500L
        if (!running && justStarted) return

        layoutPicker.visibility = if (running) View.GONE else View.VISIBLE
        layoutSettings.visibility = if (running) View.GONE else View.VISIBLE
        layoutRunning.visibility = if (running) View.VISIBLE else View.GONE
        btnAddMinute.visibility = if (running) View.VISIBLE else View.GONE
        spacerAdd.visibility = if (running) View.VISIBLE else View.GONE
        view?.keepScreenOn = running

        if (!running) {
            style(btnMain, R.color.accent_soft, R.color.accent, "Iniciar")
            val enabled = selectedDuration() > 0L
            btnMain.isEnabled = enabled
            btnMain.alpha = if (enabled) 1f else 0.4f
            btnCancel.isEnabled = false
            btnCancel.alpha = 0.4f
            return
        }

        btnMain.isEnabled = true
        btnMain.alpha = 1f
        btnCancel.isEnabled = true
        btnCancel.alpha = 1f
        tvRunLabel.text = CountdownService.label.ifBlank { "Temporizador" }

        when {
            CountdownService.isRinging -> {
                style(btnMain, R.color.destructive_soft, R.color.destructive, "Parar")
                tvRemaining.setText(R.string.t_00_00)
                tvRemaining.alpha = if ((SystemClock.elapsedRealtime() / 500L) % 2L == 0L) 1f else 0.3f
                tvEndsAt.setText(R.string.t_terminou)
                ring.progress = 0f
            }
            CountdownService.isPaused -> {
                style(btnMain, R.color.accent_soft, R.color.accent, "Retomar")
                tvRemaining.alpha = 1f
                updateCountdownTexts()
                tvEndsAt.setText(R.string.t_em_pausa)
            }
            else -> {
                style(btnMain, R.color.caution_soft, R.color.caution, "Pausar")
                tvRemaining.alpha = 1f
                updateCountdownTexts()
                val cal = Calendar.getInstance().apply { timeInMillis = CountdownService.endsAtWallClock() }
                tvEndsAt.text = TimeFmt.clockWithSuffix(
                    requireContext(), cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE)
                )
            }
        }
    }

    private fun updateCountdownTexts() {
        val rem = CountdownService.remainingMs()
        tvRemaining.text = TimeFmt.countdown(rem)
        val total = CountdownService.totalMs
        ring.progress = if (total > 0L) rem.toFloat() / total.toFloat() else 0f
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }
}
