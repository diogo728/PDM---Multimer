package pt.ubi.di.pdm.multimer.ui.activity

import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.journeyapps.barcodescanner.CaptureManager
import com.journeyapps.barcodescanner.DecoratedBarcodeView
import pt.ubi.di.pdm.multimer.R

/**
 * Leitor de QR code: janela quadrada com cantos arredondados, sempre na vertical.
 * Usa o CaptureManager da biblioteca ZXing, por isso devolve o resultado ao ScanContract como o leitor original.
 */
class ScanActivity : AppCompatActivity() {

    private lateinit var capture: CaptureManager
    private lateinit var scanner: DecoratedBarcodeView
    private var torchOn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scan)

        // Ecrã de ponta a ponta com ícones claros da barra de estado (o fundo é a câmara)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = false
        val topBar = findViewById<View>(R.id.layoutScanTop)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.rootScan)) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            topBar.setPadding(topBar.paddingLeft, bars.top, topBar.paddingRight, topBar.paddingBottom)
            insets
        }

        scanner = findViewById(R.id.zxing_barcode_scanner)
        capture = CaptureManager(this, scanner)
        capture.initializeFromIntent(intent, savedInstanceState)
        capture.decode()

        findViewById<MaterialButton>(R.id.btnScanClose).setOnClickListener { finish() }
        val btnTorch = findViewById<MaterialButton>(R.id.btnScanTorch)
        if (packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)) {
            btnTorch.setOnClickListener {
                torchOn = !torchOn
                if (torchOn) scanner.setTorchOn() else scanner.setTorchOff()
            }
        } else {
            btnTorch.visibility = View.GONE
        }
    }

    override fun onResume() {
        super.onResume()
        capture.onResume()
    }

    override fun onPause() {
        super.onPause()
        capture.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        capture.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        capture.onSaveInstanceState(outState)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        capture.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }
}
