package pt.ubi.di.pdm.multimer.ui.fragments

import android.content.res.ColorStateList
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.util.Segmented
import pt.ubi.di.pdm.multimer.util.SoundLibrary
import pt.ubi.di.pdm.multimer.util.SoundUtils

/**
 * Escolha de som a partir da biblioteca da app: "Sem som" em primeiro lugar e depois
 * toques curtos, médios e longos. Tocar numa linha seleciona e pré-escuta; "Concluir" confirma.
 */
class SoundPickerSheet : BottomSheetDialogFragment() {

    private var selected: String = SoundLibrary.DEFAULT_TIMER
    private var category = SoundLibrary.Category.SHORT
    private var previewing: String? = null
    private var player: MediaPlayer? = null

    private lateinit var containerSilent: LinearLayout
    private lateinit var containerSounds: LinearLayout
    private lateinit var tvHint: TextView
    private lateinit var segmented: Segmented

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.sheet_sound_picker, container, false)
    }

    override fun onStart() {
        super.onStart()
        val dlg = dialog as? BottomSheetDialog ?: return
        dlg.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dlg.behavior.skipCollapsed = true
        dlg.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.backgroundTintList =
            ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.bg_grouped))
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val args = requireArguments()

        selected = if (savedInstanceState != null) {
            savedInstanceState.getString(STATE_SELECTED) ?: SoundLibrary.DEFAULT_TIMER
        } else {
            args.getString(ARG_CURRENT) ?: SoundLibrary.DEFAULT_TIMER
        }
        category = if (savedInstanceState != null) {
            SoundLibrary.Category.values()[savedInstanceState.getInt(STATE_CATEGORY, 0)]
        } else {
            SoundLibrary.find(selected)?.category ?: when (args.getInt(ARG_CONTEXT, CONTEXT_STEP)) {
                CONTEXT_ALARM -> SoundLibrary.Category.LONG
                CONTEXT_TIMER -> SoundLibrary.Category.MEDIUM
                else -> SoundLibrary.Category.SHORT
            }
        }

        containerSilent = view.findViewById(R.id.containerSilent)
        containerSounds = view.findViewById(R.id.containerSounds)
        tvHint = view.findViewById(R.id.tvCategoryHint)

        segmented = Segmented(
            listOf<View>(
                view.findViewById<View>(R.id.segShort),
                view.findViewById<View>(R.id.segMedium),
                view.findViewById<View>(R.id.segLong)
            )
        ) { index ->
            category = SoundLibrary.Category.values()[index]
            stopPreview()
            render()
        }
        segmented.select(category.ordinal)

        view.findViewById<MaterialButton>(R.id.btnSoundCancel).setOnClickListener { dismiss() }
        view.findViewById<MaterialButton>(R.id.btnSoundDone).setOnClickListener {
            parentFragmentManager.setFragmentResult(
                REQUEST_KEY,
                bundleOf(RESULT_VALUE to selected, RESULT_TITLE to SoundUtils.titleFor(requireContext(), selected))
            )
            dismiss()
        }
        render()
    }

    private fun render() {
        val inflater = LayoutInflater.from(requireContext())

        containerSilent.removeAllViews()
        addRow(
            inflater, containerSilent,
            title = "Sem som", meta = "Só vibração, se estiver ativa",
            iconRes = R.drawable.ic_mute, neutral = true,
            isSelected = selected == SoundUtils.SILENT, isPlaying = false
        ) {
            selected = SoundUtils.SILENT
            stopPreview()
            render()
        }

        tvHint.text = category.hint
        containerSounds.removeAllViews()
        val sounds = SoundLibrary.byCategory(category)
        sounds.forEachIndexed { index, sound ->
            addRow(
                inflater, containerSounds,
                title = sound.title, meta = sound.durationLabel,
                iconRes = if (previewing == sound.key) R.drawable.ic_pause else R.drawable.ic_play,
                neutral = false,
                isSelected = selected == sound.key, isPlaying = previewing == sound.key
            ) {
                selected = sound.key
                togglePreview(sound)
            }
            if (index < sounds.size - 1) addDivider(containerSounds)
        }
    }

    private fun addRow(
        inflater: LayoutInflater,
        into: LinearLayout,
        title: String,
        meta: String,
        iconRes: Int,
        neutral: Boolean,
        isSelected: Boolean,
        isPlaying: Boolean,
        onClick: () -> Unit
    ) {
        val row = inflater.inflate(R.layout.item_sound_row, into, false)
        val icon = row.findViewById<ImageView>(R.id.ivSoundIcon)
        icon.setImageResource(iconRes)
        if (neutral) {
            icon.setBackgroundResource(R.drawable.bg_circle_neutral)
            icon.setColorFilter(ContextCompat.getColor(requireContext(), R.color.text_primary))
        } else {
            icon.setBackgroundResource(if (isPlaying) R.drawable.bg_circle_accent_soft else R.drawable.bg_circle_neutral)
            icon.setColorFilter(ContextCompat.getColor(requireContext(), if (isPlaying) R.color.accent else R.color.text_primary))
        }
        row.findViewById<TextView>(R.id.tvSoundName).text = title
        row.findViewById<TextView>(R.id.tvSoundMeta).text = meta
        row.findViewById<View>(R.id.ivSoundCheck).visibility = if (isSelected) View.VISIBLE else View.INVISIBLE
        row.setOnClickListener { onClick() }
        into.addView(row)
    }

    private fun addDivider(into: LinearLayout) {
        val divider = View(requireContext())
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
        lp.marginStart = (68 * resources.displayMetrics.density).toInt()
        divider.layoutParams = lp
        divider.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.separator))
        into.addView(divider)
    }

    // --- Pré-escuta (ao volume de alarme, como na utilização real) ---

    private fun togglePreview(sound: SoundLibrary.Sound) {
        if (previewing == sound.key) {
            stopPreview()
            render()
            return
        }
        stopPreview()
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(requireContext(), SoundLibrary.uriFor(requireContext(), sound))
            mp.prepare()
            mp.setOnCompletionListener {
                stopPreview()
                if (isAdded && view != null) render()
            }
            mp.start()
            player = mp
            previewing = sound.key
        } catch (e: Exception) {
            try {
                mp.release()
            } catch (ignored: Exception) {
            }
        }
        render()
    }

    private fun stopPreview() {
        player?.let {
            try {
                if (it.isPlaying) it.stop()
            } catch (e: Exception) {
                // ignorar
            }
            try {
                it.release()
            } catch (e: Exception) {
                // ignorar
            }
        }
        player = null
        previewing = null
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(STATE_SELECTED, selected)
        outState.putInt(STATE_CATEGORY, category.ordinal)
    }

    override fun onDestroyView() {
        stopPreview()
        super.onDestroyView()
    }

    companion object {
        const val REQUEST_KEY = "sound_picker_result"
        const val RESULT_VALUE = "value"
        const val RESULT_TITLE = "title"

        const val CONTEXT_ALARM = 0
        const val CONTEXT_TIMER = 1
        const val CONTEXT_STEP = 2

        private const val ARG_CURRENT = "current"
        private const val ARG_CONTEXT = "context"
        private const val STATE_SELECTED = "state_selected"
        private const val STATE_CATEGORY = "state_category"

        fun newInstance(current: String?, context: Int): SoundPickerSheet {
            val sheet = SoundPickerSheet()
            sheet.arguments = bundleOf(ARG_CURRENT to current, ARG_CONTEXT to context)
            return sheet
        }
    }
}
