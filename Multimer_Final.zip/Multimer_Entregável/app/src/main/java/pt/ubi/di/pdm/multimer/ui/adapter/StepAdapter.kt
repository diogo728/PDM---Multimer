package pt.ubi.di.pdm.multimer.ui.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.data.model.CascadeStepEntity
import pt.ubi.di.pdm.multimer.util.TimeFmt

/** Lista editável de passos de uma cascata personalizada. */
class StepAdapter(
    private val steps: MutableList<CascadeStepEntity>,
    private val onClick: (Int) -> Unit,
    private val onStartDrag: (RecyclerView.ViewHolder) -> Unit
) : RecyclerView.Adapter<StepAdapter.StepViewHolder>() {

    fun move(from: Int, to: Int) {
        val item = steps.removeAt(from)
        steps.add(to, item)
        notifyItemMoved(from, to)
    }

    fun removeAt(position: Int): CascadeStepEntity {
        val removed = steps.removeAt(position)
        notifyItemRemoved(position)
        notifyItemRangeChanged(position, steps.size - position)
        return removed
    }

    fun refreshAll() = notifyItemRangeChanged(0, steps.size)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StepViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_step, parent, false)
        return StepViewHolder(v)
    }

    override fun getItemCount(): Int = steps.size

    override fun onBindViewHolder(holder: StepViewHolder, position: Int) = holder.bind(position)

    inner class StepViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvNumber: TextView = itemView.findViewById(R.id.tvStepNumber)
        private val tvTitle: TextView = itemView.findViewById(R.id.tvStepTitle)
        private val tvDetails: TextView = itemView.findViewById(R.id.tvStepDetails)
        private val drag: ImageView = itemView.findViewById(R.id.ivStepDrag)

        @SuppressLint("ClickableViewAccessibility")
        fun bind(position: Int) {
            val step = steps[position]
            val cumulative = steps.take(position + 1).sumOf { it.durationInMillis }
            tvNumber.text = (position + 1).toString()
            tvTitle.text = step.title
            var details = "Depois de ${TimeFmt.human(step.durationInMillis)}, aos ${TimeFmt.human(cumulative)}"
            if (!step.autoDismiss) details += ", manual"
            tvDetails.text = details

            itemView.setOnClickListener {
                val pos = bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) onClick(pos)
            }
            drag.setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_DOWN) onStartDrag(this)
                false
            }
        }
    }
}
