package pt.ubi.di.pdm.multimer.share

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import pt.ubi.di.pdm.multimer.data.model.AlarmEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeStepEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeWithSteps
import pt.ubi.di.pdm.multimer.util.RepeatDays
import pt.ubi.di.pdm.multimer.util.SoundLibrary
import pt.ubi.di.pdm.multimer.util.SoundUtils
import java.io.ByteArrayOutputStream
import java.util.zip.Deflater
import java.util.zip.Inflater

/**
 * Formato de partilha de alarmes, cascatas e sequenciais: uma COPIA independente, sem ligação ao original.
 *
 * Um alarme viaja como texto: JSON compacto, comprimido e em base64, dentro de uma ligação
 * `multimer://share?d=...`. Tudo o que chega é tratado como não fiável: é validado, limitado e limpo
 * antes de tocar na base de dados, e os alarmes importados chegam sempre DESLIGADOS.
 * Só viajam definições; os sons são sempre os da biblioteca da app, nunca ficheiros.
 */
object ShareCodec {

    const val LINK_PREFIX = "multimer://share?d="
    private const val VERSION = 1

    /** Acima deste tamanho o QR fica denso demais para ler; usa-se o texto ou a partilha do sistema. */
    private const val MAX_QR_LINK = 1700
    private const val MAX_JSON_BYTES = 16 * 1024
    private const val MAX_STEPS = 60
    private const val MAX_TEXT = 60
    private const val MIN_WAIT_MS = 1_000L
    private const val MAX_WAIT_MS = 7L * 24 * 3_600 * 1_000
    private const val MAX_REPEAT = 999
    private val SNOOZE_OPTIONS = listOf(5, 10, 15, 30)

    sealed class Item {
        class AlarmItem(val alarm: AlarmEntity) : Item()
        class SequentialItem(val cascade: CascadeEntity) : Item()
        class CascadeItem(val cascade: CascadeEntity, val steps: List<CascadeStepEntity>) : Item()
    }

    sealed class Result {
        class Ok(val item: Item) : Result()
        class Error(val message: String) : Result()
    }

    fun fitsInQr(link: String): Boolean = link.length <= MAX_QR_LINK

    // ------------------------------------------------------------------ Codificação

    fun encodeAlarm(a: AlarmEntity): String {
        val o = JSONObject()
        o.put("v", VERSION)
        o.put("k", "a")
        o.put("h", a.hour)
        o.put("m", a.minute)
        o.put("l", a.label)
        o.put("d", a.repeatDays)
        o.put("vb", if (a.isVibrationEnabled) 1 else 0)
        o.put("s", a.soundUri ?: SoundLibrary.DEFAULT_ALARM)
        o.put("sn", if (a.isSnoozeEnabled) 1 else 0)
        o.put("sm", a.snoozeMinutes)
        o.put("g", if (a.isGradualVolume) 1 else 0)
        return toLink(o.toString())
    }

    fun encodeCascade(item: CascadeWithSteps): String {
        val c = item.cascade
        val o = JSONObject()
        o.put("v", VERSION)
        o.put("n", c.title)
        if (c.type == CascadeEntity.TYPE_SEQUENTIAL) {
            o.put("k", "s")
            o.put("i", c.intervalMillis)
            o.put("c", c.repeatCount)
            o.put("ad", if (c.autoDismiss) 1 else 0)
            o.put("vb", if (c.isVibrationEnabled) 1 else 0)
            o.put("s", c.soundUri ?: SoundLibrary.DEFAULT_STEP)
        } else {
            o.put("k", "c")
            val steps = JSONArray()
            for (s in item.steps.sortedBy { it.stepOrder }) {
                val row = JSONArray()
                row.put(s.title)
                row.put(s.durationInMillis)
                row.put(if (s.autoDismiss) 0 else 1) // 1 = desligar manualmente
                row.put(if (s.isVibrationEnabled) 1 else 0)
                row.put(s.soundUri ?: SoundLibrary.DEFAULT_STEP)
                steps.put(row)
            }
            o.put("p", steps)
        }
        return toLink(o.toString())
    }

    private fun toLink(json: String): String {
        val input = json.toByteArray(Charsets.UTF_8)
        val deflater = Deflater(Deflater.BEST_COMPRESSION)
        deflater.setInput(input)
        deflater.finish()
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(1024)
        while (!deflater.finished()) {
            val n = deflater.deflate(buffer)
            out.write(buffer, 0, n)
        }
        deflater.end()
        val encoded = Base64.encodeToString(out.toByteArray(), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        return LINK_PREFIX + encoded
    }

    // ------------------------------------------------------------------ Descodificação

    /** Aceita a ligação completa, texto que a contenha (uma mensagem) ou só o código. */
    fun decode(text: String?): Result {
        if (text.isNullOrBlank()) return Result.Error("Não há nada para importar.")
        val code = extractCode(text) ?: return Result.Error("Isto não parece um código do Multimer.")
        val json = try {
            inflate(Base64.decode(code, Base64.URL_SAFE))
        } catch (e: Exception) {
            return Result.Error("O código está incompleto ou danificado.")
        } ?: return Result.Error("O código é demasiado grande para ser válido.")

        return try {
            parse(JSONObject(json))
        } catch (e: Exception) {
            Result.Error("O código não pôde ser lido.")
        }
    }

    private fun extractCode(text: String): String? {
        val match = Regex("multimer://share\\?d=([A-Za-z0-9_-]+)").find(text)
        if (match != null) return match.groupValues[1]
        val trimmed = text.trim()
        return if (trimmed.length >= 20 && Regex("[A-Za-z0-9_-]+").matches(trimmed)) trimmed else null
    }

    /** Descomprime com um limite de tamanho, para um código malicioso não encher a memória. */
    private fun inflate(data: ByteArray): String? {
        val inflater = Inflater()
        inflater.setInput(data)
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(1024)
        try {
            while (!inflater.finished()) {
                val n = inflater.inflate(buffer)
                if (n == 0 && (inflater.needsInput() || inflater.needsDictionary())) break
                out.write(buffer, 0, n)
                if (out.size() > MAX_JSON_BYTES) return null
            }
        } finally {
            inflater.end()
        }
        return String(out.toByteArray(), Charsets.UTF_8)
    }

    private fun parse(o: JSONObject): Result {
        if (o.optInt("v", 0) != VERSION) {
            return Result.Error("Este código vem de outra versão do Multimer. Atualiza a app e tenta de novo.")
        }
        return when (o.optString("k")) {
            "a" -> parseAlarm(o)
            "s" -> parseSequential(o)
            "c" -> parseCascade(o)
            else -> Result.Error("Tipo de conteúdo desconhecido.")
        }
    }

    private fun parseAlarm(o: JSONObject): Result {
        val hour = o.optInt("h", -1)
        val minute = o.optInt("m", -1)
        if (hour !in 0..23 || minute !in 0..59) return Result.Error("A hora do alarme é inválida.")
        val sound = cleanSound(o.optString("s", ""), SoundLibrary.DEFAULT_ALARM)
        val snooze = o.optInt("sm", 10).let { if (it in SNOOZE_OPTIONS) it else 10 }
        val alarm = AlarmEntity(
            hour = hour,
            minute = minute,
            isEnabled = false, // chega sempre desligado
            label = clean(o.optString("l", "")),
            repeatDays = RepeatDays.toStorage(RepeatDays.parse(o.optString("d", ""))),
            isVibrationEnabled = o.optInt("vb", 1) == 1,
            soundUri = sound,
            soundTitle = titleOf(sound),
            isSnoozeEnabled = o.optInt("sn", 1) == 1,
            snoozeMinutes = snooze,
            isGradualVolume = o.optInt("g", 1) == 1
        )
        return Result.Ok(Item.AlarmItem(alarm))
    }

    private fun parseSequential(o: JSONObject): Result {
        val interval = o.optLong("i", 0L)
        if (interval < MIN_WAIT_MS || interval > 24L * 3_600 * 1_000) return Result.Error("O intervalo é inválido.")
        val count = o.optInt("c", 0)
        if (count < 0 || count > MAX_REPEAT) return Result.Error("O número de toques é inválido.")
        val sound = cleanSound(o.optString("s", ""), SoundLibrary.DEFAULT_STEP)
        val cascade = CascadeEntity(
            title = clean(o.optString("n", "")).ifEmpty { "Sequência partilhada" },
            type = CascadeEntity.TYPE_SEQUENTIAL,
            intervalMillis = interval,
            repeatCount = count,
            autoDismiss = o.optInt("ad", 1) == 1,
            isVibrationEnabled = o.optInt("vb", 1) == 1,
            soundUri = sound,
            soundTitle = titleOf(sound)
        )
        return Result.Ok(Item.SequentialItem(cascade))
    }

    private fun parseCascade(o: JSONObject): Result {
        val rows = o.optJSONArray("p") ?: return Result.Error("A cascata não tem passos.")
        if (rows.length() < 1 || rows.length() > MAX_STEPS) return Result.Error("O número de passos é inválido.")
        val steps = ArrayList<CascadeStepEntity>()
        for (i in 0 until rows.length()) {
            val row = rows.optJSONArray(i) ?: return Result.Error("Um dos passos está danificado.")
            val wait = row.optLong(1, 0L)
            if (wait < MIN_WAIT_MS || wait > MAX_WAIT_MS) return Result.Error("O tempo de um dos passos é inválido.")
            val sound = cleanSound(row.optString(4, ""), SoundLibrary.DEFAULT_STEP)
            steps.add(
                CascadeStepEntity(
                    stepOrder = i,
                    title = clean(row.optString(0, "")).ifEmpty { "Passo ${i + 1}" },
                    durationInMillis = wait,
                    autoDismiss = row.optInt(2, 0) != 1,
                    isVibrationEnabled = row.optInt(3, 1) == 1,
                    soundUri = sound,
                    soundTitle = titleOf(sound)
                )
            )
        }
        val cascade = CascadeEntity(
            title = clean(o.optString("n", "")).ifEmpty { "Cascata partilhada" },
            type = CascadeEntity.TYPE_CUSTOM
        )
        return Result.Ok(Item.CascadeItem(cascade, steps))
    }

    // ------------------------------------------------------------------ Limpeza

    private fun clean(text: String): String = text.filter { !it.isISOControl() }.trim().take(MAX_TEXT)

    /** Só se aceitam sons da biblioteca (ou silêncio); qualquer outra coisa vira o som por omissão. */
    private fun cleanSound(value: String, fallback: String): String = when {
        value == SoundUtils.SILENT -> SoundUtils.SILENT
        SoundLibrary.find(value) != null -> value
        else -> fallback
    }

    private fun titleOf(sound: String): String =
        if (sound == SoundUtils.SILENT) "Sem som" else SoundLibrary.find(sound)?.title ?: "Carrilhão"
}
