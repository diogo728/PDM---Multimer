package pt.ubi.di.pdm.multimer.service

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import pt.ubi.di.pdm.multimer.MainActivity
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.data.local.AppDatabase
import pt.ubi.di.pdm.multimer.data.model.CascadeEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeWithSteps
import pt.ubi.di.pdm.multimer.ui.activity.AlarmRingingActivity
import pt.ubi.di.pdm.multimer.util.ExactAlarms
import pt.ubi.di.pdm.multimer.util.NotificationStyle
import pt.ubi.di.pdm.multimer.util.Notifications
import pt.ubi.di.pdm.multimer.util.RingPlayer
import pt.ubi.di.pdm.multimer.util.TimeFmt
import org.json.JSONArray
import org.json.JSONObject
import pt.ubi.di.pdm.multimer.sync.SyncMapper
import java.util.concurrent.ConcurrentHashMap

/**
 * Executa cascatas. Podem correr vários alarmes sequenciais ao mesmo tempo, mas só uma
 * cascata personalizada de cada vez (iniciar outra substitui a anterior).
 * O fim de cada passo é garantido pelo AlarmManager, por isso funciona com o ecrã desligado.
 * O ritmo é fixo: o passo seguinte começa assim que o anterior toca, mesmo que esse toque
 * ainda esteja a soar à espera de ser desligado.
 */
class CascadeService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private val handler = Handler(Looper.getMainLooper())
    private val players = ConcurrentHashMap<Long, RingPlayer>()

    companion object {
        const val ROOM_RUN_ID = -999L

        const val EXTRA_CASCADE_ID = "extra_cascade_id"
        const val EXTRA_DEFINITION_JSON = "extra_definition_json"
        const val EXTRA_RUN_TITLE = "extra_run_title"
        const val EXTRA_START_AT_ELAPSED = "extra_start_at_elapsed"
        const val EXTRA_MUTED = "extra_muted"
        const val EXTRA_SILENT = "extra_silent"
        private const val EXTRA_GENERATION = "extra_generation"

        const val ACTION_START_CASCADE = "pt.ubi.di.pdm.multimer.ACTION_START_CASCADE"
        const val ACTION_START_ROOM_RUN = "pt.ubi.di.pdm.multimer.ACTION_START_ROOM_RUN"
        const val ACTION_PAUSE_CASCADE = "pt.ubi.di.pdm.multimer.ACTION_PAUSE_CASCADE"
        const val ACTION_RESUME_CASCADE = "pt.ubi.di.pdm.multimer.ACTION_RESUME_CASCADE"
        const val ACTION_NEXT_STEP = "pt.ubi.di.pdm.multimer.ACTION_NEXT_STEP"
        const val ACTION_STOP_CASCADE = "pt.ubi.di.pdm.multimer.ACTION_STOP_CASCADE"
        const val ACTION_STOP_ALL = "pt.ubi.di.pdm.multimer.ACTION_STOP_ALL_CASCADES"
        const val ACTION_STOP_RING = "pt.ubi.di.pdm.multimer.ACTION_STOP_RING_CASCADE"
        private const val ACTION_DUE = "pt.ubi.di.pdm.multimer.ACTION_CASCADE_DUE"

        private const val NOTIFICATION_ID = 2002
        private const val ALERT_NOTIFICATION_BASE = 2_100_000
        private const val DUE_REQUEST_BASE = 100_000
        private const val PROGRESS_REFRESH_MS = 5_000L
        private const val RING_MAX_MS = 5 * 60 * 1000L
        private const val AUTO_RING_MS = 12_000L

        /** Execuções em curso, por id da cascata. A interface só lê. */
        val runs = ConcurrentHashMap<Long, CascadeRun>()

        fun isRunning(cascadeId: Long): Boolean = runs.containsKey(cascadeId)
    }

    override fun onCreate() {
        super.onCreate()
        Notifications.ensureChannels(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Quem chama startForegroundService() exige startForeground() em poucos segundos
        startForeground(NOTIFICATION_ID, buildNotification())

        if (intent != null) {
            val id = intent.getLongExtra(EXTRA_CASCADE_ID, -1L)
            when (intent.action) {
                ACTION_START_CASCADE -> if (id != -1L) loadAndStart(id)
                ACTION_START_ROOM_RUN -> startRoomRun(intent)
                ACTION_PAUSE_CASCADE -> runs[id]?.let { pause(it) }
                ACTION_RESUME_CASCADE -> runs[id]?.let { resume(it) }
                ACTION_NEXT_STEP -> runs[id]?.let { skip(it) }
                ACTION_STOP_CASCADE -> runs[id]?.let { stopRun(it) }
                ACTION_STOP_ALL -> ArrayList(runs.values).forEach { stopRun(it) }
                ACTION_STOP_RING -> runs[id]?.let { stopRing(it) }
                ACTION_DUE -> runs[id]?.let { onDue(it, intent.getIntExtra(EXTRA_GENERATION, -1)) }
            }
        }

        finishIfIdle()
        return START_NOT_STICKY
    }

    private fun finishIfIdle() {
        if (runs.isEmpty() && !loading) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        } else {
            refreshNotification()
        }
    }

    // --- Arranque ---

    private var loading = false

    private val progressTick = object : Runnable {
        override fun run() {
            if (runs.isNotEmpty()) {
                refreshNotification()
                handler.postDelayed(this, PROGRESS_REFRESH_MS)
            }
        }
    }

    private fun loadAndStart(cascadeId: Long) {
        loading = true
        serviceScope.launch {
            val data: CascadeWithSteps? = withContext(Dispatchers.IO) {
                AppDatabase.getDatabase(applicationContext).cascadeDao().getCascadeWithStepsById(cascadeId)
            }
            loading = false
            val run = data?.let { buildRun(it) }
            if (run == null) {
                finishIfIdle()
                return@launch
            }
            // A mesma cascata reinicia; só uma personalizada de cada vez
            runs[cascadeId]?.let { stopRun(it, quiet = true) }
            if (!run.isSequential) {
                ArrayList(runs.values).filter { !it.isSequential }.forEach { stopRun(it, quiet = true) }
            }
            runs[cascadeId] = run
            players[cascadeId] = RingPlayer(this@CascadeService)
            handler.removeCallbacks(progressTick)
            handler.postDelayed(progressTick, PROGRESS_REFRESH_MS)
            beginStep(run, 0)
            refreshNotification()
        }
    }

    private fun startRoomRun(intent: Intent) {
        val jsonStr = intent.getStringExtra(EXTRA_DEFINITION_JSON) ?: return
        val title = intent.getStringExtra(EXTRA_RUN_TITLE) ?: "Sala ao vivo"
        val targetElapsed = intent.getLongExtra(EXTRA_START_AT_ELAPSED, SystemClock.elapsedRealtime())
        val muted = intent.getBooleanExtra(EXTRA_MUTED, false)
        val silent = intent.getBooleanExtra(EXTRA_SILENT, false)

        try {
            val json = JSONObject(jsonStr)
            val map = jsonToMap(json)
            val parsed = SyncMapper.cascadeFromMap(map) ?: return
            val (cascade, steps) = parsed
            val data = CascadeWithSteps(
                cascade = cascade.copy(id = ROOM_RUN_ID, title = title),
                steps = steps
            )
            val run = buildRun(data) ?: return
            run.muted = muted
            run.silent = silent

            runs[ROOM_RUN_ID]?.let { stopRun(it, quiet = true) }
            runs[ROOM_RUN_ID] = run
            players[ROOM_RUN_ID] = RingPlayer(this)
            handler.removeCallbacks(progressTick)
            handler.postDelayed(progressTick, PROGRESS_REFRESH_MS)

            val delay = (targetElapsed - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
            handler.postDelayed({
                if (runs[ROOM_RUN_ID] === run) beginStep(run, 0)
            }, delay)
            refreshNotification()
        } catch (e: Exception) {
            // json invalido
        }
    }

    private fun jsonToMap(json: JSONObject): Map<String, Any?> {
        val map = HashMap<String, Any?>()
        val keys = json.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            var value = json.get(key)
            if (value is JSONArray) {
                val list = ArrayList<Map<String, Any?>>()
                for (i in 0 until value.length()) {
                    val obj = value.getJSONObject(i)
                    list.add(jsonToMap(obj))
                }
                value = list
            } else if (value is JSONObject) {
                value = jsonToMap(value)
            } else if (value == JSONObject.NULL) {
                value = null
            }
            map[key] = value
        }
        return map
    }

    private fun buildRun(data: CascadeWithSteps): CascadeRun? {
        val c = data.cascade
        if (c.type == CascadeEntity.TYPE_SEQUENTIAL) {
            if (c.intervalMillis <= 0L) return null
            val step = CascadeRun.Step("", c.intervalMillis, c.autoDismiss, c.isVibrationEnabled, c.soundUri)
            return CascadeRun(c.id, c.title, true, null, step, c.repeatCount)
        }
        val steps = data.steps.sortedBy { it.stepOrder }.map {
            CascadeRun.Step(it.title, it.durationInMillis, it.autoDismiss, it.isVibrationEnabled, it.soundUri)
        }
        if (steps.isEmpty()) return null
        return CascadeRun(c.id, c.title, false, steps, null, 0)
    }

    // --- Execução ---

    private fun beginStep(run: CascadeRun, index: Int) {
        val step = run.stepAt(index)
        if (step == null) {
            stopRun(run)
            return
        }
        run.index = index
        run.stepTitle = step.title
        run.stepDurationMs = step.waitMs
        run.paused = false
        run.stepEndAtElapsed = SystemClock.elapsedRealtime() + step.waitMs
        scheduleDue(run, step.waitMs)
    }

    private fun onDue(run: CascadeRun, gen: Int) {
        if (gen != run.generation || run.paused || run.finishing) return
        if (run.remainingMs() > 800L) {
            scheduleDue(run, run.remainingMs())
            return
        }
        val index = run.index
        val step = run.stepAt(index) ?: return
        cancelDue(run)
        fire(run, step, index)

        if (run.stepAt(index + 1) != null) {
            beginStep(run, index + 1)
        } else {
            // Era o último toque
            run.finishing = true
            run.finished = true
            players[run.cascadeId]?.onFinished = { stopRun(run) }
            if (step.autoDismiss) handler.postDelayed({ stopRun(run) }, AUTO_RING_MS + 1000L)
        }
        refreshNotification()
    }

    private fun fire(run: CascadeRun, step: CascadeRun.Step, index: Int) {
        if (run.muted || run.silent) {
            run.ringing = false
            return
        }
        val player = players[run.cascadeId] ?: return
        player.onFinished = {
            run.ringing = false
            if (run.finishing) stopRun(run)
        }
        player.start(
            step.soundUri, step.vibrate,
            loop = !step.autoDismiss,
            gradualVolume = false,
            maxDurationMs = if (step.autoDismiss) AUTO_RING_MS else RING_MAX_MS
        )
        run.ringing = !step.autoDismiss

        if (!step.autoDismiss) {
            try {
                startActivity(ringingIntent(run, step, index))
            } catch (e: Exception) {
                // a notificação em ecrã inteiro trata disso
            }
        }
        postAlertNotification(run, step, index)
    }

    private fun pause(run: CascadeRun) {
        if (run.paused || run.finishing) return
        run.pausedRemainingMs = run.remainingMs()
        run.paused = true
        cancelDue(run)
    }

    private fun resume(run: CascadeRun) {
        if (!run.paused) return
        run.paused = false
        run.stepEndAtElapsed = SystemClock.elapsedRealtime() + run.pausedRemainingMs
        scheduleDue(run, run.pausedRemainingMs)
    }

    /** Salta a espera atual sem tocar e passa ao passo seguinte. */
    private fun skip(run: CascadeRun) {
        if (run.finishing) return
        cancelDue(run)
        if (run.stepAt(run.index + 1) != null) beginStep(run, run.index + 1) else stopRun(run)
    }

    private fun stopRing(run: CascadeRun) {
        players[run.cascadeId]?.stop()
        run.ringing = false
        sendBroadcast(AlarmRingingActivity.dismissBroadcast(this, AlarmRingingActivity.KIND_CASCADE, run.cascadeId))
        alertManager()?.cancel(alertId(run))
        if (run.finishing) stopRun(run)
    }

    private fun stopRun(run: CascadeRun, quiet: Boolean = false) {
        // Ignora paragens atrasadas de uma execução que já foi substituída
        val current = runs[run.cascadeId]
        if (current != null && current !== run) return
        cancelDue(run)
        players.remove(run.cascadeId)?.stop()
        runs.remove(run.cascadeId)
        sendBroadcast(AlarmRingingActivity.dismissBroadcast(this, AlarmRingingActivity.KIND_CASCADE, run.cascadeId))
        alertManager()?.cancel(alertId(run))
        if (!quiet) finishIfIdle()
    }

    // --- Agendamento ---

    private fun scheduleDue(run: CascadeRun, remaining: Long) {
        cancelDue(run)
        val gen = ++run.generation
        val runnable = Runnable { onDue(run, gen) }
        run.dueRunnable = runnable
        handler.postDelayed(runnable, remaining)
        ExactAlarms.setElapsed(this, SystemClock.elapsedRealtime() + remaining, duePendingIntent(run.cascadeId, gen))
    }

    private fun cancelDue(run: CascadeRun) {
        run.dueRunnable?.let { handler.removeCallbacks(it) }
        run.dueRunnable = null
        ExactAlarms.cancel(this, duePendingIntent(run.cascadeId, 0))
    }

    private fun duePendingIntent(cascadeId: Long, gen: Int): PendingIntent {
        val intent = Intent(this, CascadeService::class.java)
            .setAction(ACTION_DUE)
            .putExtra(EXTRA_CASCADE_ID, cascadeId)
            .putExtra(EXTRA_GENERATION, gen)
        val code = DUE_REQUEST_BASE + (cascadeId % 50_000L).toInt()
        return PendingIntent.getForegroundService(this, code, intent, Notifications.IMMUTABLE_UPDATE)
    }

    // --- Notificações ---

    private fun alertManager() = getSystemService(NotificationManager::class.java)

    private fun alertId(run: CascadeRun): Int = ALERT_NOTIFICATION_BASE + (run.cascadeId % 100_000L).toInt()

    private fun actionIntent(action: String, cascadeId: Long, code: Int): PendingIntent {
        val intent = Intent(this, CascadeService::class.java).setAction(action).putExtra(EXTRA_CASCADE_ID, cascadeId)
        return PendingIntent.getService(this, code + (cascadeId % 50_000L).toInt(), intent, Notifications.IMMUTABLE_UPDATE)
    }

    private fun ringingIntent(run: CascadeRun, step: CascadeRun.Step, index: Int): Intent {
        val sub = if (!run.isSequential && run.stepCount > 0) "Passo ${index + 1} de ${run.stepCount}" else ""
        return AlarmRingingActivity.newIntent(
            this, AlarmRingingActivity.KIND_CASCADE, run.title, step.title, sub, null, run.cascadeId
        )
    }

    private fun postAlertNotification(run: CascadeRun, step: CascadeRun.Step, index: Int) {
        val builder = NotificationCompat.Builder(this, Notifications.CHANNEL_ALERT)
            .setSmallIcon(R.drawable.ic_nav_cascade)
            .setContentTitle(run.title)
            .setContentText(step.title)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        NotificationStyle.alert(this, builder, if (run.isSequential) "Alarme sequencial" else "Cascata")

        if (step.autoDismiss) {
            builder.setTimeoutAfter(AUTO_RING_MS).setAutoCancel(true)
        } else {
            val fullScreen = PendingIntent.getActivity(
                this, 21 + (run.cascadeId % 50_000L).toInt(), ringingIntent(run, step, index), Notifications.IMMUTABLE_UPDATE
            )
            builder.setContentIntent(fullScreen)
                .setFullScreenIntent(fullScreen, true)
                .setOngoing(true)
                .addAction(0, getString(R.string.t_parar), actionIntent(ACTION_STOP_RING, run.cascadeId, 300_000))
        }
        alertManager()?.notify(alertId(run), builder.build())
    }

    private fun refreshNotification() {
        alertManager()?.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val openPi = PendingIntent.getActivity(this, 23, Intent(this, MainActivity::class.java), Notifications.IMMUTABLE_UPDATE)
        val builder = NotificationCompat.Builder(this, Notifications.CHANNEL_RUNNING)
            .setSmallIcon(R.drawable.ic_nav_cascade)
            .setContentIntent(openPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)

        val active = ArrayList(runs.values)
        NotificationStyle.running(this, builder, if (active.size == 1 && active[0].isSequential) "Alarme sequencial" else "Cascata")
        if (active.isEmpty()) {
            return builder.setContentTitle(getString(R.string.t_cascata)).setContentText(getString(R.string.t_a_iniciar)).build()
        }

        if (active.size > 1) {
            builder.setContentTitle("${active.size} alarmes em execução")
                .setContentText(active.joinToString(", ") { it.title })
                .addAction(0, getString(R.string.t_parar_todos), actionIntent(ACTION_STOP_ALL, -1L, 310_000))
            return builder.build()
        }

        val run = active[0]
        builder.setContentTitle(run.title)
        NotificationStyle.progress(builder, run.overallFraction())
        if (run.finished) {
            builder.setContentText(getString(R.string.t_concluida))
        } else {
            val position = if (run.stepCount > 0) "${run.index + 1}/${run.stepCount}" else "${run.index + 1}"
            val what = if (run.isSequential) "Toque $position" else "Passo $position, ${run.stepTitle}"
            if (run.paused) {
                builder.setContentText("Em pausa, $what, faltam " + TimeFmt.countdown(run.pausedRemainingMs))
                builder.addAction(0, getString(R.string.t_retomar), actionIntent(ACTION_RESUME_CASCADE, run.cascadeId, 320_000))
            } else {
                builder.setUsesChronometer(true)
                    .setChronometerCountDown(true)
                    .setShowWhen(true)
                    .setWhen(System.currentTimeMillis() + run.remainingMs())
                    .setContentText(what)
                builder.addAction(0, getString(R.string.t_pausar), actionIntent(ACTION_PAUSE_CASCADE, run.cascadeId, 330_000))
            }
            builder.addAction(0, getString(R.string.t_saltar), actionIntent(ACTION_NEXT_STEP, run.cascadeId, 340_000))
        }
        builder.addAction(0, getString(R.string.t_parar), actionIntent(ACTION_STOP_CASCADE, run.cascadeId, 350_000))
        return builder.build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacks(progressTick)
        serviceScope.cancel()
        ArrayList(runs.values).forEach { run ->
            cancelDue(run)
            players.remove(run.cascadeId)?.stop()
        }
        runs.clear()
        super.onDestroy()
    }
}
