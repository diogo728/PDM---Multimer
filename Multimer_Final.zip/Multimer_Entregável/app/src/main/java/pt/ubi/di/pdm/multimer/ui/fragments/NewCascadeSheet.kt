package pt.ubi.di.pdm.multimer.ui.fragments

import android.content.res.ColorStateList
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.os.bundleOf
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.data.model.CascadeEntity
import pt.ubi.di.pdm.multimer.util.CascadeTemplates

/** Em vez de começar sempre do zero: em branco, a partir de um modelo ou de uma das tuas. */
class NewCascadeSheet : BottomSheetDialogFragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.sheet_new_cascade, container, false)
    }

    override fun onStart() {
        super.onStart()
        val dlg = dialog as? BottomSheetDialog ?: return
        dlg.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dlg.behavior.skipCollapsed = true
        dlg.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.backgroundTintList =
            ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.bg_grouped))
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val args = requireArguments()
        val type = args.getInt(ARG_TYPE, CascadeEntity.TYPE_SEQUENTIAL)
        val ids = args.getLongArray(ARG_EXISTING_IDS) ?: LongArray(0)
        val titles = args.getStringArray(ARG_EXISTING_TITLES) ?: emptyArray()

        view.findViewById<TextView>(R.id.tvNewTitle).text = "Nova cascata"
        view.findViewById<MaterialButton>(R.id.btnNewCancel).setOnClickListener { dismiss() }

        val container = view.findViewById<LinearLayout>(R.id.containerNew)
        val inflater = LayoutInflater.from(requireContext())

        addGroup(container, inflater, null, listOf(
            Row("Em branco", "Começar do zero") { deliver(MODE_BLANK, null, -1L) }
        ), first = true)

        addGroup(container, inflater, "Modelos", CascadeTemplates.forType(type).map { t ->
            Row(t.name, t.description) { deliver(MODE_TEMPLATE, t.key, -1L) }
        })

        if (ids.isNotEmpty()) {
            addGroup(container, inflater, "Usar uma das tuas como base", ids.indices.map { i ->
                Row(titles.getOrNull(i) ?: "Sem nome", "Cria uma cópia para ajustares") { deliver(MODE_BASE, null, ids[i]) }
            })
        }
    }

    private class Row(val name: String, val description: String, val onClick: () -> Unit)

    private fun addGroup(container: LinearLayout, inflater: LayoutInflater, header: String?, rows: List<Row>, first: Boolean = false) {
        if (header != null) {
            val tv = TextView(requireContext())
            tv.setTextAppearance(R.style.Multimer_SectionHeader)
            tv.text = header
            val pad = (16 * resources.displayMetrics.density).toInt()
            tv.setPadding(pad, 0, pad, (6 * resources.displayMetrics.density).toInt())
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = (20 * resources.displayMetrics.density).toInt()
            tv.layoutParams = lp
            container.addView(tv)
        }
        val group = LinearLayout(requireContext())
        group.orientation = LinearLayout.VERTICAL
        group.setBackgroundResource(R.drawable.bg_group)
        group.clipToOutline = true
        val glp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        if (first) glp.topMargin = (8 * resources.displayMetrics.density).toInt()
        group.layoutParams = glp

        rows.forEachIndexed { index, r ->
            val row = inflater.inflate(R.layout.item_template_row, group, false)
            row.findViewById<TextView>(R.id.tvTemplateName).text = r.name
            row.findViewById<TextView>(R.id.tvTemplateDesc).text = r.description
            row.setOnClickListener { r.onClick() }
            group.addView(row)
            if (index < rows.size - 1) {
                val divider = View(requireContext())
                val dlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
                dlp.marginStart = (16 * resources.displayMetrics.density).toInt()
                divider.layoutParams = dlp
                divider.setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.separator))
                group.addView(divider)
            }
        }
        container.addView(group)
    }

    private fun deliver(mode: String, key: String?, id: Long) {
        parentFragmentManager.setFragmentResult(
            REQUEST_KEY,
            bundleOf(RESULT_MODE to mode, RESULT_KEY to key, RESULT_ID to id, ARG_TYPE to requireArguments().getInt(ARG_TYPE))
        )
        dismiss()
    }

    companion object {
        const val REQUEST_KEY = "new_cascade_result"
        const val ARG_TYPE = "type"
        const val ARG_EXISTING_IDS = "existing_ids"
        const val ARG_EXISTING_TITLES = "existing_titles"
        const val RESULT_MODE = "mode"
        const val RESULT_KEY = "key"
        const val RESULT_ID = "id"
        const val MODE_BLANK = "blank"
        const val MODE_TEMPLATE = "template"
        const val MODE_BASE = "base"

        fun newInstance(type: Int, ids: LongArray, titles: Array<String>): NewCascadeSheet {
            val sheet = NewCascadeSheet()
            val b = Bundle()
            b.putInt(ARG_TYPE, type)
            b.putLongArray(ARG_EXISTING_IDS, ids)
            b.putStringArray(ARG_EXISTING_TITLES, titles)
            sheet.arguments = b
            return sheet
        }
    }
}
