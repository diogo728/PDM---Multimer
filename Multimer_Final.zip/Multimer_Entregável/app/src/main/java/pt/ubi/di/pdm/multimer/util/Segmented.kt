package pt.ubi.di.pdm.multimer.util

import android.view.View

/** Controlo segmentado simples: um conjunto de vistas em que só uma fica selecionada. */
class Segmented(
    private val items: List<View>,
    private val onChanged: ((Int) -> Unit)? = null
) {
    var selectedIndex: Int = 0
        private set

    init {
        items.forEachIndexed { index, view ->
            view.setOnClickListener { select(index, true) }
        }
        select(0, false)
    }

    fun select(index: Int, notify: Boolean = false) {
        selectedIndex = index
        items.forEachIndexed { i, v -> v.isSelected = (i == index) }
        if (notify) onChanged?.invoke(index)
    }
}
