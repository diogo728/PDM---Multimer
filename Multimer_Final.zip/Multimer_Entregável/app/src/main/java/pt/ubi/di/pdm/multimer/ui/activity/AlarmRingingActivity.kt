package pt.ubi.di.pdm.multimer.ui.activity

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.google.android.material.button.MaterialButton
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.service.AlarmService
import pt.ubi.di.pdm.multimer.service.CascadeService
import pt.ubi.di.pdm.multimer.service.CountdownService
import pt.ubi.di.pdm.multimer.util.applySystemBarsPadding

/** Ecrã de toque, partilhado por alarmes, temporizador e passos de cascata. */
class AlarmRingingActivity : AppCompatActivity() {

    private var kind = KIND_ALARM
    private var refId = -1L
    private var pulse: ObjectAnimator? = null

    private val dismissReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.getIntExtra(EXTRA_KIND, -1) != kind) return
            val other = intent.getLongExtra(EXTRA_REF_ID, -1L)
            if (other == -1L || refId == -1L || other == refId) finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_alarm_ringing)
        findViewById<View>(R.id.rootRinging).applySystemBarsPadding()
        WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = false

        ContextCompat.registerReceiver(
            this, dismissReceiver, IntentFilter(ACTION_DISMISS), ContextCompat.RECEIVER_NOT_EXPORTED
        )

        bind(intent)

        val time = findViewById<TextView>(R.id.tvRingingTime)
        pulse = ObjectAnimator.ofFloat(time, View.ALPHA, 1f, 0.55f).apply {
            duration = 900
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        bind(intent)
    }

    private fun bind(source: Intent) {
        kind = source.getIntExtra(EXTRA_KIND, KIND_ALARM)
        refId = source.getLongExtra(EXTRA_REF_ID, -1L)

        findViewById<TextView>(R.id.tvRingingHeading).text = source.getStringExtra(EXTRA_HEADING) ?: "Alarme"
        val big = source.getStringExtra(EXTRA_BIG_TEXT) ?: ""
        val tvBig = findViewById<TextView>(R.id.tvRingingTime)
        // Textos curtos ("Toque 1 de 3", "07:30") ficam numa só linha, reduzindo o tamanho em vez de quebrar a meio
        tvBig.maxLines = if (big.length <= 18) 1 else 2
        tvBig.text = big
        val label = source.getStringExtra(EXTRA_LABEL) ?: ""
        val tvLabel = findViewById<TextView>(R.id.tvRingingLabel)
        tvLabel.text = label
        tvLabel.visibility = if (label.isEmpty()) View.GONE else View.VISIBLE

        val btnStop = findViewById<MaterialButton>(R.id.btnStopAlarm)
        val btnSecondary = findViewById<MaterialButton>(R.id.btnSnoozeAlarm)
        val secondary = source.getStringExtra(EXTRA_SECONDARY)

        btnStop.setOnClickListener {
            startService(serviceAction(CLASS_STOP))
            finish()
        }

        if (secondary == null) {
            btnSecondary.visibility = View.GONE
        } else {
            btnSecondary.visibility = View.VISIBLE
            btnSecondary.text = secondary
            btnSecondary.setOnClickListener {
                startService(serviceAction(CLASS_SECONDARY))
                if (kind == KIND_ALARM) finish()
            }
        }
    }

    private fun serviceAction(which: Int): Intent {
        return when (kind) {
            KIND_TIMER -> Intent(this, CountdownService::class.java).setAction(
                if (which == CLASS_STOP) CountdownService.ACTION_STOP_RING else CountdownService.ACTION_ADD_MINUTE
            )
            KIND_CASCADE -> Intent(this, CascadeService::class.java)
                .setAction(CascadeService.ACTION_STOP_RING)
                .putExtra(CascadeService.EXTRA_CASCADE_ID, refId)
            else -> Intent(this, AlarmService::class.java).setAction(
                if (which == CLASS_STOP) AlarmService.ACTION_STOP_ALARM else AlarmService.ACTION_SNOOZE_ALARM
            )
        }
    }

    override fun onDestroy() {
        pulse?.cancel()
        try {
            unregisterReceiver(dismissReceiver)
        } catch (e: IllegalArgumentException) {
            // já removido
        }
        super.onDestroy()
    }

    companion object {
        const val ACTION_DISMISS = "pt.ubi.di.pdm.multimer.ACTION_RINGING_DISMISSED"
        const val EXTRA_KIND = "extra_kind"
        const val EXTRA_HEADING = "extra_heading"
        const val EXTRA_BIG_TEXT = "extra_big_text"
        const val EXTRA_LABEL = "extra_label"
        const val EXTRA_SECONDARY = "extra_secondary"
        const val EXTRA_REF_ID = "extra_ref_id"

        const val KIND_ALARM = 0
        const val KIND_TIMER = 1
        const val KIND_CASCADE = 2

        private const val CLASS_STOP = 0
        private const val CLASS_SECONDARY = 1

        fun newIntent(
            ctx: Context,
            kind: Int,
            heading: String,
            bigText: String,
            label: String,
            secondary: String?,
            refId: Long = -1L
        ): Intent {
            return Intent(ctx, AlarmRingingActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra(EXTRA_KIND, kind)
                putExtra(EXTRA_HEADING, heading)
                putExtra(EXTRA_BIG_TEXT, bigText)
                putExtra(EXTRA_LABEL, label)
                putExtra(EXTRA_REF_ID, refId)
                if (secondary != null) putExtra(EXTRA_SECONDARY, secondary)
            }
        }

        fun dismissBroadcast(ctx: Context, kind: Int, refId: Long = -1L): Intent {
            return Intent(ACTION_DISMISS).setPackage(ctx.packageName)
                .putExtra(EXTRA_KIND, kind)
                .putExtra(EXTRA_REF_ID, refId)
        }
    }
}
