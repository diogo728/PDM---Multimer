package pt.ubi.di.pdm.multimer.util

import java.util.Calendar

/** Converte entre o texto guardado na base de dados ("Seg, Qua") e conjuntos de dias. */
object RepeatDays {
    /** Ordem de apresentação (a semana começa à segunda-feira). */
    val ORDER = listOf("Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom")

    private val CALENDAR_DAY = mapOf(
        "Seg" to Calendar.MONDAY, "Ter" to Calendar.TUESDAY, "Qua" to Calendar.WEDNESDAY,
        "Qui" to Calendar.THURSDAY, "Sex" to Calendar.FRIDAY, "Sáb" to Calendar.SATURDAY,
        "Dom" to Calendar.SUNDAY
    )

    fun parse(stored: String): Set<String> {
        if (stored.isBlank() || stored == "Uma vez") return emptySet()
        if (stored == "Todos os dias") return ORDER.toSet()
        return ORDER.filter { stored.contains(it) }.toSet()
    }

    fun toStorage(days: Collection<String>): String {
        val ordered = ORDER.filter { days.contains(it) }
        return when {
            ordered.size == 7 -> "Todos os dias"
            ordered.isEmpty() -> "Uma vez"
            else -> ordered.joinToString(", ")
        }
    }

    fun isRepeating(stored: String): Boolean = parse(stored).isNotEmpty()

    fun toCalendarDays(stored: String): Set<Int> = parse(stored).mapNotNull { CALENDAR_DAY[it] }.toSet()

    fun describe(stored: String): String = describeSet(parse(stored))

    fun describeSet(days: Set<String>): String {
        val weekdays = setOf("Seg", "Ter", "Qua", "Qui", "Sex")
        return when {
            days.isEmpty() -> "Uma vez"
            days.size == 7 -> "Todos os dias"
            days == weekdays -> "Dias úteis"
            days == setOf("Sáb", "Dom") -> "Fins de semana"
            else -> ORDER.filter { days.contains(it) }.joinToString(", ")
        }
    }
}
