package pt.ubi.di.pdm.multimer.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import pt.ubi.di.pdm.multimer.MainActivity
import pt.ubi.di.pdm.multimer.data.model.AlarmEntity
import pt.ubi.di.pdm.multimer.receiver.AlarmReceiver
import java.util.Calendar
import java.util.TimeZone

object AlarmScheduler {

    const val EXTRA_ALARM_ID = "extra_alarm_id"
    const val EXTRA_ALARM_LABEL = "extra_alarm_label"
    const val EXTRA_ALARM_HOUR = "extra_alarm_hour"
    const val EXTRA_ALARM_MINUTE = "extra_alarm_minute"
    const val EXTRA_ALARM_VIBRATE = "extra_alarm_vibrate"
    const val EXTRA_ALARM_SOUND_URI = "extra_alarm_sound_uri"
    const val EXTRA_ALARM_GRADUAL = "extra_alarm_gradual"
    const val EXTRA_ALARM_SNOOZE_ENABLED = "extra_alarm_snooze_enabled"
    const val EXTRA_ALARM_SNOOZE_MINUTES = "extra_alarm_snooze_minutes"
    const val EXTRA_IS_SNOOZE = "extra_is_snooze"

    private const val SNOOZE_REQUEST_BASE = 500_000_000

    fun scheduleAlarm(context: Context, alarm: AlarmEntity) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        if (!alarm.isEnabled) {
            cancelAlarm(context, alarm)
            return
        }

        val triggerTime = calculateNextTriggerMillis(alarm.hour, alarm.minute, alarm.repeatDays)
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra(EXTRA_ALARM_ID, alarm.id)
            // Tudo o que é preciso para tocar já vai aqui: o alarme não depende de abrir a base de dados
            putExtra(EXTRA_ALARM_LABEL, alarm.label)
            putExtra(EXTRA_ALARM_HOUR, alarm.hour)
            putExtra(EXTRA_ALARM_MINUTE, alarm.minute)
            putExtra(EXTRA_ALARM_VIBRATE, alarm.isVibrationEnabled)
            putExtra(EXTRA_ALARM_SOUND_URI, alarm.soundUri)
            putExtra(EXTRA_ALARM_GRADUAL, alarm.isGradualVolume)
            putExtra(EXTRA_ALARM_SNOOZE_ENABLED, alarm.isSnoozeEnabled)
            putExtra(EXTRA_ALARM_SNOOZE_MINUTES, alarm.snoozeMinutes)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, alarm.id.toInt(), intent, Notifications.IMMUTABLE_UPDATE
        )
        setClockAlarm(context, alarmManager, triggerTime, pendingIntent, alarm.id.toInt())
    }

    /** Volta a tocar daqui a [minutes] minutos (soneca). */
    fun scheduleSnooze(context: Context, alarmId: Long, minutes: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val triggerTime = System.currentTimeMillis() + minutes * 60_000L
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra(EXTRA_ALARM_ID, alarmId)
            putExtra(EXTRA_IS_SNOOZE, true)
        }
        val code = SNOOZE_REQUEST_BASE + alarmId.toInt()
        val pendingIntent = PendingIntent.getBroadcast(context, code, intent, Notifications.IMMUTABLE_UPDATE)
        setClockAlarm(context, alarmManager, triggerTime, pendingIntent, code)
    }

    private fun setClockAlarm(
        context: Context,
        alarmManager: AlarmManager,
        triggerTime: Long,
        pendingIntent: PendingIntent,
        showRequestCode: Int
    ) {
        val showIntent = Intent(context, MainActivity::class.java)
        val showPendingIntent = PendingIntent.getActivity(
            context, showRequestCode, showIntent, Notifications.IMMUTABLE_UPDATE
        )
        try {
            if (ExactAlarms.canScheduleExact(context)) {
                alarmManager.setAlarmClock(AlarmManager.AlarmClockInfo(triggerTime, showPendingIntent), pendingIntent)
            } else {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
            }
        } catch (e: SecurityException) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
        }
    }

    fun cancelAlarm(context: Context, alarm: AlarmEntity) {
        cancelById(context, alarm.id)
    }

    fun cancelById(context: Context, alarmId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        for (code in intArrayOf(alarmId.toInt(), SNOOZE_REQUEST_BASE + alarmId.toInt())) {
            val pendingIntent = PendingIntent.getBroadcast(
                context, code, Intent(context, AlarmReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pendingIntent != null) {
                alarmManager.cancel(pendingIntent)
                pendingIntent.cancel()
            }
        }
    }

    /**
     * Calendário no fuso horário ATUAL do aparelho. Repõe o fuso por omissão para nunca usar
     * um valor antigo guardado em cache num processo que já estava a correr (por exemplo,
     * depois de uma viagem ou de uma mudança automática de fuso).
     */
    private fun deviceCalendar(): Calendar {
        TimeZone.setDefault(null)
        return Calendar.getInstance(TimeZone.getDefault())
    }

    /** Próxima ocorrência, em hora de relógio local (acompanha mudanças de hora e de fuso). */
    fun calculateNextTriggerMillis(hour: Int, minute: Int, repeatDaysStr: String): Long {
        val now = deviceCalendar()
        val target = deviceCalendar().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val days = RepeatDays.toCalendarDays(repeatDaysStr)
        if (days.isEmpty()) {
            if (target.timeInMillis <= now.timeInMillis) target.add(Calendar.DAY_OF_YEAR, 1)
            return target.timeInMillis
        }

        for (i in 0..7) {
            if (days.contains(target.get(Calendar.DAY_OF_WEEK)) && target.timeInMillis > now.timeInMillis) {
                return target.timeInMillis
            }
            target.add(Calendar.DAY_OF_YEAR, 1)
        }
        return target.timeInMillis
    }

    /** Ex.: "7 h 12 min", "1 d 3 h", "menos de 1 min". */
    fun formatDurationUntil(hour: Int, minute: Int, repeatDaysStr: String): String {
        val diffMillis = calculateNextTriggerMillis(hour, minute, repeatDaysStr) - System.currentTimeMillis()
        if (diffMillis <= 0) return "menos de 1 min"

        val totalMinutes = (diffMillis + 59_999L) / 60_000L
        val hours = totalMinutes / 60
        val minutes = totalMinutes % 60

        return when {
            hours == 0L -> if (minutes <= 1L) "1 min" else "$minutes min"
            hours < 24L -> if (minutes == 0L) "$hours h" else "$hours h $minutes min"
            else -> {
                val days = hours / 24
                val remHours = hours % 24
                if (remHours == 0L) "$days d" else "$days d $remHours h"
            }
        }
    }

    fun formatTimeUntil(hour: Int, minute: Int, repeatDaysStr: String): String {
        return "Toca daqui a " + formatDurationUntil(hour, minute, repeatDaysStr)
    }
}
