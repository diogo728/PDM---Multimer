package pt.ubi.di.pdm.multimer.data.repository

import androidx.lifecycle.LiveData
import pt.ubi.di.pdm.multimer.data.local.AlarmDao
import pt.ubi.di.pdm.multimer.data.model.AlarmEntity
import pt.ubi.di.pdm.multimer.sync.SyncManager

class AlarmRepository(private val alarmDao: AlarmDao) {
    val allAlarms: LiveData<List<AlarmEntity>> = alarmDao.getAllAlarms()

    suspend fun getAlarmById(id: Long): AlarmEntity? = alarmDao.getAlarmById(id)

    suspend fun getEnabledAlarms(): List<AlarmEntity> = alarmDao.getEnabledAlarmsList()

    /** Toda a alteração da definição ganha um identificador (se faltar) e uma marca de alteração. */
    private fun stamp(a: AlarmEntity): AlarmEntity =
        a.copy(syncId = a.syncId.ifBlank { SyncIds.newId() }, updatedAt = SyncIds.now())

    suspend fun insert(alarm: AlarmEntity): Long = alarmDao.insertAlarm(stamp(alarm))

    suspend fun update(alarm: AlarmEntity) = alarmDao.updateAlarm(stamp(alarm))

    suspend fun setEnabled(id: Long, enabled: Boolean) = alarmDao.setEnabled(id, enabled)

    suspend fun delete(alarm: AlarmEntity) {
        // O editor pode passar uma cópia sem identificador: vai buscar o verdadeiro
        val full = if (alarm.syncId.isBlank()) alarmDao.getAlarmById(alarm.id) ?: alarm else alarm
        alarmDao.deleteAlarm(full)
        if (full.syncId.isNotBlank()) SyncManager.onLocalDelete(SyncManager.ALARMS, full.syncId)
    }
}
