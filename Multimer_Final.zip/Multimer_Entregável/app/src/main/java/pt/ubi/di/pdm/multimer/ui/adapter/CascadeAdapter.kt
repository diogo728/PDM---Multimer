package pt.ubi.di.pdm.multimer.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.data.model.CascadeWithSteps
import pt.ubi.di.pdm.multimer.service.CascadeService
import pt.ubi.di.pdm.multimer.ui.view.StepTimelineView
import pt.ubi.di.pdm.multimer.util.CascadeFormat
import pt.ubi.di.pdm.multimer.util.RowActionsPopup
import pt.ubi.di.pdm.multimer.util.TimeFmt

/**
 * Lista de cascatas. Cada linha mostra o seu próprio progresso enquanto corre
 * (vários sequenciais podem correr ao mesmo tempo). O progresso é atualizado por
 * [CascadeViewHolder.updateRun], sem recarregar a lista.
 */
class CascadeAdapter(
    private val onPlayClick: (CascadeWithSteps, Boolean) -> Unit,
    private val onPauseClick: (CascadeWithSteps) -> Unit,
    private val onSkipClick: (CascadeWithSteps) -> Unit,
    private val onItemClick: (CascadeWithSteps) -> Unit,
    private val actionsFor: (CascadeWithSteps) -> List<RowActionsPopup.Action>
) : ListAdapter<CascadeWithSteps, CascadeAdapter.CascadeViewHolder>(DiffCallback()) {

    fun itemAt(position: Int): CascadeWithSteps? = currentList.getOrNull(position)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CascadeViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_cascade, parent, false)
        return CascadeViewHolder(view)
    }

    override fun onBindViewHolder(holder: CascadeViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class CascadeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvTitle: TextView = itemView.findViewById(R.id.tvCascadeTitle)
        private val tvSummary: TextView = itemView.findViewById(R.id.tvCascadeSummary)
        private val btnPlay: ImageButton = itemView.findViewById(R.id.btnPlay)
        private val layoutRun: View = itemView.findViewById(R.id.layoutRun)
        private val tvRunStep: TextView = itemView.findViewById(R.id.tvRunStep)
        private val tvRunTime: TextView = itemView.findViewById(R.id.tvRunTime)
        private val tvRunInfo: TextView = itemView.findViewById(R.id.tvRunInfo)
        private val timeline: StepTimelineView = itemView.findViewById(R.id.timelineRun)
        private val btnPause: ImageButton = itemView.findViewById(R.id.btnRunPause)
        private val btnSkip: ImageButton = itemView.findViewById(R.id.btnRunSkip)
        private var item: CascadeWithSteps? = null
        private var showingRun = false

        fun bind(data: CascadeWithSteps) {
            item = data
            tvTitle.text = data.cascade.title
            tvSummary.text = CascadeFormat.summary(data)
            btnPlay.setOnClickListener { onPlayClick(data, CascadeService.isRunning(data.cascade.id)) }
            btnPause.setOnClickListener { onPauseClick(data) }
            btnSkip.setOnClickListener { onSkipClick(data) }
            itemView.setOnClickListener { onItemClick(data) }
            RowActionsPopup.attach(itemView) { actionsFor(data) }
            // Força a atualização do aspeto (a vista pode vir reciclada de outra linha)
            showingRun = !CascadeService.isRunning(data.cascade.id)
            updateRun()
        }

        /** Atualiza o estado em execução desta linha (chamado várias vezes por segundo). */
        fun updateRun() {
            val data = item ?: return
            val ctx = itemView.context
            val run = CascadeService.runs[data.cascade.id]
            val running = run != null

            if (running != showingRun) {
                showingRun = running
                layoutRun.visibility = if (running) View.VISIBLE else View.GONE
                if (running) {
                    btnPlay.setImageResource(R.drawable.ic_stop)
                    btnPlay.setBackgroundResource(R.drawable.bg_circle_destructive_soft)
                    btnPlay.setColorFilter(ContextCompat.getColor(ctx, R.color.destructive))
                    btnPlay.contentDescription = "Parar"
                } else {
                    btnPlay.setImageResource(R.drawable.ic_play)
                    btnPlay.setBackgroundResource(R.drawable.bg_circle_accent_soft)
                    btnPlay.setColorFilter(ContextCompat.getColor(ctx, R.color.accent))
                    btnPlay.contentDescription = "Iniciar"
                }
            }
            if (run == null) return

            val position = run.index + 1
            val total = run.stepCount
            if (run.finished) {
                tvRunStep.setText(R.string.t_ultimo_toque)
                tvRunTime.setText(R.string.t_00_00)
                tvRunInfo.setText(R.string.t_a_terminar)
            } else {
                tvRunStep.text = if (run.isSequential) {
                    if (total > 0) "Próximo toque, $position de $total" else "Próximo toque, n.º $position"
                } else {
                    "Passo $position de $total, ${run.stepTitle}"
                }
                tvRunTime.text = TimeFmt.countdown(run.remainingMs())

                val overall = run.overallRemainingMs()
                tvRunInfo.text = when {
                    run.paused -> "Em pausa"
                    overall < 0L -> "Até parares"
                    run.isSequential -> {
                        val left = (total - position).coerceAtLeast(0)
                        if (left == 0) "Este é o último toque" else "Depois deste, mais $left, faltam ${TimeFmt.human(overall)}"
                    }
                    else -> "Faltam ${TimeFmt.human(overall)} no total"
                }
            }

            timeline.setSegments(run.timelineWeights())
            val (segment, fraction) = run.timelineProgress()
            timeline.setProgress(segment, fraction, run.paused)

            btnPause.setImageResource(if (run.paused) R.drawable.ic_play else R.drawable.ic_pause)
            btnPause.setColorFilter(ContextCompat.getColor(ctx, if (run.paused) R.color.accent else R.color.caution))
            btnPause.contentDescription = if (run.paused) "Retomar" else "Pausar"
            btnSkip.visibility = if (run.finished) View.GONE else View.VISIBLE
            btnPause.visibility = if (run.finished) View.GONE else View.VISIBLE
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<CascadeWithSteps>() {
        override fun areItemsTheSame(oldItem: CascadeWithSteps, newItem: CascadeWithSteps) =
            oldItem.cascade.id == newItem.cascade.id

        override fun areContentsTheSame(oldItem: CascadeWithSteps, newItem: CascadeWithSteps) =
            oldItem == newItem
    }
}
