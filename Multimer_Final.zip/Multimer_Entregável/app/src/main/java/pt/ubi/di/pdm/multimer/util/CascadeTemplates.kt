package pt.ubi.di.pdm.multimer.util

import pt.ubi.di.pdm.multimer.data.model.CascadeEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeStepEntity

/** Modelos prontos, guardados na própria app (sem rede), para não começar sempre do zero. */
object CascadeTemplates {

    private const val MIN = 60_000L
    private const val H = 60 * MIN

    class Template(
        val key: String,
        val name: String,
        val description: String,
        val type: Int,
        val cascade: CascadeEntity,
        val steps: List<CascadeStepEntity>
    )

    private fun seq(key: String, name: String, description: String, interval: Long, count: Int, manual: Boolean = false) =
        Template(
            key, name, description, CascadeEntity.TYPE_SEQUENTIAL,
            CascadeEntity(
                title = name, type = CascadeEntity.TYPE_SEQUENTIAL,
                intervalMillis = interval, repeatCount = count, autoDismiss = !manual,
                soundUri = SoundLibrary.DEFAULT_STEP
            ),
            emptyList()
        )

    private fun custom(key: String, name: String, description: String, steps: List<Triple<String, Long, Boolean>>) =
        Template(
            key, name, description, CascadeEntity.TYPE_CUSTOM,
            CascadeEntity(title = name, type = CascadeEntity.TYPE_CUSTOM),
            steps.mapIndexed { i, (title, ms, manual) ->
                CascadeStepEntity(
                    stepOrder = i, title = title, durationInMillis = ms, autoDismiss = !manual,
                    soundUri = SoundLibrary.DEFAULT_STEP
                )
            }
        )

    /** 3 min de aquecimento, 2 rondas de 4 exercícios (40 s + 20 s de pausa) e 3 min de alongamento. */
    private fun workoutSteps(): List<Triple<String, Long, Boolean>> {
        val steps = mutableListOf<Triple<String, Long, Boolean>>()
        steps.add(Triple("Aquecimento concluído, começa o circuito", 3 * MIN, false))
        for (round in 1..2) {
            for (exercise in 1..4) {
                if (exercise < 4) {
                    steps.add(Triple("Descansa 20 segundos", 40 * 1000L, false))
                    steps.add(Triple("Exercício ${exercise + 1}", 20 * 1000L, false))
                } else if (round == 1) {
                    steps.add(Triple("Fim da ronda 1, descansa 1 minuto", 40 * 1000L, false))
                    steps.add(Triple("Ronda 2, exercício 1", MIN, false))
                } else {
                    steps.add(Triple("Fim do circuito, hora de alongar", 40 * 1000L, false))
                }
            }
        }
        steps.add(Triple("Treino concluído, bom trabalho", 3 * MIN, true))
        return steps
    }

    val sequential: List<Template> = listOf(
        seq("seq_example", "4 toques de 5 em 5 min", "Toca 4 vezes, no total 20 minutos", 5 * MIN, 4),
        seq("seq_eyes", "Pausa para os olhos", "A cada 20 min, até parares (regra 20-20-20)", 20 * MIN, 0),
        seq("seq_drive", "Condução noturna", "A cada 20 min, exige que o desligues", 20 * MIN, 0, manual = true),
        seq("seq_water", "Hidratação", "A cada 1 h, 8 vezes", H, 8),
        seq("seq_posture", "Postura", "A cada 30 min, até parares", 30 * MIN, 0)
    )

    val custom: List<Template> = listOf(
        custom(
            "cus_pomodoro", "Pomodoro", "4 blocos de foco de 25 min com pausas",
            listOf(
                Triple("Hora de pausar", 25 * MIN, false), Triple("Voltar ao foco", 5 * MIN, false),
                Triple("Hora de pausar", 25 * MIN, false), Triple("Voltar ao foco", 5 * MIN, false),
                Triple("Hora de pausar", 25 * MIN, false), Triple("Voltar ao foco", 5 * MIN, false),
                Triple("Última pausa, 15 min", 25 * MIN, false), Triple("Ciclo concluído", 15 * MIN, true)
            )
        ),
        custom(
            "cus_workout", "Treino rápido", "Aquecimento, 2 rondas de 4 exercícios (40 s a trabalhar, 20 s de pausa) e alongamento",
            workoutSteps()
        ),
        custom(
            "cus_eggs", "Ovos cozidos", "Cozer e arrefecer",
            listOf(Triple("Retirar os ovos do lume", 10 * MIN, true), Triple("Já arrefeceram", 5 * MIN, false))
        ),
        custom(
            "cus_morning", "Rotina matinal", "Do despertar à saída de casa, com tempos realistas",
            listOf(
                Triple("Hora de tomar banho", 10 * MIN, false),
                Triple("Vestir e arranjar-se", 15 * MIN, false),
                Triple("Hora do pequeno-almoço", 15 * MIN, false),
                Triple("Lavar os dentes", 20 * MIN, false),
                Triple("Chaves, carteira e telemóvel", 5 * MIN, false),
                Triple("Hora de sair de casa", 5 * MIN, true)
            )
        )
    )

    fun forType(type: Int): List<Template> =
        if (type == CascadeEntity.TYPE_SEQUENTIAL) sequential else custom

    fun find(key: String?): Template? = (sequential + custom).firstOrNull { it.key == key }
}
