package pt.ubi.di.pdm.multimer.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import pt.ubi.di.pdm.multimer.data.model.TimerEntity
import pt.ubi.di.pdm.multimer.data.repository.TimerRepository

class TimerViewModel(private val repository: TimerRepository) : ViewModel() {

    val recentTimers = repository.allTimers.asLiveData()

    fun recordRecent(timer: TimerEntity) {
        viewModelScope.launch { repository.recordRecent(timer) }
    }

    fun deleteTimer(timer: TimerEntity) {
        viewModelScope.launch { repository.deleteTimer(timer) }
    }
}

class TimerViewModelFactory(private val repository: TimerRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TimerViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return TimerViewModel(repository) as T
        }
        throw IllegalArgumentException("Classe ViewModel desconhecida")
    }
}
