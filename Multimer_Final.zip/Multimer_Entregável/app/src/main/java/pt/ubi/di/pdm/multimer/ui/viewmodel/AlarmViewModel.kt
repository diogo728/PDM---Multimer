package pt.ubi.di.pdm.multimer.ui.viewmodel

import androidx.lifecycle.*
import kotlinx.coroutines.launch
import pt.ubi.di.pdm.multimer.data.model.AlarmEntity
import pt.ubi.di.pdm.multimer.data.repository.AlarmRepository

class AlarmViewModel(private val repository: AlarmRepository) : ViewModel() {
    val allAlarms: LiveData<List<AlarmEntity>> = repository.allAlarms

    fun insertAlarm(alarm: AlarmEntity, onInserted: (Long) -> Unit = {}) = viewModelScope.launch {
        val id = repository.insert(alarm)
        onInserted(id)
    }

    fun updateAlarm(alarm: AlarmEntity) = viewModelScope.launch {
        repository.update(alarm)
    }

    fun setEnabled(id: Long, enabled: Boolean) = viewModelScope.launch {
        repository.setEnabled(id, enabled)
    }

    fun deleteAlarm(alarm: AlarmEntity) = viewModelScope.launch {
        repository.delete(alarm)
    }

    fun loadAlarm(id: Long, onLoaded: (AlarmEntity?) -> Unit) = viewModelScope.launch {
        onLoaded(repository.getAlarmById(id))
    }
}

class AlarmViewModelFactory(private val repository: AlarmRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AlarmViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AlarmViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
