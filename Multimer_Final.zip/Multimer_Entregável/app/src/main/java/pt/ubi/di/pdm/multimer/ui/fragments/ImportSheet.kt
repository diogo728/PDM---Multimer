package pt.ubi.di.pdm.multimer.ui.fragments

import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.ui.activity.ImportActivity
import pt.ubi.di.pdm.multimer.ui.activity.ScanActivity

/** Formas de receber um alarme: ler um QR code com a câmara ou colar um código recebido. */
class ImportSheet : BottomSheetDialogFragment() {

    private val scanLauncher = registerForActivityResult(ScanContract()) { result ->
        val contents = result.contents
        if (!contents.isNullOrBlank()) {
            startActivity(ImportActivity.newIntent(requireContext(), contents))
            dismiss()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.sheet_import, container, false)
    }

    override fun onStart() {
        super.onStart()
        val dlg = dialog as? BottomSheetDialog ?: return
        dlg.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dlg.behavior.skipCollapsed = true
        dlg.behavior.isDraggable = false // o arrastar não fecha nem atrapalha o scroll
        dlg.setCanceledOnTouchOutside(false)
        dlg.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.backgroundTintList =
            ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.bg_grouped))
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val ctx = requireContext()
        view.findViewById<MaterialButton>(R.id.btnImportSheetClose).setOnClickListener { dismiss() }

        val container = view.findViewById<LinearLayout>(R.id.containerImportActions)
        val inflater = LayoutInflater.from(ctx)
        val rows = listOf(
            Triple("Ler um QR code", "Aponta a câmara ao código projetado ou noutro telemóvel") { scan() },
            Triple("Colar código", "Usa o código copiado de uma mensagem") { paste() },
            Triple("Entrar numa sala ao vivo", "Escreve o código (PIN) que o administrador te deu") {
                Toast.makeText(ctx, R.string.em_desenvolvimento, Toast.LENGTH_SHORT).show()
            }
        )
        rows.forEachIndexed { index, (name, desc, action) ->
            val row = inflater.inflate(R.layout.item_template_row, container, false)
            row.findViewById<TextView>(R.id.tvTemplateName).text = name
            row.findViewById<TextView>(R.id.tvTemplateDesc).text = desc
            row.setOnClickListener { action() }
            container.addView(row)
            if (index < rows.size - 1) {
                val divider = View(ctx)
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
                lp.marginStart = (16 * resources.displayMetrics.density).toInt()
                divider.layoutParams = lp
                divider.setBackgroundColor(ContextCompat.getColor(ctx, R.color.separator))
                container.addView(divider)
            }
        }
    }

    private fun scan() {
        val options = ScanOptions()
            .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            .setBeepEnabled(false)
            .setOrientationLocked(false)
            .setCaptureActivity(ScanActivity::class.java)
        scanLauncher.launch(options)
    }

    private fun paste() {
        val ctx = requireContext()
        val clipboard = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = clipboard.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString()
        if (text.isNullOrBlank()) {
            Toast.makeText(ctx, R.string.t_nao_ha_nenhum_codigo_copiado, Toast.LENGTH_SHORT).show()
            return
        }
        startActivity(ImportActivity.newIntent(ctx, text))
        dismiss()
    }
}
