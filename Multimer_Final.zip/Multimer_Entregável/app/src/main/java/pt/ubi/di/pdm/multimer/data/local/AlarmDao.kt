package pt.ubi.di.pdm.multimer.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import pt.ubi.di.pdm.multimer.data.model.AlarmEntity

@Dao
interface AlarmDao {
    @Query("SELECT * FROM alarms ORDER BY hour ASC, minute ASC")
    fun getAllAlarms(): LiveData<List<AlarmEntity>>

    @Query("SELECT * FROM alarms WHERE id = :id")
    suspend fun getAlarmById(id: Long): AlarmEntity?

    @Query("SELECT * FROM alarms WHERE isEnabled = 1")
    suspend fun getEnabledAlarmsList(): List<AlarmEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlarm(alarm: AlarmEntity): Long

    @Update
    suspend fun updateAlarm(alarm: AlarmEntity)

    @Delete
    suspend fun deleteAlarm(alarm: AlarmEntity)

    /** Ligar/desligar é uma escolha de cada aparelho: não conta como alteração a sincronizar. */
    @Query("UPDATE alarms SET isEnabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: Long, enabled: Boolean)

    // --- Sincronização ---
    @Query("SELECT * FROM alarms WHERE syncId = :syncId LIMIT 1")
    suspend fun getBySyncId(syncId: String): AlarmEntity?

    @Query("SELECT * FROM alarms WHERE updatedAt > syncedAt")
    fun observeDirty(): Flow<List<AlarmEntity>>

    @Query("SELECT * FROM alarms")
    suspend fun getAllOnce(): List<AlarmEntity>

    @Query("SELECT COUNT(*) FROM alarms")
    suspend fun count(): Int

    @Query("UPDATE alarms SET syncedAt = :version WHERE syncId = :syncId AND updatedAt = :version")
    suspend fun markSynced(syncId: String, version: Long)

    @Query("UPDATE alarms SET syncedAt = updatedAt")
    suspend fun markAllSynced()

    @Query("DELETE FROM alarms WHERE syncId = :syncId")
    suspend fun deleteBySyncId(syncId: String)
}
