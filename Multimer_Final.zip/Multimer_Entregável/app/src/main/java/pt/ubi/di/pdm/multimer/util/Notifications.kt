package pt.ubi.di.pdm.multimer.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object Notifications {
    /** Notificações permanentes (temporizador e cascata a correr). Silenciosas. */
    const val CHANNEL_RUNNING = "multimer_running"

    /** Alarmes e toques. O som é tocado pela app, não pelo canal. */
    const val CHANNEL_ALERT = "multimer_alert"

    val IMMUTABLE_UPDATE: Int = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val running = NotificationChannel(CHANNEL_RUNNING, "Em execução", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Temporizadores e cascatas em curso"
            setShowBadge(false)
        }
        val alert = NotificationChannel(CHANNEL_ALERT, "Alarmes e toques", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Quando um alarme, temporizador ou passo da cascata toca"
            setSound(null, null)
            enableVibration(false)
            lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
        }
        nm.createNotificationChannel(running)
        nm.createNotificationChannel(alert)
    }

    fun servicePendingIntent(ctx: Context, cls: Class<*>, action: String, requestCode: Int, foreground: Boolean = false): PendingIntent {
        val intent = Intent(ctx, cls).setAction(action)
        return if (foreground && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            PendingIntent.getForegroundService(ctx, requestCode, intent, IMMUTABLE_UPDATE)
        } else {
            PendingIntent.getService(ctx, requestCode, intent, IMMUTABLE_UPDATE)
        }
    }
}
