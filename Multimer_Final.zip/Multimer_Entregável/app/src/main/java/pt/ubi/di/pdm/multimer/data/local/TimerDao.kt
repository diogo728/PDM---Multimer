package pt.ubi.di.pdm.multimer.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import pt.ubi.di.pdm.multimer.data.model.TimerEntity

/** A tabela "timers" guarda os temporizadores recentes (atalhos para repetir rapidamente). */
@Dao
interface TimerDao {

    @Query("SELECT * FROM timers ORDER BY createdAt DESC LIMIT 12")
    fun getAllTimers(): Flow<List<TimerEntity>>

    @Query("SELECT * FROM timers WHERE id = :id")
    suspend fun getTimerById(id: Long): TimerEntity?

    @Query("SELECT * FROM timers WHERE durationInMillis = :duration AND title = :title")
    suspend fun findDuplicates(duration: Long, title: String): List<TimerEntity>

    /** Os que excedem os 12 mais recentes. */
    @Query("SELECT * FROM timers ORDER BY createdAt DESC LIMIT -1 OFFSET 12")
    suspend fun getOverflow(): List<TimerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTimer(timer: TimerEntity): Long

    @Update
    suspend fun updateTimer(timer: TimerEntity)

    @Delete
    suspend fun deleteTimer(timer: TimerEntity)

    // --- Sincronização ---
    @Query("SELECT * FROM timers WHERE syncId = :syncId LIMIT 1")
    suspend fun getBySyncId(syncId: String): TimerEntity?

    @Query("SELECT * FROM timers WHERE updatedAt > syncedAt")
    fun observeDirty(): Flow<List<TimerEntity>>

    @Query("SELECT * FROM timers")
    suspend fun getAllOnce(): List<TimerEntity>

    @Query("SELECT COUNT(*) FROM timers")
    suspend fun count(): Int

    @Query("UPDATE timers SET syncedAt = :version WHERE syncId = :syncId AND updatedAt = :version")
    suspend fun markSynced(syncId: String, version: Long)

    @Query("UPDATE timers SET syncedAt = updatedAt")
    suspend fun markAllSynced()

    @Query("DELETE FROM timers WHERE syncId = :syncId")
    suspend fun deleteBySyncId(syncId: String)
}
