package pt.ubi.di.pdm.multimer.util

import android.content.Context
import android.os.SystemClock
import android.provider.Settings

/**
 * Estado do cronómetro, independente do ecrã: continua a contar ao mudar de aba, com a app em
 * segundo plano e até se o processo for terminado.
 *
 * Conta com o relógio monotónico do sistema, por isso ajustes da hora (automáticos ou manuais) e
 * mudanças de fuso horário não o fazem saltar. A hora de parede só serve de apoio se o aparelho
 * reiniciar com o cronómetro a correr.
 */
object StopwatchStore {
    private const val PREFS = "stopwatch_state"

    data class Lap(val number: Int, val lapMs: Long, val totalMs: Long)

    private var loaded = false
    private var accumulatedMs = 0L
    private var startedAtElapsed = 0L
    private var startedAtWall = 0L
    private var bootCount = -1
    private val lapTotals = mutableListOf<Long>()

    var isRunning: Boolean = false
        private set

    private fun currentBootCount(ctx: Context): Int =
        try {
            Settings.Global.getInt(ctx.applicationContext.contentResolver, Settings.Global.BOOT_COUNT, -1)
        } catch (e: Exception) {
            -1
        }

    fun load(ctx: Context) {
        if (loaded) return
        val sp = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        isRunning = sp.getBoolean("running", false)
        accumulatedMs = sp.getLong("accumulated", 0L)
        startedAtElapsed = sp.getLong("started_elapsed", 0L)
        startedAtWall = sp.getLong("started_wall", 0L)
        bootCount = sp.getInt("boot_count", -1)
        lapTotals.clear()
        val raw = sp.getString("laps", "") ?: ""
        if (raw.isNotEmpty()) {
            raw.split(",").mapNotNull { it.toLongOrNull() }.forEach { lapTotals.add(it) }
        }

        if (isRunning) {
            val sameBoot = bootCount != -1 && bootCount == currentBootCount(ctx)
            if (!sameBoot) {
                // O aparelho reiniciou: o relógio monotónico recomeçou, usa a hora de parede só desta vez
                val elapsedSince = (System.currentTimeMillis() - startedAtWall).coerceAtLeast(0L)
                startedAtElapsed = (SystemClock.elapsedRealtime() - elapsedSince).coerceAtLeast(0L)
                bootCount = currentBootCount(ctx)
                save(ctx)
            }
        }
        loaded = true
    }

    private fun save(ctx: Context) {
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("running", isRunning)
            .putLong("accumulated", accumulatedMs)
            .putLong("started_elapsed", startedAtElapsed)
            .putLong("started_wall", startedAtWall)
            .putInt("boot_count", bootCount)
            .putString("laps", lapTotals.joinToString(","))
            .apply()
    }

    fun elapsedMs(): Long {
        val running = if (isRunning) (SystemClock.elapsedRealtime() - startedAtElapsed).coerceAtLeast(0L) else 0L
        return accumulatedMs + running
    }

    val hasTime: Boolean get() = isRunning || accumulatedMs > 0L

    fun start(ctx: Context) {
        if (isRunning) return
        startedAtElapsed = SystemClock.elapsedRealtime()
        startedAtWall = System.currentTimeMillis()
        bootCount = currentBootCount(ctx)
        isRunning = true
        save(ctx)
    }

    fun pause(ctx: Context) {
        if (!isRunning) return
        accumulatedMs = elapsedMs()
        isRunning = false
        save(ctx)
    }

    fun reset(ctx: Context) {
        isRunning = false
        accumulatedMs = 0L
        startedAtElapsed = 0L
        startedAtWall = 0L
        lapTotals.clear()
        save(ctx)
    }

    fun lap(ctx: Context) {
        if (!isRunning) return
        lapTotals.add(elapsedMs())
        save(ctx)
    }

    /** Voltas da mais recente para a mais antiga. */
    fun laps(): List<Lap> {
        val result = mutableListOf<Lap>()
        var previous = 0L
        lapTotals.forEachIndexed { index, total ->
            result.add(Lap(index + 1, total - previous, total))
            previous = total
        }
        return result.reversed()
    }
}
