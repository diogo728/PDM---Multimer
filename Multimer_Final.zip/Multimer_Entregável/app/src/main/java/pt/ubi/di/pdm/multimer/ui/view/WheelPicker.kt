package pt.ubi.di.pdm.multimer.ui.view

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Typeface
import android.util.AttributeSet
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSnapHelper
import androidx.recyclerview.widget.RecyclerView
import pt.ubi.di.pdm.multimer.R
import kotlin.math.abs
import kotlin.math.min

/**
 * Roda de seleção vertical, com ajuste automático à linha central e opção de dar a volta.
 * O destaque da linha central é desenhado por uma vista atrás da roda (ver layouts).
 */
class WheelPicker @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : RecyclerView(context, attrs, defStyleAttr) {

    private val itemHeightPx = (ROW_HEIGHT_DP * resources.displayMetrics.density).toInt()
    private val wheelLayoutManager = LinearLayoutManager(context)
    private val snapHelper = LinearSnapHelper()
    private val wheelAdapter = WheelAdapter()

    private var items: List<String> = emptyList()
    private var wrap = true
    private var pendingIndex = 0
    private var lastTickIndex = -1
    private var userScrolling = false

    /** Valor mínimo quando usada como intervalo numérico. */
    var minValue: Int = 0
        private set

    var onValueChanged: ((Int) -> Unit)? = null

    val selectedIndex: Int
        get() {
            val n = items.size
            if (n == 0) return 0
            val snap = snapHelper.findSnapView(wheelLayoutManager) ?: return pendingIndex
            val pos = getChildAdapterPosition(snap)
            return if (pos == RecyclerView.NO_POSITION) pendingIndex else pos % n
        }

    /** Valor numérico selecionado (índice + valor mínimo). */
    var value: Int
        get() = selectedIndex + minValue
        set(v) {
            setSelectedIndex(v - minValue)
        }

    init {
        layoutManager = wheelLayoutManager
        overScrollMode = View.OVER_SCROLL_NEVER
        isVerticalScrollBarEnabled = false
        clipToPadding = false
        val pad = itemHeightPx * (VISIBLE_ROWS / 2)
        setPadding(paddingLeft, pad, paddingRight, pad)
        itemAnimator = null
        // A roda trata sozinha do seu gesto; a página à volta não deve roubá-lo
        isNestedScrollingEnabled = false
        snapHelper.attachToRecyclerView(this)
        adapter = wheelAdapter

        addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                updateChildLook()
                val idx = selectedIndex
                if (idx != lastTickIndex) {
                    if (lastTickIndex != -1 && userScrolling) {
                        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    }
                    lastTickIndex = idx
                }
            }

            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                userScrolling = newState != RecyclerView.SCROLL_STATE_IDLE
                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    onValueChanged?.invoke(selectedIndex)
                }
            }
        })
    }

    fun setItems(newItems: List<String>, wrapAround: Boolean = true, selected: Int = 0) {
        items = newItems
        wrap = wrapAround
        minValue = 0
        wheelAdapter.notifyDataSetChanged()
        setSelectedIndex(selected)
    }

    fun setNumberRange(min: Int, max: Int, selected: Int = min, twoDigits: Boolean = true, wrapAround: Boolean = true) {
        val list = (min..max).map { if (twoDigits) String.format("%02d", it) else it.toString() }
        items = list
        wrap = wrapAround
        minValue = min
        wheelAdapter.notifyDataSetChanged()
        setSelectedIndex(selected - min)
    }

    fun setSelectedIndex(index: Int) {
        if (items.isEmpty()) return
        val i = index.coerceIn(0, items.size - 1)
        pendingIndex = i
        lastTickIndex = i
        val pos = if (wrap) (REPEAT / 2) * items.size + i else i
        wheelLayoutManager.scrollToPositionWithOffset(pos, 0)
        post { updateChildLook() }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> parent?.requestDisallowInterceptTouchEvent(true)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> parent?.requestDisallowInterceptTouchEvent(false)
        }
        return super.onTouchEvent(e)
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) parent?.requestDisallowInterceptTouchEvent(true)
        return super.onInterceptTouchEvent(e)
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        super.onMeasure(widthSpec, View.MeasureSpec.makeMeasureSpec(itemHeightPx * VISIBLE_ROWS, View.MeasureSpec.EXACTLY))
    }

    private fun updateChildLook() {
        val center = height / 2f
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            val childCenter = (child.top + child.bottom) / 2f
            val rows = abs(childCenter - center) / itemHeightPx
            val t = min(rows / 2.2f, 1f)
            child.alpha = 1f - 0.72f * t
            val scale = 1f - 0.16f * t
            child.scaleX = scale
            child.scaleY = scale
        }
    }

    private inner class WheelAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount(): Int {
            if (items.isEmpty()) return 0
            return if (wrap) items.size * REPEAT else items.size
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val tv = TextView(parent.context)
            tv.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, itemHeightPx)
            tv.gravity = Gravity.CENTER
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            tv.typeface = ResourcesCompat.getFont(parent.context, R.font.multimer_sans_light) ?: Typeface.DEFAULT
            tv.fontFeatureSettings = "tnum"
            tv.setTextColor(ContextCompat.getColor(parent.context, R.color.text_primary))
            tv.includeFontPadding = false
            return object : RecyclerView.ViewHolder(tv) {}
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            (holder.itemView as TextView).text = items[position % items.size]
        }
    }

    companion object {
        const val ROW_HEIGHT_DP = 44
        private const val VISIBLE_ROWS = 5
        private const val REPEAT = 200
    }
}
