package pt.ubi.di.pdm.multimer.util

import android.content.Context

/** Preferências simples: últimas definições do temporizador. */
object Prefs {
    private const val NAME = "multimer_prefs"

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun timerSoundUri(ctx: Context): String? =
        sp(ctx).getString("timer_sound_uri", null) ?: SoundLibrary.DEFAULT_TIMER
    fun timerSoundTitle(ctx: Context): String =
        sp(ctx).getString("timer_sound_title", null) ?: SoundUtils.titleFor(ctx, timerSoundUri(ctx))
    fun setTimerSound(ctx: Context, uri: String?, title: String) {
        sp(ctx).edit().putString("timer_sound_uri", uri).putString("timer_sound_title", title)
            .putLong("timer_prefs_updated", System.currentTimeMillis()).apply()
    }

    fun timerVibrate(ctx: Context): Boolean = sp(ctx).getBoolean("timer_vibrate", true)
    fun setTimerVibrate(ctx: Context, v: Boolean) =
        sp(ctx).edit().putBoolean("timer_vibrate", v).putLong("timer_prefs_updated", System.currentTimeMillis()).apply()

    /** true = toca uma vez e pára sozinho. */
    fun timerAutoStop(ctx: Context): Boolean = sp(ctx).getBoolean("timer_auto_stop", false)
    fun setTimerAutoStop(ctx: Context, v: Boolean) =
        sp(ctx).edit().putBoolean("timer_auto_stop", v).putLong("timer_prefs_updated", System.currentTimeMillis()).apply()

    fun permissionsAsked(ctx: Context): Boolean = sp(ctx).getBoolean("permissions_asked", false)
    fun setPermissionsAsked(ctx: Context) = sp(ctx).edit().putBoolean("permissions_asked", true).apply()

    // --- Conta e sincronização ---

    /** Última alteração das definições do temporizador (para sincronizar). */
    fun timerSettingsUpdatedAt(ctx: Context): Long = sp(ctx).getLong("timer_prefs_updated", 0L)

    /** Aplica definições vindas da conta sem as contar como alteração local. */
    fun applyRemoteTimerSettings(ctx: Context, soundUri: String?, vibrate: Boolean, autoStop: Boolean, updatedAt: Long) {
        sp(ctx).edit()
            .putString("timer_sound_uri", soundUri)
            .putString("timer_sound_title", SoundUtils.titleFor(ctx, soundUri))
            .putBoolean("timer_vibrate", vibrate)
            .putBoolean("timer_auto_stop", autoStop)
            .putLong("timer_prefs_updated", updatedAt)
            .apply()
    }

    /** Se o utilizador já decidiu se envia para a conta o que existe neste aparelho. */
    fun syncChoiceMade(ctx: Context, uid: String): Boolean = sp(ctx).getBoolean("sync_choice_$uid", false)
    fun setSyncChoiceMade(ctx: Context, uid: String) = sp(ctx).edit().putBoolean("sync_choice_$uid", true).apply()
    fun clearSyncChoice(ctx: Context, uid: String) = sp(ctx).edit().remove("sync_choice_$uid").apply()

    fun syncPaused(ctx: Context): Boolean = sp(ctx).getBoolean("sync_paused", false)
    fun setSyncPaused(ctx: Context, paused: Boolean) = sp(ctx).edit().putBoolean("sync_paused", paused).apply()

    /** Eliminações feitas enquanto a sincronização não estava ativa ("uid|coleção|id"). */
    fun pendingDeletes(ctx: Context): Set<String> = sp(ctx).getStringSet("pending_deletes", emptySet()) ?: emptySet()
    fun addPendingDelete(ctx: Context, entry: String) {
        val set = HashSet(pendingDeletes(ctx))
        set.add(entry)
        sp(ctx).edit().putStringSet("pending_deletes", set).apply()
    }
    fun removePendingDelete(ctx: Context, entry: String) {
        val set = HashSet(pendingDeletes(ctx))
        set.remove(entry)
        sp(ctx).edit().putStringSet("pending_deletes", set).apply()
    }

    /** Último nome usado como convidado numa sala ao vivo. */
    fun guestName(ctx: Context): String = sp(ctx).getString("guest_name", null) ?: ""
    fun setGuestName(ctx: Context, name: String) = sp(ctx).edit().putString("guest_name", name).apply()
}
