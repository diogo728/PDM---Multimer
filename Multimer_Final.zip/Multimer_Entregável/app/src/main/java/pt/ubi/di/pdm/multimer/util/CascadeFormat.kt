package pt.ubi.di.pdm.multimer.util

import pt.ubi.di.pdm.multimer.data.model.CascadeEntity
import pt.ubi.di.pdm.multimer.data.model.CascadeWithSteps

object CascadeFormat {

    fun summary(item: CascadeWithSteps): String {
        val c = item.cascade
        return if (c.type == CascadeEntity.TYPE_SEQUENTIAL) {
            val every = "A cada " + TimeFmt.human(c.intervalMillis)
            if (c.repeatCount <= 0) {
                "$every, até parares"
            } else {
                val total = TimeFmt.human(c.intervalMillis * c.repeatCount)
                val toques = if (c.repeatCount == 1) "1 toque" else "${c.repeatCount} toques"
                "$every, $toques ($total)"
            }
        } else {
            val n = item.steps.size
            val total = item.steps.sumOf { it.durationInMillis }
            val passos = if (n == 1) "1 passo" else "$n passos"
            "$passos, ${TimeFmt.human(total)} no total"
        }
    }
}
