package pt.ubi.di.pdm.multimer.ui.fragments

import android.content.res.ColorStateList
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.asLiveData
import androidx.lifecycle.lifecycleScope
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.launch
import pt.ubi.di.pdm.multimer.R
import pt.ubi.di.pdm.multimer.sync.AuthManager
import pt.ubi.di.pdm.multimer.sync.SyncManager
import pt.ubi.di.pdm.multimer.util.Prefs
import pt.ubi.di.pdm.multimer.util.Segmented

/**
 * Conta e sincronização. Tudo opcional: sem conta a app funciona na mesma, só offline.
 * Com conta, os alarmes, cascatas e temporizadores recentes ficam iguais em todos os aparelhos.
 */
class AccountSheet : BottomSheetDialogFragment() {

    private var registerMode = false
    private var choiceDialogShowing = false

    private lateinit var layoutSignedOut: View
    private lateinit var layoutSignedIn: View
    private lateinit var layoutUnavailable: View
    private lateinit var layoutNameRow: View
    private lateinit var etName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var tvError: TextView
    private lateinit var btnSubmit: MaterialButton
    private lateinit var segmented: Segmented

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.sheet_account, container, false)
    }

    override fun onStart() {
        super.onStart()
        val dlg = dialog as? BottomSheetDialog ?: return
        dlg.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dlg.behavior.skipCollapsed = true
        dlg.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.backgroundTintList =
            ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.bg_grouped))
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val ctx = requireContext()

        layoutSignedOut = view.findViewById(R.id.layoutSignedOut)
        layoutSignedIn = view.findViewById(R.id.layoutSignedIn)
        layoutUnavailable = view.findViewById(R.id.layoutUnavailable)
        layoutNameRow = view.findViewById(R.id.layoutNameRow)
        etName = view.findViewById(R.id.etAccountName)
        etEmail = view.findViewById(R.id.etAccountEmail)
        etPassword = view.findViewById(R.id.etAccountPassword)
        tvError = view.findViewById(R.id.tvAccountError)
        btnSubmit = view.findViewById(R.id.btnAccountSubmit)

        // O campo de palavra-passe fica sempre escondido, mesmo depois de rodar o ecrã
        etPassword.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD

        view.findViewById<MaterialButton>(R.id.btnAccountClose).setOnClickListener { dismiss() }

        segmented = Segmented(
            listOf<View>(view.findViewById<View>(R.id.segLogin), view.findViewById<View>(R.id.segRegister))
        ) { index ->
            registerMode = index == 1
            renderMode()
        }
        segmented.select(if (registerMode) 1 else 0)

        btnSubmit.setOnClickListener { submit() }
        view.findViewById<View>(R.id.btnAccountForgot).setOnClickListener { resetPassword() }

        val switchAuto = view.findViewById<MaterialSwitch>(R.id.switchSyncAuto)
        switchAuto.isChecked = !Prefs.syncPaused(ctx)
        switchAuto.setOnCheckedChangeListener { _, checked -> SyncManager.setPaused(!checked) }

        view.findViewById<View>(R.id.btnSyncNow).setOnClickListener {
            SyncManager.syncNow()
            Toast.makeText(ctx, R.string.t_a_sincronizar, Toast.LENGTH_SHORT).show()
        }
        view.findViewById<View>(R.id.btnSignOut).setOnClickListener {
            AuthManager.signOut()
            render()
        }
        view.findViewById<View>(R.id.btnDeleteAccount).setOnClickListener { confirmDelete() }

        SyncManager.state.asLiveData().observe(viewLifecycleOwner) { render() }
        renderMode()
        render()
    }

    private fun renderMode() {
        layoutNameRow.visibility = if (registerMode) View.VISIBLE else View.GONE
        btnSubmit.text = if (registerMode) "Criar conta" else "Entrar"
        tvError.visibility = View.GONE
    }

    private fun render() {
        if (!isAdded || view == null) return
        val ctx = requireContext()
        if (!AuthManager.available(ctx)) {
            layoutSignedOut.visibility = View.GONE
            layoutSignedIn.visibility = View.GONE
            layoutUnavailable.visibility = View.VISIBLE
            return
        }
        layoutUnavailable.visibility = View.GONE
        val user = AuthManager.currentUser(ctx)
        if (user == null) {
            layoutSignedIn.visibility = View.GONE
            layoutSignedOut.visibility = View.VISIBLE
            return
        }
        layoutSignedOut.visibility = View.GONE
        layoutSignedIn.visibility = View.VISIBLE

        val name = AuthManager.displayName(user)
        val v = requireView()
        v.findViewById<TextView>(R.id.tvAccountAvatar).text = name.take(1).uppercase()
        v.findViewById<TextView>(R.id.tvAccountName).text = name
        v.findViewById<TextView>(R.id.tvAccountEmail).text = user.email ?: ""
        v.findViewById<TextView>(R.id.tvAccountSync).text = when (SyncManager.state.value) {
            SyncManager.State.SYNCED -> "Tudo sincronizado"
            SyncManager.State.SYNCING -> "A sincronizar…"
            SyncManager.State.OFFLINE_PENDING -> "Sem ligação, sincroniza quando houver internet"
            SyncManager.State.PAUSED -> "Em pausa"
            SyncManager.State.CHOICE_PENDING -> "À espera da tua escolha"
            else -> ""
        }
        if (SyncManager.state.value == SyncManager.State.CHOICE_PENDING) askUploadChoice()
    }

    private fun showError(message: String) {
        tvError.text = message
        tvError.visibility = View.VISIBLE
    }

    private fun setBusy(busy: Boolean) {
        btnSubmit.isEnabled = !busy
        btnSubmit.alpha = if (busy) 0.5f else 1f
    }

    private fun submit() {
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString()
        val name = etName.text.toString().trim()
        when {
            registerMode && name.isEmpty() -> return showError("Indica o teu nome.")
            !email.contains("@") || !email.contains(".") -> return showError("Indica um e-mail válido.")
            password.length < 6 -> return showError("A palavra-passe precisa de pelo menos 6 caracteres.")
        }
        tvError.visibility = View.GONE
        setBusy(true)
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                if (registerMode) AuthManager.register(name, email, password) else AuthManager.signIn(email, password)
                etPassword.setText("")
                render()
            } catch (e: Exception) {
                showError(AuthManager.friendlyError(e))
            } finally {
                setBusy(false)
            }
        }
    }

    private fun resetPassword() {
        val email = etEmail.text.toString().trim()
        if (!email.contains("@")) {
            showError("Escreve primeiro o teu e-mail.")
            return
        }
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                AuthManager.sendPasswordReset(email)
                Toast.makeText(requireContext(), R.string.t_se_existir_uma_conta_com, Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                showError(AuthManager.friendlyError(e))
            }
        }
    }

    /** Primeira vez neste aparelho: enviar ou não o que já existe aqui para a conta. */
    private fun askUploadChoice() {
        if (choiceDialogShowing) return
        choiceDialogShowing = true
        viewLifecycleOwner.lifecycleScope.launch {
            val count = SyncManager.localCount()
            if (!isAdded) return@launch
            AlertDialog.Builder(requireContext())
                .setTitle(R.string.t_enviar_o_que_tens_neste)
                .setMessage(
                    "Tens $count itens guardados neste aparelho (alarmes, cascatas e temporizadores). " +
                        "Queres enviá-los para a tua conta para os teres em todos os aparelhos?"
                )
                .setCancelable(false)
                .setPositiveButton(R.string.t_enviar) { _, _ -> SyncManager.confirmUploadChoice(true) }
                .setNegativeButton(R.string.t_nao_enviar) { _, _ -> SyncManager.confirmUploadChoice(false) }
                .setOnDismissListener { choiceDialogShowing = false }
                .show()
        }
    }

    private fun confirmDelete() {
        val ctx = requireContext()
        val input = EditText(ctx)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        input.hint = "Palavra-passe"
        val pad = (20 * resources.displayMetrics.density).toInt()
        input.setPadding(pad, pad, pad, pad)
        AlertDialog.Builder(ctx)
            .setTitle(R.string.t_eliminar_conta)
            .setMessage(
                "Isto apaga a tua conta e tudo o que foi sincronizado. O conteúdo guardado neste aparelho mantém-se. " +
                    "Confirma com a tua palavra-passe."
            )
            .setView(input)
            .setPositiveButton(R.string.t_eliminar) { _, _ ->
                val password = input.text.toString()
                viewLifecycleOwner.lifecycleScope.launch {
                    try {
                        AuthManager.deleteAccount(ctx, password)
                        Toast.makeText(ctx, R.string.t_conta_eliminada, Toast.LENGTH_SHORT).show()
                        render()
                    } catch (e: Exception) {
                        Toast.makeText(ctx, AuthManager.friendlyError(e), Toast.LENGTH_LONG).show()
                    }
                }
            }
            .setNegativeButton(R.string.t_cancelar, null)
            .show()
    }
}
