# Gera os 15 sons de app/src/main/res/raw (síntese aditiva, sem ficheiros externos).
# Uso: criar as pastas wav/ e ogg/, correr este ficheiro e depois codificar com:
#   for f in wav/*.wav; do ffmpeg -y -i $f -ac 1 -c:a libvorbis -q:a 4 ogg/$(basename $f .wav).ogg; done
# Requer numpy e scipy.
import numpy as np
from scipy.signal import fftconvolve, butter, sosfilt
import wave, os

SR = 44100
rng = np.random.default_rng(7)

def t_(dur): return np.arange(int(dur * SR)) / SR

def buf(dur): return np.zeros(int(dur * SR) + 1)

def put(b, sig, start, gain=1.0):
    i = int(start * SR)
    if i >= len(b): return
    n = min(len(sig), len(b) - i)
    b[i:i + n] += sig[:n] * gain

def attack(sig, ms=2.0):
    n = min(len(sig), int(ms / 1000 * SR))
    if n > 0: sig[:n] *= np.linspace(0, 1, n)
    return sig

def release(sig, ms=8.0):
    n = min(len(sig), int(ms / 1000 * SR))
    if n > 0: sig[-n:] *= np.linspace(1, 0, n)
    return sig

def hz(note):  # nome -> frequência, ex 'C5'
    names = {'C':0,'D':2,'E':4,'F':5,'G':7,'A':9,'B':11}
    n = names[note[0]]; o = int(note[-1]); acc = 0
    if len(note) == 3: acc = 1 if note[1] == '#' else -1
    return 440.0 * 2 ** (((o + 1) * 12 + n + acc - 69) / 12)

def bell(f, dur=3.0, decay=1.4, bright=1.0):
    t = t_(dur); s = np.zeros_like(t)
    for ratio, amp, df in [(1, 1, 1), (2.0, .42, .7), (2.76, .30, .55), (5.4, .14*bright, .32), (8.93, .07*bright, .2)]:
        s += amp * np.sin(2*np.pi*f*ratio*t) * np.exp(-t/(decay*df))
    return release(attack(s))

def marimba(f, dur=1.2, decay=.45):
    t = t_(dur); s = np.zeros_like(t)
    for ratio, amp, df in [(1, 1, 1), (4.0, .30, .22), (9.9, .08, .08)]:
        s += amp * np.sin(2*np.pi*f*ratio*t) * np.exp(-t/(decay*df))
    return release(attack(s, 1.0))

def pluck(f, dur=1.6, decay=.7):
    t = t_(dur); s = np.zeros_like(t)
    for k in range(1, 8):
        s += (1/k) * np.sin(2*np.pi*f*k*t) * np.exp(-t/(decay/(1 + .55*(k-1))))
    return release(attack(s, 1.5))

def glass(f, dur=3.0, decay=1.6):
    t = t_(dur); vib = 1 + .0015*np.sin(2*np.pi*5.2*t)
    s = np.sin(2*np.pi*f*t*vib) * np.exp(-t/decay)
    s += .28*np.sin(2*np.pi*f*2.0*t) * np.exp(-t/(decay*.6))
    s += .10*np.sin(2*np.pi*f*3.01*t) * np.exp(-t/(decay*.4))
    return release(attack(s, 12.0), 30)

def beep(f, dur=.1):
    t = t_(dur)
    s = np.sin(2*np.pi*f*t) + .18*np.sin(2*np.pi*f*3*t)
    return release(attack(s, 6.0), 10.0)

def wood(f=900, dur=.12):
    t = t_(dur)
    s = np.sin(2*np.pi*(f*(.78 + .22*np.exp(-t/.01)))*t) * np.exp(-t/.028)
    n = rng.standard_normal(len(t))
    sos = butter(2, [1500, 5000], btype='band', fs=SR, output='sos')
    s += .35 * sosfilt(sos, n) * np.exp(-t/.008)
    return release(attack(s, .5), 4.0)

def drop(f0=520, f1=1250, dur=.5):
    t = t_(dur)
    f = f1 - (f1 - f0) * np.exp(-t/.035)
    phase = 2*np.pi*np.cumsum(f)/SR
    s = np.sin(phase) * np.exp(-t/.11)
    return release(attack(s, 1.0), 20.0)

def reverb(x, wet=.22, rt=.9):
    n = int(rt * SR)
    t = np.arange(n) / SR
    ir = rng.standard_normal(n) * np.exp(-t / (rt/5.5))
    ir[:int(.012*SR)] *= np.linspace(0, 1, int(.012*SR))
    ir /= np.sqrt(np.sum(ir**2))
    y = fftconvolve(x, ir)[:len(x) + n//2]
    out = np.zeros(len(y)); out[:len(x)] += x * (1 - wet*.5)
    out += y * wet
    return out

def finish(x, target_rms_db=-13.5, tail=.25):
    """Iguala o volume percebido (RMS nas partes com som) e limita os picos de forma suave."""
    x = np.concatenate([x, np.zeros(int(tail*SR))])
    x = x - np.mean(x)
    fr = int(.05*SR)
    e = np.array([np.sqrt(np.mean(x[i:i+fr]**2)) for i in range(0, len(x)-fr, fr)])
    act = e[e > e.max()*.05]
    rms = np.sqrt(np.mean(act**2)) + 1e-9
    x = x * (10 ** (target_rms_db/20) / rms)
    peak = np.max(np.abs(x))
    if peak > .9:
        x = np.tanh(x / peak * 1.1) / np.tanh(1.1) * .9
    n = int(.004*SR); x[:n] *= np.linspace(0, 1, n)
    n = int(.12*SR);  x[-n:] *= np.linspace(1, 0, n)
    idx = np.where(np.abs(x) > 1e-3)[0]
    end = min(len(x), (idx[-1] if len(idx) else len(x)) + int(.2*SR))
    return x[:end]

def save(name, x):
    y = (np.clip(x, -1, 1) * 32767).astype('<i2')
    with wave.open(f'wav/{name}.wav', 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(y.tobytes())

S = {}

# ---------------- CURTOS ----------------
b = buf(1.3)
put(b, drop(), 0.0, 1.0); put(b, drop(560, 1400), .55, .85)
S['snd_short_drop'] = finish(reverb(b, .18, .5))

b = buf(1.0)
put(b, wood(900), 0.0, 1.0); put(b, wood(1050), .26, .9)
S['snd_short_wood'] = finish(reverb(b, .12, .35))

b = buf(2.0)
put(b, bell(880, 1.9, .85), 0.0, 1.0)
S['snd_short_bell'] = finish(reverb(b, .16, .5), tail=.1)

b = buf(1.5)
for st in (0, .2): put(b, beep(1046, .11), st, .9)
for st in (.75, .95): put(b, beep(1046, .11), st, .9)
S['snd_short_beep'] = finish(b)

b = buf(2.0)
for i, n in enumerate(['E5', 'G5', 'C6']): put(b, marimba(hz(n), 1.2), i*.2, 1.0)
S['snd_short_marimba'] = finish(reverb(b, .18, .5))

# ---------------- MÉDIOS ----------------
b = buf(7.0)
for rep, g in ((0, 1.0), (3.4, .7)):
    for i, n in enumerate(['C5', 'E5', 'G5', 'C6']): put(b, bell(hz(n), 2.8, 1.2), rep + i*.34, g*(0.8 + .06*i))
S['snd_medium_chime'] = finish(reverb(b, .26, 1.1))

b = buf(6.5)
seq = ['C5','D5','E5','G5','A5','G5','E5','D5','C5']
for i, n in enumerate(seq): put(b, pluck(hz(n), 1.8), i*.22, .9)
put(b, pluck(hz('C6'), 3.0, 1.1), 9*.22 + .05, 1.0); put(b, pluck(hz('E5'), 3.0, 1.1), 9*.22 + .05, .6)
S['snd_medium_harp'] = finish(reverb(b, .25, 1.0))

b = buf(7.5)
for rep in (0, 3.6):
    put(b, bell(hz('E5'), 2.2, .9), rep, 1.0); put(b, bell(hz('C5'), 2.8, 1.1), rep + .75, 1.0)
S['snd_medium_ding'] = finish(reverb(b, .2, .8))

b = buf(8.0)
def ping(f=1180, dur=1.4):
    t = t_(dur); s = np.sin(2*np.pi*f*t)*np.exp(-t/.28) + .25*np.sin(2*np.pi*f*2*t)*np.exp(-t/.12)
    return release(attack(s, 3.0), 30)
for k in range(4):
    st = k * 1.9
    put(b, ping(), st, 1.0); put(b, ping(), st + .38, .38); put(b, ping(), st + .76, .15)
S['snd_medium_sonar'] = finish(reverb(b, .22, .9))

b = buf(7.5)
for i, n in enumerate(['G5', 'B5', 'D6']): put(b, glass(hz(n), 3.2, 1.5), i*.55, .9)
for i, n in enumerate(['C6', 'E6', 'G5']): put(b, glass(hz(n), 3.2, 1.5), 3.6 + i*.55, .85)
S['snd_medium_glass'] = finish(reverb(b, .3, 1.2))

# ---------------- LONGOS ----------------
# Amanhecer: acordes suaves que crescem + notas de sino em escala pentatónica ascendente
D = 26.0
b = buf(D)
t = t_(D); swell = np.clip(t / 20.0, 0, 1) ** 1.3 * .8 + .2
pad = np.zeros_like(t)
for f, a in ((hz('C4'), 1), (hz('G4'), .7), (hz('E5'), .5)):
    pad += a * np.sin(2*np.pi*f*t) * (1 + .03*np.sin(2*np.pi*.18*t))
pad *= swell * .16 * np.minimum(1, (D - 1.2 - t).clip(0) / 3.0) * np.minimum(1, t/2.0)
b[:len(pad)] += pad[:len(b)]
scale = ['C5','D5','E5','G5','A5','C6','D6','E6','G6']
tt = 1.0; i = 0
while tt < D - 4:
    n = scale[min(i, len(scale)-1)] if i < len(scale) else scale[(i*5) % len(scale)]
    put(b, bell(hz(n), 3.0, 1.2), tt, .55 + .45*min(1, tt/20))
    tt += 1.9 - min(.7, tt/35); i += 1
S['snd_long_dawn'] = finish(reverb(b, .3, 1.5))

# Clássico: toque de campainha com tremolo
D = 22.0
b = buf(D)
def ring_burst(dur=1.7):
    t = t_(dur); s = np.zeros_like(t)
    strike = 17.0
    for k in range(int(dur*strike)):
        st = k / strike; f = 1320 if k % 2 == 0 else 1760
        seg = bell(f, .22, .08, .6)
        i0 = int(st*SR); n = min(len(seg), len(s) - i0)
        s[i0:i0+n] += seg[:n] * .9
    return release(s, 40)
cur = 0.4
while cur < D - 2.2:
    put(b, ring_burst(), cur, 1.0); cur += 1.7 + 0.9
S['snd_long_classic'] = finish(reverb(b, .12, .4))

# Digital: grupos de quatro bips, com intensidade constante
D = 20.0
b = buf(D); cur = .2
while cur < D - 2.0:
    for k in range(4): put(b, beep(1175, .09), cur + k*.16, .85)
    cur += .9 + .55
    if int((cur-.2)/1.45) % 2 == 1:    # de dois em dois grupos, uma ligeira variação de altura
        pass
S['snd_long_digital'] = finish(b)

# Sinos de vento: notas aleatórias, suaves
D = 30.0
b = buf(D); tt = .3
pent = ['E6','G6','A6','B6','D7','E7','G6','A6']
while tt < D - 3.5:
    n = pent[rng.integers(len(pent))]
    put(b, bell(hz(n), 3.2, .9 + rng.random()*.5, .7), tt, .45 + rng.random()*.5)
    tt += .12 + rng.random()*.85
S['snd_long_windchimes'] = finish(reverb(b, .32, 1.4))

# Crescendo: escala que sobe, acelera e fica mais forte
D = 24.0
b = buf(D); tt = .2; step = 0
notes = ['C5','D5','E5','G5','A5','C6','D6','E6']
while tt < D - 2.5:
    n = notes[step % len(notes)]
    oct_up = 2 if (step // len(notes)) % 3 == 2 else 1
    g = .35 + .65 * min(1, tt / (D - 6))
    put(b, marimba(hz(n) * (1 if oct_up == 1 else 2), 1.0, .5), tt, g)
    tt += max(.14, .55 - tt * .018); step += 1
S['snd_long_rise'] = finish(reverb(b, .22, .8))

for k, v in S.items():
    save(k, v)
    print(f'{k:24s} {len(v)/SR:5.1f}s peak={np.max(np.abs(v)):.2f}')
