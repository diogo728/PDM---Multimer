# Tipografia

A app usa **Multimer Sans**, embutida em `app/src/main/res/font/` (funciona 100% offline, nada é descarregado).

É derivada da **Instrument Sans** (© The Instrument Sans Project Authors, licença SIL OFL 1.1, texto em
`app/src/main/assets/licenses/MultimerSans-OFL.txt`). A Instrument Sans só tem Regular e Bold; os pesos
ExtraLight, Light, Medium e SemiBold foram gerados por interpolação/extrapolação dos contornos
(os dois pesos originais têm contornos totalmente compatíveis), para obter os algarismos finos.
Mantém os algarismos tabulares (`tnum`), por isso os números não "tremem" ao contar.
